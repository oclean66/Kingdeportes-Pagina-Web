var s_iOffsetX, s_iOffsetY;
(function(a) {
    (jQuery.browser = jQuery.browser || {}).mobile = /android|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(ad|hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|tablet|treo|up\.(browser|link)|vodafone|wap|webos|windows (ce|phone)|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))
})(navigator.userAgent ||
    navigator.vendor || window.opera);
$(window).resize(function() {
    sizeHandler()
});

function trace(a) {
    console.log(a)
}

function getSize(a) {
    var d = a.toLowerCase(),
        c = window.document,
        b = c.documentElement;
    if (void 0 === window["inner" + a]) a = b["client" + a];
    else if (window["inner" + a] != b["client" + a]) {
        var e = c.createElement("body");
        e.id = "vpw-test-b";
        e.style.cssText = "overflow:scroll";
        var f = c.createElement("div");
        f.id = "vpw-test-d";
        f.style.cssText = "position:absolute;top:-1000px";
        f.innerHTML = "<style>@media(" + d + ":" + b["client" + a] + "px){body#vpw-test-b div#vpw-test-d{" + d + ":7px!important}}</style>";
        e.appendChild(f);
        b.insertBefore(e, c.head);
        a = 7 == f["offset" + a] ? b["client" + a] : window["inner" + a];
        b.removeChild(e)
    } else a = window["inner" + a];
    return a
}
window.addEventListener("orientationchange", onOrientationChange);

function onOrientationChange() {
    window.matchMedia("(orientation: portrait)").matches && sizeHandler();
    window.matchMedia("(orientation: landscape)").matches && sizeHandler()
}

function isIOS() {
    for (var a = "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";"); a.length;)
        if (navigator.platform === a.pop()) return !0;
    return !1
}

function getIOSWindowHeight() {
    return document.documentElement.clientWidth / window.innerWidth * window.innerHeight
}

function getHeightOfIOSToolbars() {
    var a = (0 === window.orientation ? screen.height : screen.width) - getIOSWindowHeight();
    return 1 < a ? a : 0
}

function sizeHandler() {
    window.scrollTo(0, 1);
    if ($("#canvas")) {
        var a;
        a = navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? getIOSWindowHeight() : getSize("Height");
        var d = getSize("Width");
        _checkOrientation(d, a);
        var c = Math.min(a / CANVAS_HEIGHT, d / CANVAS_WIDTH),
            b = CANVAS_WIDTH * c,
            c = CANVAS_HEIGHT * c,
            e;
        c < a ? (e = a - c, c += e, b += CANVAS_WIDTH / CANVAS_HEIGHT * e) : b < d && (e = d - b, b += e, c += CANVAS_HEIGHT / CANVAS_WIDTH * e);
        e = a / 2 - c / 2;
        var f = d / 2 - b / 2,
            g = CANVAS_WIDTH / b;
        if (f * g < -EDGEBOARD_X || e * g < -EDGEBOARD_Y) c = Math.min(a / (CANVAS_HEIGHT - 2 * EDGEBOARD_Y),
            d / (CANVAS_WIDTH - 2 * EDGEBOARD_X)), b = CANVAS_WIDTH * c, c *= CANVAS_HEIGHT, e = (a - c) / 2, f = (d - b) / 2, g = CANVAS_WIDTH / b;
        s_iOffsetX = -1 * f * g;
        s_iOffsetY = -1 * e * g;
        0 <= e && (s_iOffsetY = 0);
        0 <= f && (s_iOffsetX = 0);
        null !== s_oInterface && s_oInterface.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        null !== s_oMenu && s_oMenu.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        s_bMobile ? ($("#canvas").css("width", b + "px"), $("#canvas").css("height", c + "px")) : (s_oStage.canvas.width = b, s_oStage.canvas.height = c, s_oStage.scaleX = s_oStage.scaleY = Math.min(b / CANVAS_WIDTH,
            c / CANVAS_HEIGHT));
        0 > e ? $("#canvas").css("top", e + "px") : $("#canvas").css("top", "0px");
        $("#canvas").css("left", f + "px")
    }
}

function _checkOrientation(a, d) {
    s_bMobile && ENABLE_CHECK_ORIENTATION && (a > d ? "landscape" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"), s_oMain.stopUpdate()) : "portrait" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"),
        s_oMain.stopUpdate()))
}

function inIframe() {
    try {
        return window.self !== window.top
    } catch (a) {
        return !0
    }
}

function createBitmap(a, d, c) {
    var b = new createjs.Bitmap(a),
        e = new createjs.Shape;
    d && c ? e.graphics.beginFill("#fff").drawRect(0, 0, d, c) : e.graphics.beginFill("#ff0").drawRect(0, 0, a.width, a.height);
    b.hitArea = e;
    return b
}

function createSprite(a, d, c, b, e, f) {
    a = null !== d ? new createjs.Sprite(a, d) : new createjs.Sprite(a);
    d = new createjs.Shape;
    d.graphics.beginFill("#000000").drawRect(-c, -b, e, f);
    a.hitArea = d;
    return a
}

function randomFloatBetween(a, d, c) {
    "undefined" === typeof c && (c = 2);
    return parseFloat(Math.min(a + Math.random() * (d - a), d).toFixed(c))
}

function shuffle(a) {
    for (var d = a.length, c, b; 0 !== d;) b = Math.floor(Math.random() * d), --d, c = a[d], a[d] = a[b], a[b] = c;
    return a
}

function formatTime(a) {
    a /= 1E3;
    var d = Math.floor(a / 60);
    a = parseFloat(a - 60 * d).toFixed(1);
    var c = "",
        c = 10 > d ? c + ("0" + d + ":") : c + (d + ":");
    return 10 > a ? c + ("0" + a) : c + a
}
Array.prototype.sortOn = function() {
    var a = this.slice();
    if (!arguments.length) return a.sort();
    var d = Array.prototype.slice.call(arguments);
    return a.sort(function(a, b) {
        for (var c = d.slice(), f = c.shift(); a[f] == b[f] && c.length;) f = c.shift();
        return a[f] == b[f] ? 0 : a[f] > b[f] ? 1 : -1
    })
};

function roundDecimal(a, d) {
    var c = Math.pow(10, d);
    return Math.round(c * a) / c
}

function tweenVectors(a, d, c, b) {
    b.set(a.getX() + c * (d.getX() - a.getX()), a.getY() + c * (d.getY() - a.getY()));
    return b
}

function NoClickDelay(a) {
    this.element = a;
    window.Touch && this.element.addEventListener("touchstart", this, !1)
}
NoClickDelay.prototype = {
    handleEvent: function(a) {
        switch (a.type) {
            case "touchstart":
                this.onTouchStart(a);
                break;
            case "touchmove":
                this.onTouchMove(a);
                break;
            case "touchend":
                this.onTouchEnd(a)
        }
    },
    onTouchStart: function(a) {
        a.preventDefault();
        this.moved = !1;
        this.element.addEventListener("touchmove", this, !1);
        this.element.addEventListener("touchend", this, !1)
    },
    onTouchMove: function(a) {
        this.moved = !0
    },
    onTouchEnd: function(a) {
        this.element.removeEventListener("touchmove", this, !1);
        this.element.removeEventListener("touchend",
            this, !1);
        if (!this.moved) {
            a = document.elementFromPoint(a.changedTouches[0].clientX, a.changedTouches[0].clientY);
            3 === a.nodeType && (a = a.parentNode);
            var d = document.createEvent("MouseEvents");
            d.initEvent("click", !0, !0);
            a.dispatchEvent(d)
        }
    }
};

function playSound(a, d, c) {
    return !1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile ? createjs.Sound.play(a, {
        loop: c,
        volume: d
    }) : null
}

function stopSound(a) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || a.stop()
}

function setVolume(a, d) {
    if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) a.volume = d
}

function setMute(a, d) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || a.setMute(d)
}

function ctlArcadeResume() {
    null !== s_oMain && s_oMain.startUpdate()
}

function ctlArcadePause() {
    null !== s_oMain && s_oMain.stopUpdate()
}

function getParamValue(a) {
    for (var d = window.location.search.substring(1).split("&"), c = 0; c < d.length; c++) {
        var b = d[c].split("=");
        if (b[0] == a) return b[1]
    }
}
(function() {
    function a(a) {
        var b = {
            focus: "visible",
            focusin: "visible",
            pageshow: "visible",
            blur: "hidden",
            focusout: "hidden",
            pagehide: "hidden"
        };
        a = a || window.event;
        a.type in b ? document.body.className = b[a.type] : (document.body.className = this[d] ? "hidden" : "visible", "hidden" === document.body.className ? s_oMain.stopUpdate() : s_oMain.startUpdate())
    }
    var d = "hidden";
    d in document ? document.addEventListener("visibilitychange", a) : (d = "mozHidden") in document ? document.addEventListener("mozvisibilitychange", a) : (d = "webkitHidden") in
        document ? document.addEventListener("webkitvisibilitychange", a) : (d = "msHidden") in document ? document.addEventListener("msvisibilitychange", a) : "onfocusin" in document ? document.onfocusin = document.onfocusout = a : window.onpageshow = window.onpagehide = window.onfocus = window.onblur = a
})();

function CSpriteLibrary() {
    var a, d, c, b, e, f;
    this.init = function(g, m, l) {
        c = d = 0;
        b = g;
        e = m;
        f = l;
        a = {}
    };
    this.addSprite = function(b, c) {
        a.hasOwnProperty(b) || (a[b] = {
            szPath: c,
            oSprite: new Image
        }, d++)
    };
    this.getSprite = function(b) {
        return a.hasOwnProperty(b) ? a[b].oSprite : null
    };
    this._onSpritesLoaded = function() {
        e.call(f)
    };
    this._onSpriteLoaded = function() {
        b.call(f);
        ++c === d && this._onSpritesLoaded()
    };
    this.loadSprites = function() {
        for (var b in a) a[b].oSprite.oSpriteLibrary = this, a[b].oSprite.onload = function() {
                this.oSpriteLibrary._onSpriteLoaded()
            },
            a[b].oSprite.src = a[b].szPath
    };
    this.getNumSprites = function() {
        return d
    }
}
var CANVAS_WIDTH = 1700,
    CANVAS_HEIGHT = 768,
    EDGEBOARD_X = 250,
    EDGEBOARD_Y = 0,
    FPS_TIME = 1E3 / 24,
    DISABLE_SOUND_MOBILE = !1,
    FONT_GAME_1 = "arialbold",
    FONT_GAME_2 = "Digital-7",
    STATE_LOADING = 0,
    STATE_MENU = 1,
    STATE_HELP = 1,
    STATE_GAME = 3,
    STATE_GAME_WAITING_FOR_BET = 0,
    STATE_GAME_DEALING = 1,
    STATE_GAME_PLAYER_TURN = 2,
    STATE_GAME_SHOWDOWN = 3,
    STATE_GAME_DISTRIBUTE_FICHES = 4,
    STATE_GAME_SHOW_WINNER = 5,
    STATE_CARD_DEALING = 0,
    STATE_CARD_REMOVING = 1,
    ON_MOUSE_DOWN = 0,
    ON_MOUSE_UP = 1,
    ON_MOUSE_OVER = 2,
    ON_MOUSE_OUT = 3,
    ON_DRAG_START = 4,
    ON_DRAG_END = 5,
    ASSIGN_FICHES =
    "ASSIGN_FICHES",
    END_HAND = "END_HAND",
    ON_CARD_SHOWN = "ON_CARD_SHOWN",
    ON_CARD_ANIMATION_ENDING = "ON_CARD_ANIMATION_ENDING",
    ON_CARD_TO_REMOVE = "ON_CARD_TO_REMOVE",
    NUM_FICHES = 6,
    CARD_WIDTH = 66,
    CARD_HEIGHT = 102,
    MIN_BET, MAX_BET, TOTAL_MONEY, FICHE_WIDTH, WIN_OCCURRENCE, BET_OCCURRENCE, TIME_FICHES_MOV = 600,
    TIME_CARD_DEALING = 250,
    TIME_CARD_REMOVE = 1E3,
    TIME_SHOW_FINAL_CARDS = 4E3,
    TIME_END_HAND, BET_TIME = 1E4,
    AD_SHOW_COUNTER, ENABLE_FULLSCREEN, NUM_DECKS = 4,
    PAYOUT_MULT, PROGRESSIVE_LIMIT, BET_ANTE = 0,
    BET_RAISE = 1,
    POS_BET = [];
PAYOUT_MULT = [];
var GAP_1 = 0,
    GAP_2 = 1,
    GAP_3 = 2,
    GAP_4 = 3,
    GAP_5 = 4,
    GAP_6 = 5,
    GAP_7 = 6,
    GAP_8 = 7,
    GAP_9 = 8,
    GAP_10 = 9,
    GAP_11 = 10,
    GAP_12 = 11,
    CONSECUTIVE_RANK = 12,
    PAIR_RANK = 13,
    THREE_OF_A_KIND = 14,
    TEXT_DEAL = "DEAL",
    TEXT_MIN_BET = "MIN BET",
    TEXT_MAX_BET = "MAX BET",
    TEXT_RECHARGE = "RECHARGE",
    TEXT_EXIT = "EXIT",
    TEXT_MONEY = "MONEY",
    TEXT_CURRENCY = "$",
    TEXT_RAISE = "RAISE",
    TEXT_CALL = "CALL",
    TEXT_COLLECT = "COLLECT",
    TEXT_PROGRESSIVE = "PROGRESSIVE BET",
    TEXT_PROGRESSIVE_LIMIT = "PROGRESSIVE ANTE LIMIT",
    TEXT_DISPLAY_MSG_WAITING_BET = "BET ANTE",
    TEXT_DISPLAY_MSG_PLAYER_LOSE = "PLAYER LOSES THIS HAND!",
    TEXT_DISPLAY_MSG_STANDOFF = "STAND OFF",
    TEXT_DISPLAY_MSG_PLAYER_WIN = "PLAYER WINS",
    TEXT_DISPLAY_MSG_PUSH = "PLAYER'S WAGER RETURNED!",
    TEXT_DISPLAY_MSG_USER_TURN = "PLAYER TURN. CALL OR RAISE?",
    TEXT_DISPLAY_MSG_USER_TURN_NO_RAISE = "PLAYER TURN. NOT ENOUGH MONEY FOR RAISE CALL",
    TEXT_DISPLAY_MSG_SHOWDOWN = "SHOWDOWN!",
    TEXT_DISPLAY_MSG_DEALING = "DEALING...",
    TEXT_NO_MONEY = "YOU DON'T HAVE ENOUGH MONEY!!!",
    TEXT_HAND_WON_PLAYER = "YOU WON THIS GAME HAND!!",
    TEXT_HAND_PUSH = "HAND IS A PUSH",
    TEXT_HAND_LOSE_PLAYER = "YOU LOSE THIS GAME HAND!!",
    TEXT_ERROR_PROG_LIMIT = "YOUR CURRENT BET IS HIGHER THAN PROGRESSIVE LIMIT. YOU MUST COLLECT CHIPS!",
    TEXT_ERROR_MIN_BET = "YOUR BET IS LOWER THAN MINIMUM BET!!",
    TEXT_ERROR_MAX_BET = "YOUR BET IS HIGHER THAN MAXIMUM BET!!",
    TEXT_ERROR_PROGRESSIVE = "PLEASE WAIT GAME ROUND END TO TOGGLE PROGRESSIVE FEATURE!",
    TEXT_EVALUATOR = "ROYAL FLUSH;STRAIGHT FLUSH;FOUR OF A KIND;FULL HOUSE;FLUSH;STRAIGHT;THREE OF A KIND;TWO PAIR;ONE PAIR;HIGH CARD;NO HAND".split(";"),
    TEXT_SHARE_IMAGE = "200x200.jpg",
    TEXT_SHARE_TITLE = "Congratulations!",
    TEXT_SHARE_MSG1 = "You collected <strong>",
    TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!",
    TEXT_SHARE_SHARE1 = "My score is ",
    TEXT_SHARE_SHARE2 = " points! Can you do better?";

function CPreloader() {
    var a, d, c, b, e;
    this._init = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("bg_preloader", "./sprites/bg_preloader.jpg");
        s_oSpriteLibrary.addSprite("progress_bar", "./sprites/progress_bar.png");
        s_oSpriteLibrary.loadSprites();
        e = new createjs.Container;
        s_oStage.addChild(e)
    };
    this.unload = function() {
        e.removeAllChildren()
    };
    this._onImagesLoaded = function() {};
    this._onAllImagesLoaded = function() {
        this.attachSprites();
        s_oMain.preloaderReady()
    };
    this.attachSprites = function() {
        var f = createBitmap(s_oSpriteLibrary.getSprite("bg_preloader"));
        e.addChild(f);
        c = createBitmap(s_oSpriteLibrary.getSprite("progress_bar"));
        c.x = 599;
        c.y = CANVAS_HEIGHT - 50;
        e.addChild(c);
        a = 476;
        b = new createjs.Shape;
        b.graphics.beginFill("rgba(255,0,0,0.01)").drawRect(599, CANVAS_HEIGHT - 50, 1, 30);
        e.addChild(b);
        c.mask = b;
        d = new createjs.Text("0%", "30px " + FONT_GAME_1, "#fff");
        d.x = 638;
        d.y = CANVAS_HEIGHT - 56;
        d.textAlign = "center";
        d.textBaseline = "middle";
        e.addChild(d)
    };
    this.refreshLoader = function(c) {
        d.text =
            c + "%";
        c = Math.floor(c * a / 100);
        b.graphics.clear();
        b.graphics.beginFill("rgba(255,0,0,0.01)").drawRect(599, CANVAS_HEIGHT - 50, c, 30)
    };
    this._init()
}

function CMain(a) {
    var d, c = 0,
        b = 0,
        e = STATE_LOADING,
        f, g, m;
    this.initContainer = function() {
        var a = document.getElementById("canvas");
        s_oStage = new createjs.Stage(a);
        createjs.Touch.enable(s_oStage);
        s_bMobile = jQuery.browser.mobile;
        !1 === s_bMobile && s_oStage.enableMouseOver(20);
        s_iPrevTime = (new Date).getTime();
        createjs.Ticker.setFPS(30);
        createjs.Ticker.addEventListener("tick", this._update);
        navigator.userAgent.match(/Windows Phone/i) && (DISABLE_SOUND_MOBILE = !0);
        s_oSpriteLibrary = new CSpriteLibrary;
        g = new CPreloader;
        s_oGameSettings = new CGameSettings;
        d = !0
    };
    this.preloaderReady = function() {
        this._loadImages();
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || this._initSounds()
    };
    this.soundLoaded = function() {
        c++;
        g.refreshLoader(Math.floor(c / b * 100));
        c === b && (g.unload(), this.gotoMenu())
    };
    this._initSounds = function() {
        createjs.Sound.initializeDefaultPlugins() && (0 < navigator.userAgent.indexOf("Opera") || 0 < navigator.userAgent.indexOf("OPR") ? (createjs.Sound.alternateExtensions = ["mp3"], createjs.Sound.addEventListener("fileload", createjs.proxy(this.soundLoaded,
            this)), createjs.Sound.registerSound("./sounds/card.ogg", "card"), createjs.Sound.registerSound("./sounds/chip.ogg", "chip"), createjs.Sound.registerSound("./sounds/fiche_collect.ogg", "fiche_collect"), createjs.Sound.registerSound("./sounds/press_but.ogg", "press_but"), createjs.Sound.registerSound("./sounds/win.ogg", "win"), createjs.Sound.registerSound("./sounds/lose.ogg", "lose")) : (createjs.Sound.alternateExtensions = ["ogg"], createjs.Sound.addEventListener("fileload", createjs.proxy(this.soundLoaded, this)),
            createjs.Sound.registerSound("./sounds/card.mp3", "card", 4), createjs.Sound.registerSound("./sounds/chip.mp3", "chip", 4), createjs.Sound.registerSound("./sounds/fiche_collect.mp3", "fiche_collect"), createjs.Sound.registerSound("./sounds/press_but.mp3", "press_but"), createjs.Sound.registerSound("./sounds/win.mp3", "win"), createjs.Sound.registerSound("./sounds/lose.mp3", "lose")), b += 6)
    };
    this._loadImages = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("but_menu_bg",
            "./sprites/but_menu_bg.png");
        s_oSpriteLibrary.addSprite("but_game_bg", "./sprites/but_game_bg.png");
        s_oSpriteLibrary.addSprite("but_exit", "./sprites/but_exit.png");
        s_oSpriteLibrary.addSprite("bg_menu", "./sprites/bg_menu.jpg");
        s_oSpriteLibrary.addSprite("audio_icon", "./sprites/audio_icon.png");
        s_oSpriteLibrary.addSprite("bg_game", "./sprites/bg_game.jpg");
        s_oSpriteLibrary.addSprite("card_spritesheet", "./sprites/card_spritesheet.png");
        s_oSpriteLibrary.addSprite("msg_box", "./sprites/msg_box.png");
        s_oSpriteLibrary.addSprite("display_bg",
            "./sprites/display_bg.png");
        s_oSpriteLibrary.addSprite("fiche_highlight", "./sprites/fiche_highlight.png");
        s_oSpriteLibrary.addSprite("win_bg", "./sprites/win_bg.png");
        s_oSpriteLibrary.addSprite("but_clear", "./sprites/but_clear.png");
        s_oSpriteLibrary.addSprite("but_generic", "./sprites/but_generic.png");
        s_oSpriteLibrary.addSprite("but_rebet", "./sprites/but_rebet.png");
        s_oSpriteLibrary.addSprite("gui_bg", "./sprites/gui_bg.png");
        s_oSpriteLibrary.addSprite("bet_ante", "./sprites/bet_ante.png");
        s_oSpriteLibrary.addSprite("bet_raise",
            "./sprites/bet_raise.png");
        s_oSpriteLibrary.addSprite("puck", "./sprites/puck.png");
        s_oSpriteLibrary.addSprite("toggle_progressive", "./sprites/toggle_progressive.png");
        s_oSpriteLibrary.addSprite("help_cursor", "./sprites/help_cursor.png");
        s_oSpriteLibrary.addSprite("but_fullscreen", "./sprites/but_fullscreen.png");
        for (var a = 0; a < NUM_FICHES; a++) s_oSpriteLibrary.addSprite("fiche_" + a, "./sprites/fiche_" + a + ".png");
        b += s_oSpriteLibrary.getNumSprites();
        s_oSpriteLibrary.loadSprites()
    };
    this._onImagesLoaded = function() {
        c++;
        g.refreshLoader(Math.floor(c / b * 100));
        c === b && (g.unload(), this.gotoMenu())
    };
    this._onAllImagesLoaded = function() {};
    this.onAllPreloaderImagesLoaded = function() {
        this._loadImages()
    };
    this.gotoMenu = function() {
        new CMenu;
        e = STATE_MENU
    };
    this.gotoGame = function() {
        m = new CGame(f);
        e = STATE_GAME
    };
    this.gotoHelp = function() {
        new CHelp;
        e = STATE_HELP
    };
    this.stopUpdate = function() {
        d = !1;
        createjs.Ticker.paused = !0;
        $("#block_game").css("display", "block");
        createjs.Sound.setMute(!0)
    };
    this.startUpdate = function() {
        s_iPrevTime = (new Date).getTime();
        d = !0;
        createjs.Ticker.paused = !1;
        $("#block_game").css("display", "none");
        s_bAudioActive && createjs.Sound.setMute(!1)
    };
    this._update = function(a) {
        if (d) {
            var b = (new Date).getTime();
            s_iTimeElaps = b - s_iPrevTime;
            s_iCntTime += s_iTimeElaps;
            s_iCntFps++;
            s_iPrevTime = b;
            1E3 <= s_iCntTime && (s_iCurFps = s_iCntFps, s_iCntTime -= 1E3, s_iCntFps = 0);
            e === STATE_GAME && m.update();
            s_oStage.update(a)
        }
    };
    s_oMain = this;
    f = a;
    ENABLE_CHECK_ORIENTATION = f.check_orientation;
    this.initContainer()
}
var s_bMobile, s_bAudioActive = !0,
    s_bFullscreen = !1,
    s_iCntTime = 0,
    s_iTimeElaps = 0,
    s_iPrevTime = 0,
    s_iCntFps = 0,
    s_iCurFps = 0,
    s_oDrawLayer, s_oStage, s_oMain, s_oSpriteLibrary, s_oGameSettings;

function CTextButton(a, d, c, b, e, f, g, m) {
    var l, n, h, k, x, r, u, v;
    this._init = function(a, b, c, d, e, f, g, m) {
        l = !1;
        n = [];
        h = [];
        v = m;
        x = createBitmap(c);
        m = Math.ceil(g / 20);
        r = new createjs.Text(d, g + "px " + e, "#000000");
        var z = r.getBounds();
        r.textAlign = "center";
        r.textBaseline = "alphabetic";
        r.x = c.width / 2 + m;
        r.y = Math.floor(c.height / 2) + z.height / 3 + m;
        u = new createjs.Text(d, g + "px " + e, f);
        u.textAlign = "center";
        u.textBaseline = "alphabetic";
        u.x = c.width / 2;
        u.y = Math.floor(c.height / 2) + z.height / 3;
        k = new createjs.Container;
        k.x = a;
        k.y = b;
        k.regX = c.width /
            2;
        k.regY = c.height / 2;
        k.cursor = "pointer";
        k.addChild(x, u);
        v.addChild(k);
        this._initListener()
    };
    this.unload = function() {
        k.off("mousedown");
        k.off("pressup");
        v.removeChild(k)
    };
    this.setVisible = function(a) {
        k.visible = a
    };
    this.enable = function() {
        l = !1;
        u.color = "#fff";
        k.visible = !0
    };
    this.disable = function() {
        l = !0;
        u.color = "#a39b9d"
    };
    this._initListener = function() {
        oParent = this;
        k.on("mousedown", this.buttonDown);
        k.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        n[a] = b;
        h[a] = c
    };
    this.buttonRelease = function() {
        l ||
            (!1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || playSound("press_but", 1, 0), k.scaleX = 1, k.scaleY = 1, n[ON_MOUSE_UP] && n[ON_MOUSE_UP].call(h[ON_MOUSE_UP]))
    };
    this.buttonDown = function() {
        l || (k.scaleX = .9, k.scaleY = .9, n[ON_MOUSE_DOWN] && n[ON_MOUSE_DOWN].call(h[ON_MOUSE_DOWN]))
    };
    this.setPosition = function(a, b) {
        k.x = a;
        k.y = b
    };
    this.changeText = function(a) {
        u.text = a;
        r.text = a
    };
    this.setX = function(a) {
        k.x = a
    };
    this.setY = function(a) {
        k.y = a
    };
    this.getButtonImage = function() {
        return k
    };
    this.getX = function() {
        return k.x
    };
    this.getY = function() {
        return k.y
    };
    this._init(a, d, c, b, e, f, g, m);
    return this
}

function CGfxButton(a, d, c, b) {
    var e, f, g, m, l, n = [],
        h, k;
    this._init = function(a, b, c) {
        e = !1;
        m = [];
        l = [];
        f = c.width;
        g = c.height;
        h = createBitmap(c);
        h.x = a;
        h.y = b;
        h.regX = c.width / 2;
        h.regY = c.height / 2;
        h.cursor = "pointer";
        k.addChild(h);
        this._initListener()
    };
    this.unload = function() {
        h.off("mousedown", this.buttonDown);
        h.off("pressup", this.buttonRelease);
        k.removeChild(h)
    };
    this.setVisible = function(a) {
        h.visible = a
    };
    this._initListener = function() {
        h.on("mousedown", this.buttonDown);
        h.on("pressup", this.buttonRelease)
    };
    this.addEventListener =
        function(a, c, b) {
            m[a] = c;
            l[a] = b
        };
    this.addEventListenerWithParams = function(a, c, b, d) {
        m[a] = c;
        l[a] = b;
        n = d
    };
    this.buttonRelease = function() {
        e || (!1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || playSound("press_but", 1, 0), m[ON_MOUSE_UP] && m[ON_MOUSE_UP].call(l[ON_MOUSE_UP], n))
    };
    this.buttonDown = function() {
        e || m[ON_MOUSE_DOWN] && m[ON_MOUSE_DOWN].call(l[ON_MOUSE_DOWN], n)
    };
    this.setPosition = function(a, c) {
        h.x = a;
        h.y = c
    };
    this.setX = function(a) {
        h.x = a
    };
    this.setY = function(a) {
        h.y = a
    };
    this.enable = function() {
        e = !1;
        h.filters = [];
        h.cache(0,
            0, f, g)
    };
    this.disable = function() {
        e = !0;
        var a = (new createjs.ColorMatrix).adjustSaturation(-100).adjustBrightness(40);
        h.filters = [new createjs.ColorMatrixFilter(a)];
        h.cache(0, 0, f, g)
    };
    this.getButtonImage = function() {
        return h
    };
    this.getX = function() {
        return h.x
    };
    this.getY = function() {
        return h.y
    };
    k = b;
    this._init(a, d, c);
    return this
}

function CToggle(a, d, c, b, e) {
    var f, g, m, l, n = [],
        h;
    this._init = function(a, c, b, d, e) {
        m = [];
        l = [];
        var k = new createjs.SpriteSheet({
            images: [b],
            frames: {
                width: b.width / 2,
                height: b.height,
                regX: b.width / 2 / 2,
                regY: b.height / 2
            },
            animations: {
                state_true: [0],
                state_false: [1]
            }
        });
        f = d;
        g = e;
        h = createSprite(k, "state_" + f, b.width / 2 / 2, b.height / 2, b.width / 2, b.height);
        h.x = a;
        h.y = c;
        h.cursor = "pointer";
        h.stop();
        s_oStage.addChild(h);
        this._initListener()
    };
    this.unload = function() {
        h.off("mousedown", this.buttonDown);
        h.off("pressup", this.buttonRelease);
        s_oStage.removeChild(h)
    };
    this._initListener = function() {
        h.on("mousedown", this.buttonDown);
        h.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        m[a] = b;
        l[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, d) {
        m[a] = b;
        l[a] = c;
        n = d
    };
    this.setActive = function(a) {
        f = a;
        h.gotoAndStop("state_" + f)
    };
    this.buttonRelease = function() {
        h.scaleX = 1;
        h.scaleY = 1;
        playSound("press_button", 1, 0);
        g && (f = !f, h.gotoAndStop("state_" + f));
        m[ON_MOUSE_UP] && m[ON_MOUSE_UP].call(l[ON_MOUSE_UP], n)
    };
    this.buttonDown = function() {
        h.scaleX =
            .9;
        h.scaleY = .9;
        m[ON_MOUSE_DOWN] && m[ON_MOUSE_DOWN].call(l[ON_MOUSE_DOWN], n)
    };
    this.setPosition = function(a, b) {
        h.x = a;
        h.y = b
    };
    this.setVisible = function(a) {
        h.visible = a
    };
    this.getY = function() {
        return h.y
    };
    this._init(a, d, c, b, e)
}

function CMenu() {
    var a, d, c, b, e, f = null,
        g = null,
        m, l, n, h;
    this._init = function() {
        m = createBitmap(s_oSpriteLibrary.getSprite("bg_menu"));
        s_oStage.addChild(m);
        var k = s_oSpriteLibrary.getSprite("but_menu_bg");
        l = new CGfxButton(CANVAS_WIDTH / 2, CANVAS_HEIGHT - 164, k, s_oStage);
        l.addEventListener(ON_MOUSE_UP, this._onButPlayRelease, this);
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) k = s_oSpriteLibrary.getSprite("audio_icon"), c = CANVAS_WIDTH - k.width / 4 - 10, b = k.height / 2 + 10, n = new CToggle(c, b, k, s_bAudioActive, !0), n.addEventListener(ON_MOUSE_UP,
            this._onAudioToggle, this);
        var k = window.document,
            x = k.documentElement;
        f = x.requestFullscreen || x.mozRequestFullScreen || x.webkitRequestFullScreen || x.msRequestFullscreen;
        g = k.exitFullscreen || k.mozCancelFullScreen || k.webkitExitFullscreen || k.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (f = !1);
        f && !1 === inIframe() && (k = s_oSpriteLibrary.getSprite("but_fullscreen"), a = k.width / 4 + 10, d = k.height / 2 + 10, e = new CToggle(a, d, k, s_bFullscreen, !0), e.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        h = new createjs.Shape;
        h.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(h);
        createjs.Tween.get(h).to({
            alpha: 0
        }, 400).call(function() {
            h.visible = !1
        });
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.refreshButtonPos = function(k, h) {
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || n.setPosition(c - k, h + b);
        f && !1 === inIframe() && e.setPosition(a + k, d + h)
    };
    this.unload = function() {
        l.unload();
        l = null;
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) n.unload(), n = null;
        f && !1 === inIframe() && e.unload();
        s_oStage.removeAllChildren();
        s_oMenu = null
    };
    this._onButPlayRelease = function() {
        this.unload();
        s_oMain.gotoGame();
        $(s_oMain).trigger("start_session")
    };
    this._onAudioToggle = function() {
        createjs.Sound.setMute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? (g.call(window.document), s_bFullscreen = !1) : (f.call(window.document.documentElement), s_bFullscreen = !0);
        sizeHandler()
    };
    s_oMenu = this;
    this._init()
}
var s_oMenu = null;

function CGame(a) {
    var d = !1,
        c, b = !1,
        e, f, g, m, l, n, h, k, x, r, u, v, z, D, G, A, C, H, F, B, E, q, p, y, t, w, I, J;
    this._init = function() {
        f = MAX_BET;
        g = -1;
        m = x = e = 0;
        s_oTweenController = new CTweenController;
        var a = createBitmap(s_oSpriteLibrary.getSprite("bg_game"));
        s_oStage.addChild(a);
        B = new createjs.Container;
        s_oStage.addChild(B);
        q = new CInterface(TOTAL_MONEY);
        E = new CHandEvaluator;
        p = new CSeat;
        p.setCredit(TOTAL_MONEY);
        y = new CPuck(400, 414, s_oStage);
        t = new CHelpCursor(515, 590, s_oSpriteLibrary.getSprite("help_cursor"), s_oStage);
        w = new CHelpCursor(1240,
            720, s_oSpriteLibrary.getSprite("help_cursor"), s_oStage);
        this.reset(!1);
        A = new CVector2;
        A.set(1214, 228);
        C = new CVector2;
        C.set(0, CANVAS_HEIGHT + 100);
        H = new CVector2;
        H.set(0, -CANVAS_HEIGHT);
        F = new CVector2(454, 230);
        J = new CGameOver;
        p.getCredit() < s_oGameSettings.getFichesValueAt(0) ? (this._gameOver(), this.changeState(-1)) : d = !0;
        G = new CVector2(A.getX(), A.getY());
        I = new CMsgBox;
        this.changeState(STATE_GAME_WAITING_FOR_BET)
    };
    this.unload = function() {
        d = !1;
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || createjs.Sound.stop();
        for (var a = 0; a < v.length; a++) v[a].unload();
        q.unload();
        J.unload();
        I.unload();
        s_oStage.removeAllChildren()
    };
    this.reset = function(a) {
        l = m = e = 0;
        p.reset(b);
        b = !1;
        v = [];
        v.splice(0);
        q.reset();
        q.enableBetFiches(a);
        this.shuffleCard()
    };
    this.shuffleCard = function() {
        z = [];
        z = s_oGameSettings.getShuffledCardDeck()
    };
    this.changeState = function(a) {
        g = a;
        switch (a) {
            case STATE_GAME_WAITING_FOR_BET:
                a = TEXT_MIN_BET + ": " + MIN_BET + "\n" + TEXT_MAX_BET + ": " + MAX_BET;
                s_bProgressiveAnte && (a += "\n" + TEXT_PROGRESSIVE_LIMIT + " " + PROGRESSIVE_LIMIT);
                q.displayMsg(TEXT_DISPLAY_MSG_WAITING_BET, a);
                break;
            case STATE_GAME_DEALING:
                q.disableButtons(), q.displayMsg(TEXT_DISPLAY_MSG_DEALING), this._dealing()
        }
    };
    this.cardFromDealerArrived = function(a, b) {
        2 !== b && a.showCard();
        s_oGame._dealing()
    };
    this._showWin = function() {
        if (c) {
            k = p.getBetAnte() + p.getBetAnte() * PAYOUT_MULT[u.result] + p.getBetRaise() + p.getBetRaise() * PAYOUT_MULT[u.result];
            this._playerWin();
            if (s_bProgressiveAnte) {
                q.enable(!0, !1, !1, !0);
                b = !0;
                return
            }
            p.increaseCredit(k);
            n -= k
        } else this._playerLose();
        this.distributeFiche()
    };
    this.distributeFiche = function() {
        this.changeState(STATE_GAME_DISTRIBUTE_FICHES);
        q.refreshCredit(p.getCredit());
        playSound("fiche_collect", 1, 0);
        setTimeout(function() {
            p.resetBet();
            s_oGame.changeState(STATE_GAME_WAITING_FOR_BET);
            q.enableBetFiches(!0)
        }, 3 * TIME_CARD_REMOVE)
    };
    this._playerWin = function() {
        u.result === PAIR_RANK || u.result === CONSECUTIVE_RANK ? (q.displayMsg(TEXT_DISPLAY_MSG_SHOWDOWN, TEXT_DISPLAY_MSG_PUSH + " " + k.toFixed(2) + TEXT_CURRENCY), q.showResultText(TEXT_HAND_PUSH)) : (q.displayMsg(TEXT_DISPLAY_MSG_SHOWDOWN,
            TEXT_DISPLAY_MSG_PLAYER_WIN + " " + k.toFixed(2) + TEXT_CURRENCY), q.showResultText(TEXT_HAND_WON_PLAYER));
        p.initMovement(C.getX(), C.getY());
        playSound("win", 1, 0)
    };
    this._playerLose = function() {
        q.displayMsg(TEXT_DISPLAY_MSG_SHOWDOWN, TEXT_DISPLAY_MSG_PLAYER_LOSE);
        p.initMovement(H.getX(), H.getY());
        q.showResultText(TEXT_HAND_LOSE_PLAYER);
        playSound("lose", 1, 0)
    };
    this._standOff = function(a) {
        p.increaseCredit(a);
        n -= a;
        q.displayMsg(TEXT_DISPLAY_MSG_SHOWDOWN, TEXT_DISPLAY_MSG_STANDOFF);
        p.initMovement(C.getX(), C.getY());
        q.showResultText(TEXT_DISPLAY_MSG_STANDOFF)
    };
    this._dealing = function() {
        if (3 > l) {
            var a = new CCard(A.getX(), A.getY(), B);
            2 === l && a.addEventListener(ON_CARD_SHOWN, this._onThirdCardShown, this);
            var b = D.splice(0, 1),
                c = b[0].fotogram,
                b = b[0].rank;
            a.setInfo(G, p.getAttachCardOffset(), c, b, l);
            p.newCardDealed();
            v.push(a);
            l++;
            a.addEventListener(ON_CARD_ANIMATION_ENDING, this.cardFromDealerArrived);
            playSound("card", 1, 0)
        } else v[0].getValue() > v[1].getValue() && (B.setChildIndex(v[2].getSprite(), 0), a = v[0].getCurPos(), c = v[1].getCurPos(),
            v[0].changePos(c), v[1].changePos(a)), a = u.result, u.result === THREE_OF_A_KIND && (a = PAIR_RANK), a = s_oGameSettings.getPuckPos(a), y.move(a.x), setTimeout(function() {
            s_oGame._prepareUserActions()
        }, 2E3)
    };
    this._prepareUserActions = function() {
        u.result === CONSECUTIVE_RANK ? (g = STATE_GAME_SHOWDOWN, s_oGame._showWin()) : u.result === PAIR_RANK || u.result === THREE_OF_A_KIND ? v[2].showCard() : (p.getCredit() < 2 * p.getBetAnte() ? (q.enable(!1, !1, !0, !1), q.displayMsg(TEXT_DISPLAY_MSG_USER_TURN_NO_RAISE)) : (q.enable(!1, !0, !0, !1), q.displayMsg(TEXT_DISPLAY_MSG_USER_TURN)),
            s_oGame.changeState(STATE_GAME_PLAYER_TURN))
    };
    this._onThirdCardShown = function() {
        u.result === THREE_OF_A_KIND && y.move(s_oGameSettings.getPuckPos(THREE_OF_A_KIND).x);
        g = STATE_GAME_SHOWDOWN;
        setTimeout(function() {
            s_oGame._showWin()
        }, 1500)
    };
    this._onEndHand = function() {
        for (var a = new CVector2(F.getX(), F.getY()), b = 0; b < v.length; b++) v[b].initRemoving(a), v[b].hideCard();
        e = 0;
        s_oGame.changeState(STATE_GAME_SHOW_WINNER);
        y.resetPosition();
        x++;
        x === AD_SHOW_COUNTER && (x = 0, $(s_oMain).trigger("show_interlevel_ad"));
        $(s_oMain).trigger("save_score", [p.getCredit()])
    };
    this.setBet = function(a, b) {
        if (q.isResultPanelvisible()) q.hideWinnnerPanel(), p.clearBet(), r = this.setBet, this._onEndHand();
        else {
            var c = s_oGameSettings.getFichesValues()[b],
                d;
            a === BET_ANTE ? (e = 0, t.hide(), d = p.getBetAnte() + c) : d = p.getBetAnte();
            d > f ? I.show(TEXT_ERROR_MAX_BET) : 0 > p.getCredit() - c ? q.displayMsg(TEXT_NO_MONEY) : (a === BET_ANTE ? (p.decreaseCredit(c), n += c, p.betAnte(c), q.enable(!0, !1, !1)) : (p.decreaseCredit(d), n += d, p.betRaise()), q.refreshCredit(p.getCredit()))
        }
    };
    this.toggleProgressive = function() {
        g ===
            STATE_GAME_WAITING_FOR_BET ? (s_bProgressiveAnte = !s_bProgressiveAnte, q.toggleProgressive()) : I.show(TEXT_ERROR_PROGRESSIVE)
    };
    this._gameOver = function() {
        J.show()
    };
    this.onRebet = function() {
        q.isResultPanelvisible() && (r = this.rebet, q.hideWinnnerPanel(), this._onEndHand())
    };
    this.onDeal = function() {
        if (b) k > PROGRESSIVE_LIMIT ? (I.show(TEXT_ERROR_PROG_LIMIT), q.enable(!1, !1, !1, !0)) : (r = this.onDeal, p.clearBet(), p.betAnte(k), q.hideWinnnerPanel(), this._onEndHand());
        else if (w.hide(), h = p.getBetAnte() * PAYOUT_MULT[GAP_11], p.getBetAnte() <
            MIN_BET) I.show(TEXT_ERROR_MIN_BET), q.enableBetFiches(!1), q.enable(!1, !1, !1);
        else {
            B.removeAllChildren();
            if ((n < h ? WIN_OCCURRENCE + 1 : Math.floor(101 * Math.random())) > WIN_OCCURRENCE) {
                do {
                    D = this._generateRandPlayerCards();
                    var a = E.evaluate(D)
                } while (a.win);
                c = !1
            } else {
                do D = this._generateRandPlayerCards(), a = E.evaluate(D); while (!a.win);
                c = !0
            }
            p.setPrevBet();
            u = a;
            this.changeState(STATE_GAME_DEALING)
        }
    };
    this.onCall = function() {
        v[2].showCard()
    };
    this.onRaise = function() {
        g !== STATE_GAME_DISTRIBUTE_FICHES && (this.setBet(BET_RAISE,
            q.getFicheSelected()), v[2].showCard())
    };
    this.onCollect = function() {
        p.increaseCredit(k);
        n -= k;
        this.distributeFiche()
    };
    this._generateRandPlayerCards = function() {
        for (var a = [], b = 0; 3 > b; b++) a.push({
            fotogram: z[m].fotogram,
            rank: z[m].rank,
            suit: z[m].suit
        }), m++, this._checkDeckLength();
        return a
    };
    this._checkDeckLength = function() {
        m >= z.length && (z = s_oGameSettings.getShuffledCardDeck(), m = 0)
    };
    this.clearBets = function() {
        if (g === STATE_GAME_WAITING_FOR_BET) {
            e = 0;
            q.enable(!1, !1, !1);
            var a = p.getStartingBet();
            0 < a && (p.clearBet(),
                p.increaseCredit(a), n -= a, q.refreshCredit(p.getCredit()), a = p.checkIfRebetIsPossible(), q.enableBetFiches(a))
        }
    };
    this.rebet = function() {
        this.clearBets();
        var a = p.rebet();
        n -= a;
        q.enable(!0, !1, !1);
        q.refreshCredit(p.getCredit())
    };
    this.onExit = function() {
        this.unload();
        $(s_oMain).trigger("end_session");
        $(s_oMain).trigger("share_event", p.getCredit());
        s_oMain.gotoMenu()
    };
    this.getState = function() {
        return g
    };
    this._updateDealing = function() {
        for (var a = 0; a < v.length; a++) v[a].update()
    };
    this._updateFiches = function() {
        p.updateFichesController()
    };
    this._updateShowWinner = function() {
        for (var a = 0; a < v.length; a++) v[a].update();
        e += s_iTimeElaps;
        e > TIME_END_HAND && (e = 0, a = p.checkIfRebetIsPossible(), this.reset(a), q.reset(), p.getCredit() < s_oGameSettings.getFichesValueAt(0) ? (this._gameOver(), this.changeState(-1)) : p.getCredit() < s_oGameSettings.getFichesValueAt(0) ? (this._gameOver(), this.changeState(-1)) : (this.changeState(STATE_GAME_WAITING_FOR_BET), r.call(this, 0, q.getFicheSelected())))
    };
    this.update = function() {
        if (!1 !== d) switch (g) {
            case STATE_GAME_WAITING_FOR_BET:
                e +=
                    s_iTimeElaps;
                6E3 < e && (e = 0, 0 < p.getBetAnte() && !w.isVisible() ? w.show(-1) : t.isVisible() || 0 !== p.getBetAnte() || t.show(1));
                break;
            case STATE_GAME_DEALING:
                this._updateDealing();
                break;
            case STATE_GAME_DISTRIBUTE_FICHES:
                this._updateFiches();
                break;
            case STATE_GAME_SHOW_WINNER:
                this._updateShowWinner()
        }
    };
    s_oGame = this;
    TOTAL_MONEY = a.money;
    MIN_BET = a.min_bet;
    MAX_BET = a.max_bet;
    WIN_OCCURRENCE = a.win_occurrence;
    BET_OCCURRENCE = a.bet_occurrence;
    n = a.game_cash;
    s_bProgressiveAnte = a.progressive_bet;
    PROGRESSIVE_LIMIT = a.progressive_limit;
    TIME_END_HAND = a.time_show_hand;
    ENABLE_FULLSCREEN = a.fullscreen;
    AD_SHOW_COUNTER = a.ad_show_counter;
    this._init()
}
var s_bProgressiveAnte, s_oGame, s_oTweenController;

function CInterface(a) {
    var d, c, b, e, f, g, m, l, n, h, k = null,
        x = null,
        r, u, v, z, D, G, A, C = null,
        H, F, B, E, q, p;
    this._init = function(a) {
        var t = s_oSpriteLibrary.getSprite("but_exit");
        b = CANVAS_WIDTH - t.width / 2 - 10;
        e = t.height / 2 + 10;
        n = new CGfxButton(b, e, t, s_oStage);
        n.addEventListener(ON_MOUSE_UP, this._onExit, this);
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) f = n.getX() - t.width - 10, g = t.height / 2 + 10, C = new CToggle(f, g, s_oSpriteLibrary.getSprite("audio_icon"), s_bAudioActive, !0), C.addEventListener(ON_MOUSE_UP, this._onAudioToggle,
            this);
        var t = window.document,
            w = t.documentElement;
        k = w.requestFullscreen || w.mozRequestFullScreen || w.webkitRequestFullScreen || w.msRequestFullscreen;
        x = t.exitFullscreen || t.mozCancelFullScreen || t.webkitExitFullscreen || t.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (k = !1);
        k && !1 === inIframe() && (t = s_oSpriteLibrary.getSprite("but_fullscreen"), d = null === C ? n.getX() - t.width / 2 - 10 : f - t.width / 2 - 10, c = t.height / 2 + 10, h = new CToggle(d, c, t, s_bFullscreen, !0), h.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        t = createBitmap(s_oSpriteLibrary.getSprite("display_bg"));
        t.x = 290;
        t.y = 6;
        s_oStage.addChild(t);
        t = s_oSpriteLibrary.getSprite("gui_bg");
        w = createBitmap(t);
        w.y = CANVAS_HEIGHT - t.height;
        s_oStage.addChild(w);
        t = s_oSpriteLibrary.getSprite("but_clear");
        r = new CGfxButton(830, CANVAS_HEIGHT - t.height / 2, t, s_oStage);
        r.addEventListener(ON_MOUSE_UP, this._onButClearRelease, this);
        t = s_oSpriteLibrary.getSprite("but_rebet");
        u = new CGfxButton(890, CANVAS_HEIGHT - t.height / 2, t, s_oStage);
        u.disable();
        u.addEventListener(ON_MOUSE_UP, this._onButRebetRelease, this);
        t = s_oSpriteLibrary.getSprite("but_generic");
        z = new CTextButton(1012, CANVAS_HEIGHT - t.height / 2, t, TEXT_DEAL, FONT_GAME_1, "#ffffff", 30, s_oStage);
        z.addEventListener(ON_MOUSE_UP, this._onButDealRelease, this);
        D = new CTextButton(1380, CANVAS_HEIGHT - t.height / 2, t, TEXT_RAISE, FONT_GAME_1, "#ffffff", 30, s_oStage);
        D.addEventListener(ON_MOUSE_UP, this._onButRaiseRelease, this);
        G = new CTextButton(1196, CANVAS_HEIGHT - t.height / 2, t, TEXT_CALL, FONT_GAME_1, "#ffffff", 30, s_oStage);
        G.addEventListener(ON_MOUSE_UP, this._onButCallRelease, this);
        A = new CTextButton(1196, CANVAS_HEIGHT -
            t.height / 2, t, TEXT_COLLECT, FONT_GAME_1, "#ffffff", 30, s_oStage);
        A.setVisible(!1);
        A.addEventListener(ON_MOUSE_UP, this._onButCollectRelease, this);
        POS_BET[BET_ANTE] = {
            x: CANVAS_WIDTH / 2 - 100,
            y: 600
        };
        POS_BET[BET_RAISE] = {
            x: CANVAS_WIDTH / 2 + 100,
            y: 600
        };
        v = new CGfxButton(POS_BET[BET_ANTE].x, POS_BET[BET_ANTE].y, s_oSpriteLibrary.getSprite("bet_ante"), s_oStage);
        v.addEventListener(ON_MOUSE_UP, this._onButAnteRelease, this);
        w = new createjs.Text(TEXT_PROGRESSIVE, "14px " + FONT_GAME_1, "#ffde00");
        w.x = 502;
        w.y = 496;
        w.textAlign = "left";
        s_oStage.addChild(w);
        H = new CToggle(480, 504, s_oSpriteLibrary.getSprite("toggle_progressive"), s_bProgressiveAnte, !1);
        H.addEventListener(ON_MOUSE_UP, this._onToggleProgressiveRelease, this);
        var w = s_oSpriteLibrary.getSprite("bet_raise"),
            y = createBitmap(w);
        y.x = POS_BET[BET_RAISE].x;
        y.y = POS_BET[BET_RAISE].y;
        y.regX = w.width / 2;
        y.regY = w.height / 2;
        s_oStage.addChild(y);
        B = new createjs.Text("", "24px " + FONT_GAME_2, "#ffde00");
        B.x = 402;
        B.y = 16;
        B.lineWidth = 210;
        B.textAlign = "left";
        B.lineHeight = 20;
        s_oStage.addChild(B);
        E = new createjs.Text("",
            "19px " + FONT_GAME_2, "#ffde00");
        E.x = 402;
        E.y = 46;
        E.lineWidth = 210;
        E.textAlign = "left";
        E.lineHeight = 18;
        s_oStage.addChild(E);
        w = new createjs.Text(TEXT_MONEY + ":", "30px " + FONT_GAME_2, "#ffde00");
        w.x = 320;
        w.y = CANVAS_HEIGHT - 84;
        w.textAlign = "left";
        s_oStage.addChild(w);
        F = new createjs.Text(TEXT_CURRENCY + a.toFixed(3), "30px " + FONT_GAME_2, "#ffde00");
        F.x = 410;
        F.y = CANVAS_HEIGHT - 84;
        F.textAlign = "left";
        s_oStage.addChild(F);
        a = [{
            x: 337,
            y: CANVAS_HEIGHT - 24
        }, {
            x: 417,
            y: CANVAS_HEIGHT - 24
        }, {
            x: 497,
            y: CANVAS_HEIGHT - 24
        }, {
            x: 577,
            y: CANVAS_HEIGHT -
                24
        }, {
            x: 657,
            y: CANVAS_HEIGHT - 24
        }, {
            x: 737,
            y: CANVAS_HEIGHT - 24
        }];
        l = [];
        w = s_oGameSettings.getFichesValues();
        for (y = 0; y < NUM_FICHES; y++) t = s_oSpriteLibrary.getSprite("fiche_" + y), l[y] = new CGfxButton(a[y].x, a[y].y, t, s_oStage), l[y].addEventListenerWithParams(ON_MOUSE_UP, this._onFicheClicked, this, [w[y], y]);
        a = s_oSpriteLibrary.getSprite("fiche_highlight");
        q = createBitmap(a);
        q.regX = a.width / 2;
        q.regY = a.height / 2;
        q.x = l[0].getX();
        q.y = l[0].getY();
        s_oStage.addChild(q);
        m = 0;
        FICHE_WIDTH = t.width;
        p = new CAnimText(CANVAS_WIDTH, CANVAS_HEIGHT,
            s_oStage);
        this.disableButtons();
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.unload = function() {
        n.unload();
        n = null;
        !1 === DISABLE_SOUND_MOBILE && (C.unload(), C = null);
        r.unload();
        z.unload();
        u.unload();
        k && !1 === inIframe() && h.unload();
        s_oInterface = null
    };
    this.refreshButtonPos = function(a, m) {
        n.setPosition(b - a, m + e);
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || C.setPosition(f - a, m + g);
        k && !1 === inIframe() && h.setPosition(d - a, c + m)
    };
    this.reset = function() {
        this.disableButtons()
    };
    this.enableBetFiches = function(a) {
        for (var b =
                0; b < NUM_FICHES; b++) l[b].enable();
        r.enable();
        v.enable();
        a && u.enable()
    };
    this.disableBetFiches = function() {
        for (var a = 0; a < NUM_FICHES; a++) l[a].disable();
        r.disable();
        u.disable();
        v.disable()
    };
    this.disableButtons = function() {
        z.disable();
        G.disable();
        D.disable();
        A.disable()
    };
    this.enable = function(a, b, c, d) {
        a ? z.enable() : z.disable();
        b ? D.enable() : (D.setVisible(!1), D.disable());
        c ? G.enable() : (G.setVisible(!1), G.disable());
        d ? A.enable() : (A.setVisible(!1), A.disable())
    };
    this.refreshCredit = function(a) {
        F.text = TEXT_CURRENCY +
            a.toFixed(3)
    };
    this.displayMsg = function(a, b) {
        B.text = a;
        E.text = b
    };
    this.hideWinnnerPanel = function() {
        p.hide()
    };
    this._onFicheClicked = function(a) {
        q.x = l[a[1]].getX();
        q.y = l[a[1]].getY();
        m = a[1]
    };
    this.showResultText = function(a) {
        p.show({
            x: -200,
            y: CANVAS_HEIGHT / 2 - 200
        }, {
            x: CANVAS_WIDTH / 2 - 326,
            y: CANVAS_HEIGHT / 2 - 200
        }, a)
    };
    this.toggleProgressive = function() {
        H.setActive(s_bProgressiveAnte)
    };
    this._onButClearRelease = function() {
        s_oGame.clearBets()
    };
    this._onButRebetRelease = function() {
        u.disable();
        s_oGame.onRebet()
    };
    this._onButAnteRelease =
        function() {
            s_oGame.setBet(BET_ANTE, m)
        };
    this._onButDealRelease = function() {
        this.disableBetFiches();
        this.disableButtons();
        s_oGame.onDeal()
    };
    this._onButRaiseRelease = function() {
        this.disableButtons();
        s_oGame.onRaise()
    };
    this._onButCallRelease = function() {
        this.disableButtons();
        s_oGame.onCall()
    };
    this._onButCollectRelease = function() {
        this.disableButtons();
        s_oGame.onCollect()
    };
    this._onToggleProgressiveRelease = function() {
        s_oGame.toggleProgressive()
    };
    this._onExit = function() {
        s_oGame.onExit()
    };
    this._onAudioToggle =
        function() {
            createjs.Sound.setMute(s_bAudioActive);
            s_bAudioActive = !s_bAudioActive
        };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? (x.call(window.document), s_bFullscreen = !1) : (k.call(window.document.documentElement), s_bFullscreen = !0);
        sizeHandler()
    };
    this.getFicheSelected = function() {
        return m
    };
    this.isResultPanelvisible = function() {
        return p.isVisible()
    };
    s_oInterface = this;
    this._init(a);
    return this
}
var s_oInterface = null;

function CTweenController() {
    this.tweenValue = function(a, d, c) {
        return a + c * (d - a)
    };
    this.easeLinear = function(a, d, c, b) {
        return c * a / b + d
    };
    this.easeInCubic = function(a, d, c, b) {
        b = (a /= b) * a * a;
        return d + c * b
    };
    this.easeBackInQuart = function(a, d, c, b) {
        b = (a /= b) * a;
        return d + c * (2 * b * b + 2 * b * a + -3 * b)
    };
    this.easeInBack = function(a, d, c, b) {
        return c * (a /= b) * a * (2.70158 * a - 1.70158) + d
    };
    this.easeOutCubic = function(a, d, c, b) {
        return c * ((a = a / b - 1) * a * a + 1) + d
    }
}

function CSeat() {
    var a, d, c, b, e, f, g, m, l, n, h;
    this._init = function() {
        l = new createjs.Container;
        l.x = CANVAS_WIDTH / 2 - 80;
        l.y = 223;
        s_oStage.addChild(l);
        h = [];
        for (var b = 0; 2 > b; b++) h[b] = new CFichesController;
        d = a = e = 0;
        g = [];
        g[0] = {
            x: l.x,
            y: l.y
        };
        g[1] = {
            x: l.x + 2 * CARD_WIDTH + 28,
            y: l.y
        };
        g[2] = {
            x: l.x + CARD_WIDTH + 14,
            y: l.y
        };
        this.reset();
        n = new CVector2;
        n.set(0, 0);
        m = new CVector2(n.getX(), n.getY())
    };
    this.unload = function() {
        s_oStage.removeChild(l)
    };
    this.addEventListener = function(a, b, c) {};
    this.reset = function(a) {
        b = 0;
        if (!1 === a) {
            for (a = 0; a <
                h.length; a++) h[a].reset();
            f = [];
            for (a = 0; 2 > a; a++) f[a] = []
        }
    };
    this.clearBet = function() {
        d = a = 0;
        f = [];
        for (var b = 0; b < h.length; b++) h[b].reset(), f[b] = []
    };
    this.resetBet = function() {
        for (var b = d = a = 0; b < h.length; b++) h[b].reset();
        f = [];
        for (b = 0; 2 > b; b++) f[b] = []
    };
    this.setCredit = function(a) {
        e = a
    };
    this.increaseCredit = function(a) {
        e += a;
        e = parseFloat(e.toFixed(2))
    };
    this.betAnte = function(b) {
        a += b;
        h[0].createFichesPile(a, POS_BET[0].x, POS_BET[0].y)
    };
    this.betRaise = function() {
        d = a;
        h[1].createFichesPile(d, POS_BET[1].x, POS_BET[1].y)
    };
    this.setPrevBet = function() {
        c = a
    };
    this.decreaseCredit = function(a) {
        e -= a;
        e = parseFloat(e.toFixed(2))
    };
    this.refreshFiches = function(a, b, c, d, e) {
        f[e].push({
            value: a,
            index: b
        });
        h[e].refreshFiches(f[e], c, d)
    };
    this.initMovement = function(a, b) {
        for (var c = 0; c < h.length; c++) h[c].initMovement(a, b)
    };
    this.newCardDealed = function() {
        b++
    };
    this.rebet = function() {
        d = 0;
        a = c;
        this.decreaseCredit(c);
        h[BET_ANTE].createFichesPile(c, POS_BET[BET_ANTE].x, POS_BET[BET_ANTE].y);
        return c
    };
    this.checkIfRebetIsPossible = function() {
        for (var a = 0, b =
                0; b < h.length; b++) var c = parseFloat(h[b].getPrevBet().toFixed(2)),
            a = a + c;
        return a > e ? !1 : !0
    };
    this.updateFichesController = function() {
        for (var a = 0; a < h.length; a++) h[a].update()
    };
    this.getAttachCardOffset = function() {
        m.set(g[b].x, g[b].y);
        return m
    };
    this.getBetAnte = function() {
        return a
    };
    this.getBetRaise = function() {
        return d
    };
    this.getCredit = function() {
        return e
    };
    this.getCardOffset = function() {
        return n
    };
    this.getStartingBet = function() {
        for (var a = 0, b = 0; b < h.length; b++) a += h[b].getValue();
        return a
    };
    this._init()
}

function CFichesController() {
    var a, d, c, b, e, f, g, m, l, n;
    this._init = function() {
        m = new createjs.Container;
        s_oStage.addChild(m);
        e = new CVector2;
        e.set(m.x, m.y);
        l = new createjs.Container;
        s_oStage.addChild(l);
        n = new createjs.Text("", "28px " + FONT_GAME_1, "#fff");
        n.textAlign = "center";
        n.shadow = new createjs.Shadow("#000000", 2, 2, 2);
        l.addChild(n);
        c = b = d = 0;
        a = !1
    };
    this.addEventListener = function(a, b, c) {};
    this.reset = function() {
        a = !1;
        c = 0;
        m.removeAllChildren();
        m.x = e.getX();
        m.y = e.getY();
        n.text = ""
    };
    this.setPrevValue = function(a) {
        b =
            a
    };
    this.refreshFiches = function(a, b, d) {
        a = a.sortOn("value", "index");
        for (var e = b, f = d + 10, h = c = 0, g = 0; g < a.length; g++) {
            var k = s_oSpriteLibrary.getSprite("fiche_" + a[g].index),
                k = createBitmap(k);
            k.scaleX = .7;
            k.scaleY = .7;
            m.addChild(k);
            k.x = e - 12;
            k.y = f;
            f -= 5;
            h++;
            9 < h && (h = 0, e += FICHE_WIDTH, f = d);
            c += a[g].value
        }
        playSound("chip", 1, 0);
        n.x = b;
        n.y = d + 35;
        n.text = c.toFixed(2) + TEXT_CURRENCY
    };
    this.createFichesPile = function(a, b, c) {
        this.reset();
        var d = s_oGameSettings.getFichesValues(),
            e = [];
        do {
            for (var f = d[d.length - 1], g = d.length - 1; f > a;) g--,
                f = d[g];
            for (var g = Math.floor(a / f), h = 0; h < g; h++) e.push({
                value: f,
                index: s_oGameSettings.getIndexForFiches(f)
            });
            f = Math.floor(a / f) === a / f ? 0 : a % f;
            a = f.toFixed(2)
        } while (0 < f);
        this.refreshFiches(e, b, c)
    };
    this.initMovement = function(d, e) {
        b = c;
        f = new CVector2(m.x, m.y);
        g = new CVector2(d, e);
        a = !0
    };
    this.getValue = function() {
        return c
    };
    this.getPrevBet = function() {
        return b
    };
    this.update = function() {
        if (a)
            if (d += s_iTimeElaps, d > TIME_FICHES_MOV) d = 0, a = !1;
            else {
                n.text = "";
                var b = easeInOutCubic(d, 0, 1, TIME_FICHES_MOV),
                    c = new CVector2,
                    c = tweenVectors(f,
                        g, b, c);
                m.x = c.getX();
                m.y = c.getY()
            }
    };
    this._init()
}

function CVector2(a, d) {
    var c, b;
    this._init = function(a, d) {
        c = a;
        b = d
    };
    this.add = function(a, d) {
        c += a;
        b += d
    };
    this.addV = function(a) {
        c += a.getX();
        b += a.getY()
    };
    this.scalarDivision = function(a) {
        c /= a;
        b /= a
    };
    this.subV = function(a) {
        c -= a.getX();
        b -= a.getY()
    };
    this.scalarProduct = function(a) {
        c *= a;
        b *= a
    };
    this.invert = function() {
        c *= -1;
        b *= -1
    };
    this.dotProduct = function(a) {
        return c * a.getX() + b * a.getY()
    };
    this.set = function(a, d) {
        c = a;
        b = d
    };
    this.setV = function(a) {
        c = a.getX();
        b = a.getY()
    };
    this.length = function() {
        return Math.sqrt(c * c + b * b)
    };
    this.length2 =
        function() {
            return c * c + b * b
        };
    this.normalize = function() {
        var a = this.length();
        0 < a && (c /= a, b /= a)
    };
    this.getNormalize = function(a) {
        this.length();
        a.set(c, b);
        a.normalize()
    };
    this.rot90CCW = function() {
        var a = c;
        c = -b;
        b = a
    };
    this.rot90CW = function() {
        var a = c;
        c = b;
        b = -a
    };
    this.getRotCCW = function(a) {
        a.set(c, b);
        a.rot90CCW()
    };
    this.getRotCW = function(a) {
        a.set(c, b);
        a.rot90CW()
    };
    this.ceil = function() {
        c = Math.ceil(c);
        b = Math.ceil(b)
    };
    this.round = function() {
        c = Math.round(c);
        b = Math.round(b)
    };
    this.toString = function() {
        return "Vector2: " + c + ", " +
            b
    };
    this.print = function() {
        trace("Vector2: " + c + ", " + b + "")
    };
    this.getX = function() {
        return c
    };
    this.getY = function() {
        return b
    };
    this._init(a, d)
}

function CGameSettings() {
    var a, d, c, b;
    this._init = function() {
        var b = -1;
        a = [];
        for (var d = 0; 52 > d; d++) {
            var g = (d + 1) % 13;
            1 === g ? (g = 14, b++) : 0 === g && (g = 13);
            a.push({
                fotogram: d,
                rank: g,
                suit: b
            })
        }
        c = [.1, 1, 5, 10, 25, 100];
        this._initPuckPos();
        this._initPayouts()
    };
    this._initPuckPos = function() {
        b = [];
        b[GAP_1] = {
            x: 494,
            y: 414
        };
        b[GAP_2] = {
            x: 548,
            y: 414
        };
        b[GAP_3] = {
            x: 604,
            y: 414
        };
        b[GAP_4] = {
            x: 660,
            y: 414
        };
        b[GAP_5] = {
            x: 716,
            y: 414
        };
        b[GAP_6] = {
            x: 770,
            y: 414
        };
        b[GAP_7] = {
            x: 826,
            y: 414
        };
        b[GAP_8] = {
            x: 882,
            y: 414
        };
        b[GAP_9] = {
            x: 936,
            y: 414
        };
        b[GAP_10] = {
            x: 992,
            y: 414
        };
        b[GAP_11] = {
            x: 1048,
            y: 414
        };
        b[GAP_12] = {
            x: 1048,
            y: 414
        };
        b[CONSECUTIVE_RANK] = {
            x: 1104,
            y: 414
        };
        b[PAIR_RANK] = {
            x: 1158,
            y: 414
        };
        b[THREE_OF_A_KIND] = {
            x: 1213,
            y: 414
        }
    };
    this._initPayouts = function() {
        PAYOUT_MULT[GAP_1] = 5;
        PAYOUT_MULT[GAP_2] = 4;
        PAYOUT_MULT[GAP_3] = 2;
        PAYOUT_MULT[GAP_4] = 1;
        PAYOUT_MULT[GAP_5] = 1;
        PAYOUT_MULT[GAP_6] = 1;
        PAYOUT_MULT[GAP_7] = 1;
        PAYOUT_MULT[GAP_8] = 1;
        PAYOUT_MULT[GAP_9] = 1;
        PAYOUT_MULT[GAP_10] = 1;
        PAYOUT_MULT[GAP_11] = 1;
        PAYOUT_MULT[GAP_12] = 1;
        PAYOUT_MULT[CONSECUTIVE_RANK] = 0;
        PAYOUT_MULT[PAIR_RANK] = 0;
        PAYOUT_MULT[THREE_OF_A_KIND] =
            11
    };
    this.getFichesValues = function() {
        return c
    };
    this.getFichesValueAt = function(a) {
        return c[a]
    };
    this.getIndexForFiches = function(a) {
        for (var b = 0, d = 0; d < c.length; d++) c[d] === a && (b = d);
        return b
    };
    this.generateFichesPile = function(a) {
        var b = [],
            d, e = c.length - 1,
            l = c[e];
        do {
            d = a % l;
            d = CMath.roundDecimal(d, 1);
            a = Math.floor(a / l);
            for (var n = 0; n < a; n++) b.push(l);
            e--;
            l = c[e];
            a = d
        } while (0 < d && -1 < e);
        return b
    };
    this.getShuffledCardDeck = function() {
        for (var b = [], c = 0; c < a.length; c++) b[c] = a[c];
        for (d = []; 0 < b.length;) d.push(b.splice(Math.round(Math.random() *
            (b.length - 1)), 1)[0]);
        return d
    };
    this.getCardDeck = function() {
        return a
    };
    this.getPuckPos = function(a) {
        return b[a]
    };
    this._init()
}
var TYPE_LINEAR = 0,
    TYPE_OUT_CUBIC = 1,
    TYPE_IN_CUBIC = 2,
    TYPE_OUT_BACK = 3,
    TYPE_IN_BACK = 4;

function ease(a, d, c, b, e, f) {
    var g;
    switch (a) {
        case TYPE_LINEAR:
            g = easeLinear(d, c, b, e, f);
            break;
        case TYPE_IN_CUBIC:
            g = easeInCubic(d, c, b, e, f);
            break;
        case TYPE_OUT_CUBIC:
            g = easeOutCubic(d, c, b, e, f);
            break;
        case TYPE_IN_BACK:
            g = easeInBack(d, c, b, e, f);
            break;
        case TYPE_OUT_BACK:
            g = easeInBack(d, c, b, e, f)
    }
    return g
}

function easeOutBounce(a, d, c, b) {
    return (a /= b) < 1 / 2.75 ? 7.5625 * c * a * a + d : a < 2 / 2.75 ? c * (7.5625 * (a -= 1.5 / 2.75) * a + .75) + d : a < 2.5 / 2.75 ? c * (7.5625 * (a -= 2.25 / 2.75) * a + .9375) + d : c * (7.5625 * (a -= 2.625 / 2.75) * a + .984375) + d
}

function easeInBounce(a, d, c, b) {
    return c - easeOutBounce(b - a, 0, c, b) + d
}

function easeInOutBounce(a, d, c, b) {
    return a < b / 2 ? .5 * easeInBounce(2 * a, 0, c, b) + d : .5 * easeOutBounce(2 * a - b, 0, c, b) + .5 * c + d
}

function easeInCirc(a, d, c, b) {
    return -c * (Math.sqrt(1 - (a /= b) * a) - 1) + d
}

function easeOutCirc(a, d, c, b) {
    return c * Math.sqrt(1 - (a = a / b - 1) * a) + d
}

function easeInOutCirc(a, d, c, b) {
    return 1 > (a /= b / 2) ? -c / 2 * (Math.sqrt(1 - a * a) - 1) + d : c / 2 * (Math.sqrt(1 - (a -= 2) * a) + 1) + d
}

function easeInCubic(a, d, c, b, e) {
    return c * (a /= b) * a * a + d
}

function easeOutCubic(a, d, c, b, e) {
    return c * ((a = a / b - 1) * a * a + 1) + d
}

function easeInOutCubic(a, d, c, b, e) {
    return 1 > (a /= b / 2) ? c / 2 * a * a * a + d : c / 2 * ((a -= 2) * a * a + 2) + d
}

function easeInElastic(a, d, c, b, e, f, g) {
    if (0 == a) return d;
    if (1 == (a /= b)) return d + c;
    g || (g = .3 * b);
    !f || f < Math.abs(c) ? (f = c, e = g / 4) : e = g / (2 * Math.PI) * Math.asin(c / f);
    return -(f * Math.pow(2, 10 * --a) * Math.sin(2 * (a * b - e) * Math.PI / g)) + d
}

function easeOutElastic(a, d, c, b, e, f, g) {
    if (0 == a) return d;
    if (1 == (a /= b)) return d + c;
    g || (g = .3 * b);
    !f || f < Math.abs(c) ? (f = c, e = g / 4) : e = g / (2 * Math.PI) * Math.asin(c / f);
    return f * Math.pow(2, -10 * a) * Math.sin(2 * (a * b - e) * Math.PI / g) + c + d
}

function easeInOutElastic(a, d, c, b, e, f, g) {
    if (0 == a) return d;
    if (1 == (a /= b)) return d + c;
    g || (g = .3 * b);
    !f || f < Math.abs(c) ? (f = c, e = g / 4) : e = g / (2 * Math.PI) * Math.asin(c / f);
    return 1 > a ? -.5 * f * Math.pow(2, 10 * --a) * Math.sin(2 * (a * b - e) * Math.PI / g) + d : f * Math.pow(2, -10 * --a) * Math.sin(2 * (a * b - e) * Math.PI / g) * .5 + c + d
}

function easeInExpo(a, d, c, b) {
    return 0 == a ? d : c * Math.pow(2, 10 * (a / b - 1)) + d
}

function easeOutExpo(a, d, c, b) {
    return a == b ? d + c : c * (-Math.pow(2, -10 * a / b) + 1) + d
}

function easeInOutExpo(a, d, c, b) {
    return 0 == a ? d : a == b ? d + c : 1 > (a /= b / 2) ? c / 2 * Math.pow(2, 10 * (a - 1)) + d : c / 2 * (-Math.pow(2, -10 * --a) + 2) + d
}

function easeLinear(a, d, c, b) {
    return c * a / b + d
}

function easeInQuad(a, d, c, b) {
    return c * (a /= b) * a + d
}

function easeOutQuad(a, d, c, b) {
    return -c * (a /= b) * (a - 2) + d
}

function easeInOutQuad(a, d, c, b) {
    return 1 > (a /= b / 2) ? c / 2 * a * a + d : -c / 2 * (--a * (a - 2) - 1) + d
}

function easeInQuart(a, d, c, b) {
    return c * (a /= b) * a * a * a + d
}

function easeOutQuart(a, d, c, b) {
    return -c * ((a = a / b - 1) * a * a * a - 1) + d
}

function easeInOutQuart(a, d, c, b) {
    return 1 > (a /= b / 2) ? c / 2 * a * a * a * a + d : -c / 2 * ((a -= 2) * a * a * a - 2) + d
}

function easeInQuint(a, d, c, b) {
    return c * (a /= b) * a * a * a * a + d
}

function easeOutQuint(a, d, c, b) {
    return c * ((a = a / b - 1) * a * a * a * a + 1) + d
}

function easeInOutQuint(a, d, c, b) {
    return 1 > (a /= b / 2) ? c / 2 * a * a * a * a * a + d : c / 2 * ((a -= 2) * a * a * a * a + 2) + d
}

function easeInSine(a, d, c, b) {
    return -c * Math.cos(a / b * (Math.PI / 2)) + c + d
}

function easeOutSine(a, d, c, b) {
    return c * Math.sin(a / b * (Math.PI / 2)) + d
}

function easeInOutSine(a, d, c, b) {
    return -c / 2 * (Math.cos(Math.PI * a / b) - 1) + d
}

function easeInBack(a, d, c, b) {
    return c * (a /= b) * a * (2.70158 * a - 1.70158) + d
}

function easeOutBack(a, d, c, b) {
    return c * ((a = a / b - 1) * a * (2.70158 * a + 1.70158) + 1) + d
}

function CCard(a, d, c) {
    var b, e = -1,
        f, g, m, l, n, h, k, x, r, u;
    this._init = function(a, b, c) {
        u = c;
        c = {
            images: [s_oSpriteLibrary.getSprite("card_spritesheet")],
            frames: {
                width: CARD_WIDTH,
                height: CARD_HEIGHT,
                regX: CARD_WIDTH / 2,
                regY: CARD_HEIGHT / 2
            },
            animations: {
                card_1_1: [0],
                card_1_2: [1],
                card_1_3: [2],
                card_1_4: [3],
                card_1_5: [4],
                card_1_6: [5],
                card_1_7: [6],
                card_1_8: [7],
                card_1_9: [8],
                card_1_10: [9],
                card_1_J: [10],
                card_1_Q: [11],
                card_1_K: [12],
                card_2_1: [13],
                card_2_2: [14],
                card_2_3: [15],
                card_2_4: [16],
                card_2_5: [17],
                card_2_6: [18],
                card_2_7: [19],
                card_2_8: [20],
                card_2_9: [21],
                card_2_10: [22],
                card_2_J: [23],
                card_2_Q: [24],
                card_2_K: [25],
                card_3_1: [26],
                card_3_2: [27],
                card_3_3: [28],
                card_3_4: [29],
                card_3_5: [30],
                card_3_6: [31],
                card_3_7: [32],
                card_3_8: [33],
                card_3_9: [34],
                card_3_10: [35],
                card_3_J: [36],
                card_3_Q: [37],
                card_3_K: [38],
                card_4_1: [39],
                card_4_2: [40],
                card_4_3: [41],
                card_4_4: [42],
                card_4_5: [43],
                card_4_6: [44],
                card_4_7: [45],
                card_4_8: [46],
                card_4_9: [47],
                card_4_10: [48],
                card_4_J: [49],
                card_4_Q: [50],
                card_4_K: [51],
                back: [52]
            }
        };
        c = new createjs.SpriteSheet(c);
        r = createSprite(c,
            "back", CARD_WIDTH / 2, CARD_HEIGHT / 2, CARD_WIDTH, CARD_HEIGHT);
        r.x = a;
        r.y = b;
        r.rotation = 120;
        r.stop();
        u.addChild(r);
        k = [];
        x = []
    };
    this.unload = function() {
        h = n = null;
        u.removeChild(r)
    };
    this.addEventListener = function(a, b, c) {
        k[a] = b;
        x[a] = c
    };
    this.setInfo = function(a, c, d, k, r) {
        b = !1;
        l = 0;
        f = d;
        g = k;
        n = a;
        h = c;
        m = r;
        e = STATE_CARD_DEALING
    };
    this.initRemoving = function(a) {
        n = new CVector2(r.x, r.y);
        h = a;
        l = 0;
        e = STATE_CARD_REMOVING
    };
    this.setValue = function() {
        r.gotoAndStop(f);
        var a = this;
        createjs.Tween.get(r).to({
            scaleX: 1
        }, 100).call(function() {
            a.cardShown()
        })
    };
    this.showCard = function() {
        var a = this;
        createjs.Tween.get(r).to({
            scaleX: .1
        }, 100).call(function() {
            a.setValue()
        })
    };
    this.hideCard = function() {
        var a = this;
        createjs.Tween.get(r).to({
            scaleX: .1
        }, 100).call(function() {
            a.setBack()
        })
    };
    this.setBack = function() {
        r.gotoAndStop("back");
        var a = this;
        createjs.Tween.get(r).to({
            scaleX: 1
        }, 100).call(function() {
            a.cardHidden()
        })
    };
    this.cardShown = function() {
        k[ON_CARD_SHOWN] && k[ON_CARD_SHOWN].call(x[ON_CARD_SHOWN])
    };
    this.cardHidden = function() {
        b = !0
    };
    this.changePos = function(a) {
        createjs.Tween.get(r).to({
            x: a.x,
            y: a.y
        }, 500).call(function() {
            n = a
        })
    };
    this.getValue = function() {
        return g
    };
    this.getFotogram = function() {
        return f
    };
    this.getCurPos = function() {
        return {
            x: r.x,
            y: r.y
        }
    };
    this.getSprite = function() {
        return r
    };
    this._updateDealing = function() {
        l += s_iTimeElaps;
        if (l > TIME_CARD_DEALING) e = -1, l = 0, r.x = h.getX(), r.y = h.getY(), r.rotation = 360, k[ON_CARD_ANIMATION_ENDING] && k[ON_CARD_ANIMATION_ENDING].call(x[ON_CARD_ANIMATION_ENDING], this, m);
        else {
            this.visible = !0;
            var a = easeInOutCubic(l, 0, 1, TIME_CARD_DEALING),
                b = new CVector2,
                b = tweenVectors(n,
                    h, a, b);
            r.x = b.getX();
            r.y = b.getY();
            r.rotation = 120 + 24E3 * a / 100
        }
    };
    this._updateRemoving = function() {
        l += s_iTimeElaps;
        if (l > TIME_CARD_REMOVE) l = 0, b = !1, e = -1, this.unload();
        else {
            var a = easeInOutCubic(l, 0, 1, TIME_CARD_REMOVE),
                c = new CVector2,
                c = tweenVectors(n, h, a, c);
            r.x = c.getX();
            r.y = c.getY();
            r.rotation = 4500 * a / 100
        }
    };
    this.update = function() {
        switch (e) {
            case STATE_CARD_DEALING:
                this._updateDealing();
                break;
            case STATE_CARD_REMOVING:
                !0 === b && this._updateRemoving()
        }
    };
    s_oCard = this;
    this._init(a, d, c)
}
var s_oCard;

function CGameOver() {
    var a, d, c, b;
    this._init = function() {
        b = new createjs.Container;
        s_oStage.addChild(b);
        b.on("click", function() {});
        var e = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        b.addChild(e);
        a = new createjs.Text(TEXT_NO_MONEY, "32px " + FONT_GAME_1, "#fff");
        a.textAlign = "center";
        a.x = CANVAS_WIDTH / 2;
        a.y = 290;
        a.lineWidth = 300;
        a.shadow = new createjs.Shadow("#000000", 2, 2, 2);
        b.addChild(a);
        d = new CTextButton(CANVAS_WIDTH / 2 - 100, 450, s_oSpriteLibrary.getSprite("but_game_bg"), TEXT_RECHARGE, FONT_GAME_1, "#fff",
            16, b);
        d.addEventListener(ON_MOUSE_UP, this._onRecharge, this);
        c = new CTextButton(CANVAS_WIDTH / 2 + 100, 450, s_oSpriteLibrary.getSprite("but_game_bg"), TEXT_EXIT, FONT_GAME_1, "#fff", 20, b);
        c.addEventListener(ON_MOUSE_UP, this._onExit, this);
        this.hide()
    };
    this.unload = function() {
        d.unload();
        c.unload();
        b.off("click", function() {})
    };
    this.show = function() {
        b.visible = !0;
        $(s_oMain).trigger("end_session")
    };
    this.hide = function() {
        b.visible = !1
    };
    this._onRecharge = function() {
        $(s_oMain).trigger("recharge")
    };
    this._onExit = function() {
        s_oGame.onExit()
    };
    this._init()
}

function CMsgBox() {
    var a, d, c, b;
    this._init = function() {
        a = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        c = new createjs.Text("", "34px " + FONT_GAME_1, "#000");
        c.x = CANVAS_WIDTH / 2 + 2;
        c.y = CANVAS_HEIGHT / 2 - 28;
        c.textAlign = "center";
        c.lineWidth = 400;
        c.textBaseline = "middle";
        d = new createjs.Text("", "34px " + FONT_GAME_1, "#ffffff");
        d.x = CANVAS_WIDTH / 2;
        d.y = CANVAS_HEIGHT / 2 - 30;
        d.textAlign = "center";
        d.lineWidth = 400;
        d.textBaseline = "middle";
        b = new createjs.Container;
        b.alpha = 0;
        b.visible = !1;
        b.addChild(a, c, d);
        s_oStage.addChild(b)
    };
    this.unload =
        function() {
            b.off("mousedown", this._onExit)
        };
    this._initListener = function() {
        b.on("mousedown", this._onExit)
    };
    this.show = function(a) {
        c.text = a;
        d.text = a;
        b.visible = !0;
        var e = this;
        createjs.Tween.get(b).to({
            alpha: 1
        }, 500).call(function() {
            e._initListener()
        });
        setTimeout(function() {
            e._onExit()
        }, 3E3)
    };
    this._onExit = function() {
        b.visible && (b.off("mousedown"), b.visible = !1)
    };
    this._init();
    return this
}

function CHandEvaluator() {
    this.evaluate = function(a) {
        if (1 === Math.abs(a[0].rank - a[1].rank)) return {
            win: !0,
            result: CONSECUTIVE_RANK
        };
        if (a[0].rank === a[1].rank) return a[2].rank === a[0].rank ? {
            win: !0,
            result: THREE_OF_A_KIND
        } : {
            win: !0,
            result: PAIR_RANK
        };
        var d = Math.abs(a[0].rank - a[1].rank),
            c = a[0].rank > a[1].rank ? [a[1].rank, a[0].rank] : [a[0].rank, a[1].rank];
        return a[2].rank > c[0] && a[2].rank < c[1] ? {
            win: !0,
            result: window["GAP_" + d]
        } : {
            win: !1,
            result: window["GAP_" + d]
        }
    }
}

function CAnimText(a, d, c) {
    var b, e, f, g;
    this._init = function(a, b) {
        f = new createjs.Container;
        f.visible = !1;
        f.x = a;
        f.y = b;
        g.addChild(f);
        var c = s_oSpriteLibrary.getSprite("win_bg"),
            d = createBitmap(c);
        f.addChild(d);
        e = new createjs.Text("", "28px " + FONT_GAME_1, "#fff");
        e.x = c.width / 2;
        e.y = 0;
        e.alphabetic = "middle";
        e.textAlign = "center";
        e.lineWidth = c.width;
        f.addChild(e)
    };
    this.show = function(a, c, d) {
        b = a;
        e.text = d;
        f.x = a.x;
        f.y = a.y;
        f.visible = !0;
        createjs.Tween.get(f).to({
            x: c.x,
            y: c.y
        }, 1E3, createjs.Ease.elasticOut)
    };
    this.hide = function() {
        createjs.Tween.get(f).to({
            x: b.x,
            y: b.y
        }, 500, createjs.Ease.cubicOut).call(function() {
            f.visible = !1;
            f.x = b.x;
            f.y = b.y
        })
    };
    this.isVisible = function() {
        return f.visible
    };
    g = c;
    this._init(a, d)
}

function CPuck(a, d, c) {
    var b, e, f;
    this._init = function() {
        b = a;
        var c = s_oSpriteLibrary.getSprite("puck");
        e = createBitmap(c);
        e.regX = c.width / 2;
        e.regY = c.height / 2;
        e.x = a;
        e.y = d;
        f.addChild(e)
    };
    this.move = function(a) {
        createjs.Tween.get(e).to({
            x: a
        }, 1E3, createjs.Ease.cubicOut)
    };
    this.resetPosition = function() {
        createjs.Tween.get(e).to({
            x: b
        }, 1E3, createjs.Ease.cubicOut)
    };
    f = c;
    this._init(a, d)
}

function CHelpCursor(a, d, c, b) {
    var e, f, g;
    this._init = function(a, c, d) {
        e = a;
        f = createBitmap(d);
        f.visible = !1;
        f.x = a;
        f.y = c;
        b.addChild(f)
    };
    this.show = function(a) {
        0 > a && (f.scaleX *= -1);
        this._move(a, e + 30 * a, 600);
        f.visible = !0
    };
    this.hide = function() {
        createjs.Tween.removeTweens(f);
        f.x = e;
        f.visible = !1
    };
    this._move = function(a, b, c) {
        var d;
        d = 0 < a ? createjs.Ease.cubicIn : createjs.Ease.cubicOut;
        createjs.Tween.get(f).to({
            x: b
        }, c, d).call(function() {
            a *= -1;
            g._move(a, b + 15 * a, 400)
        })
    };
    this.isVisible = function() {
        return f.visible
    };
    g = this;
    this._init(a,
        d, c)
};