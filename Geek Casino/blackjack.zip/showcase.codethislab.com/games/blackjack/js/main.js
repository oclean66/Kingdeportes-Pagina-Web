/*
 Platform.js <https://mths.be/platform>
 Copyright 2014-2018 Benjamin Tan <https://bnjmnt4n.now.sh/>
 Copyright 2011-2013 John-David Dalton
 Available under MIT license <https://mths.be/mit>
*/
(function() {
    function a(a) {
        a = String(a);
        return a.charAt(0).toUpperCase() + a.slice(1)
    }

    function d(a, b) {
        var d = -1,
            f = a ? a.length : 0;
        if ("number" == typeof f && -1 < f && f <= k)
            for (; ++d < f;) b(a[d], d, a);
        else c(a, b)
    }

    function b(b) {
        b = String(b).replace(/^ +| +$/g, "");
        return /^(?:webOS|i(?:OS|P))/.test(b) ? b : a(b)
    }

    function c(a, b) {
        for (var c in a) y.call(a, c) && b(a[c], c, a)
    }

    function f(b) {
        return null == b ? a(b) : B.call(b).slice(8, -1)
    }

    function e(a, b) {
        var c = null != a ? typeof a[b] : "number";
        return !/^(?:boolean|number|string|undefined)$/.test(c) &&
            ("object" == c ? !!a[b] : !0)
    }

    function h(a) {
        return String(a).replace(/([ -])(?!$)/g, "$1?")
    }

    function t(a, b) {
        var c = null;
        d(a, function(d, f) {
            c = b(c, d, f, a)
        });
        return c
    }

    function r(a) {
        function d(c) {
            return t(c, function(c, d) {
                var f = d.pattern || h(d);
                !c && (c = RegExp("\\b" + f + " *\\d+[.\\w_]*", "i").exec(a) || RegExp("\\b" + f + " *\\w+-[\\w]*", "i").exec(a) || RegExp("\\b" + f + "(?:; *(?:[a-z]+[_-])?[a-z]+\\d+|[^ ();-]*)", "i").exec(a)) && ((c = String(d.label && !RegExp(f, "i").test(d.label) ? d.label : c).split("/"))[1] && !/[\d.]+/.test(c[0]) && (c[0] +=
                    " " + c[1]), d = d.label || d, c = b(c[0].replace(RegExp(f, "i"), d).replace(RegExp("; *(?:" + d + "[_-])?", "i"), " ").replace(RegExp("(" + d + ")[-_.]?(\\w)", "i"), "$1 $2")));
                return c
            })
        }

        function n(b) {
            return t(b, function(b, c) {
                return b || (RegExp(c + "(?:-[\\d.]+/|(?: for [\\w-]+)?[ /-])([\\d.]+[^ ();/_-]*)", "i").exec(a) || 0)[1] || null
            })
        }
        var l = u,
            p = a && "object" == typeof a && "String" != f(a);
        p && (l = a, a = null);
        var q = l.navigator || {},
            k = q.userAgent || "";
        a || (a = k);
        var C = p ? !!q.likeChrome : /\bChrome\b/.test(a) && !/internal|\n/i.test(B.toString()),
            O = p ? "Object" : "ScriptBridgingProxyObject",
            A = p ? "Object" : "Environment",
            y = p && l.java ? "JavaPackage" : f(l.java),
            Q = p ? "Object" : "RuntimeObject";
        A = (y = /\bJava/.test(y) && l.java) && f(l.environment) == A;
        var V = y ? "a" : "\u03b1",
            T = y ? "b" : "\u03b2",
            U = l.document || {},
            z = l.operamini || l.opera,
            m = v.test(m = p && z ? z["[[Class]]"] : f(z)) ? m : z = null,
            g, R = a;
        p = [];
        var N = null,
            S = a == k;
        k = S && z && "function" == typeof z.version && z.version();
        var E = function(b) {
                return t(b, function(b, c) {
                    return b || RegExp("\\b" + (c.pattern || h(c)) + "\\b", "i").exec(a) && (c.label ||
                        c)
                })
            }([{
                label: "EdgeHTML",
                pattern: "Edge"
            }, "Trident", {
                label: "WebKit",
                pattern: "AppleWebKit"
            }, "iCab", "Presto", "NetFront", "Tasman", "KHTML", "Gecko"]),
            w = function(b) {
                return t(b, function(b, c) {
                    return b || RegExp("\\b" + (c.pattern || h(c)) + "\\b", "i").exec(a) && (c.label || c)
                })
            }(["Adobe AIR", "Arora", "Avant Browser", "Breach", "Camino", "Electron", "Epiphany", "Fennec", "Flock", "Galeon", "GreenBrowser", "iCab", "Iceweasel", "K-Meleon", "Konqueror", "Lunascape", "Maxthon", {
                    label: "Microsoft Edge",
                    pattern: "Edge"
                }, "Midori", "Nook Browser",
                "PaleMoon", "PhantomJS", "Raven", "Rekonq", "RockMelt", {
                    label: "Samsung Internet",
                    pattern: "SamsungBrowser"
                }, "SeaMonkey", {
                    label: "Silk",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Sleipnir", "SlimBrowser", {
                    label: "SRWare Iron",
                    pattern: "Iron"
                }, "Sunrise", "Swiftfox", "Waterfox", "WebPositive", "Opera Mini", {
                    label: "Opera Mini",
                    pattern: "OPiOS"
                }, "Opera", {
                    label: "Opera",
                    pattern: "OPR"
                }, "Chrome", {
                    label: "Chrome Mobile",
                    pattern: "(?:CriOS|CrMo)"
                }, {
                    label: "Firefox",
                    pattern: "(?:Firefox|Minefield)"
                }, {
                    label: "Firefox for iOS",
                    pattern: "FxiOS"
                },
                {
                    label: "IE",
                    pattern: "IEMobile"
                }, {
                    label: "IE",
                    pattern: "MSIE"
                }, "Safari"
            ]),
            F = d([{
                    label: "BlackBerry",
                    pattern: "BB10"
                }, "BlackBerry", {
                    label: "Galaxy S",
                    pattern: "GT-I9000"
                }, {
                    label: "Galaxy S2",
                    pattern: "GT-I9100"
                }, {
                    label: "Galaxy S3",
                    pattern: "GT-I9300"
                }, {
                    label: "Galaxy S4",
                    pattern: "GT-I9500"
                }, {
                    label: "Galaxy S5",
                    pattern: "SM-G900"
                }, {
                    label: "Galaxy S6",
                    pattern: "SM-G920"
                }, {
                    label: "Galaxy S6 Edge",
                    pattern: "SM-G925"
                }, {
                    label: "Galaxy S7",
                    pattern: "SM-G930"
                }, {
                    label: "Galaxy S7 Edge",
                    pattern: "SM-G935"
                }, "Google TV", "Lumia", "iPad",
                "iPod", "iPhone", "Kindle", {
                    label: "Kindle Fire",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Nexus", "Nook", "PlayBook", "PlayStation Vita", "PlayStation", "TouchPad", "Transformer", {
                    label: "Wii U",
                    pattern: "WiiU"
                }, "Wii", "Xbox One", {
                    label: "Xbox 360",
                    pattern: "Xbox"
                }, "Xoom"
            ]),
            P = function(b) {
                return t(b, function(b, c, d) {
                    return b || (c[F] || c[/^[a-z]+(?: +[a-z]+\b)*/i.exec(F)] || RegExp("\\b" + h(d) + "(?:\\b|\\w*\\d)", "i").exec(a)) && d
                })
            }({
                Apple: {
                    iPad: 1,
                    iPhone: 1,
                    iPod: 1
                },
                Archos: {},
                Amazon: {
                    Kindle: 1,
                    "Kindle Fire": 1
                },
                Asus: {
                    Transformer: 1
                },
                "Barnes & Noble": {
                    Nook: 1
                },
                BlackBerry: {
                    PlayBook: 1
                },
                Google: {
                    "Google TV": 1,
                    Nexus: 1
                },
                HP: {
                    TouchPad: 1
                },
                HTC: {},
                LG: {},
                Microsoft: {
                    Xbox: 1,
                    "Xbox One": 1
                },
                Motorola: {
                    Xoom: 1
                },
                Nintendo: {
                    "Wii U": 1,
                    Wii: 1
                },
                Nokia: {
                    Lumia: 1
                },
                Samsung: {
                    "Galaxy S": 1,
                    "Galaxy S2": 1,
                    "Galaxy S3": 1,
                    "Galaxy S4": 1
                },
                Sony: {
                    PlayStation: 1,
                    "PlayStation Vita": 1
                }
            }),
            x = function(c) {
                return t(c, function(c, d) {
                    var f = d.pattern || h(d);
                    if (!c && (c = RegExp("\\b" + f + "(?:/[\\d.]+|[ \\w.]*)", "i").exec(a))) {
                        var e = c,
                            g = d.label || d,
                            p = {
                                "10.0": "10",
                                "6.4": "10 Technical Preview",
                                "6.3": "8.1",
                                "6.2": "8",
                                "6.1": "Server 2008 R2 / 7",
                                "6.0": "Server 2008 / Vista",
                                "5.2": "Server 2003 / XP 64-bit",
                                "5.1": "XP",
                                "5.01": "2000 SP1",
                                "5.0": "2000",
                                "4.0": "NT",
                                "4.90": "ME"
                            };
                        f && g && /^Win/i.test(e) && !/^Windows Phone /i.test(e) && (p = p[/[\d.]+$/.exec(e)]) && (e = "Windows " + p);
                        e = String(e);
                        f && g && (e = e.replace(RegExp(f, "i"), g));
                        c = e = b(e.replace(/ ce$/i, " CE").replace(/\bhpw/i, "web").replace(/\bMacintosh\b/, "Mac OS").replace(/_PowerPC\b/i, " OS").replace(/\b(OS X) [^ \d]+/i, "$1").replace(/\bMac (OS X)\b/, "$1").replace(/\/(\d)/,
                            " $1").replace(/_/g, ".").replace(/(?: BePC|[ .]*fc[ \d.]+)$/i, "").replace(/\bx86\.64\b/gi, "x86_64").replace(/\b(Windows Phone) OS\b/, "$1").replace(/\b(Chrome OS \w+) [\d.]+\b/, "$1").split(" on ")[0])
                    }
                    return c
                })
            }(["Windows Phone", "Android", "CentOS", {
                    label: "Chrome OS",
                    pattern: "CrOS"
                }, "Debian", "Fedora", "FreeBSD", "Gentoo", "Haiku", "Kubuntu", "Linux Mint", "OpenBSD", "Red Hat", "SuSE", "Ubuntu", "Xubuntu", "Cygwin", "Symbian OS", "hpwOS", "webOS ", "webOS", "Tablet OS", "Tizen", "Linux", "Mac OS X", "Macintosh", "Mac",
                "Windows 98;", "Windows "
            ]);
        E && (E = [E]);
        P && !F && (F = d([P]));
        if (g = /\bGoogle TV\b/.exec(F)) F = g[0];
        /\bSimulator\b/i.test(a) && (F = (F ? F + " " : "") + "Simulator");
        "Opera Mini" == w && /\bOPiOS\b/.test(a) && p.push("running in Turbo/Uncompressed mode");
        "IE" == w && /\blike iPhone OS\b/.test(a) ? (g = r(a.replace(/like iPhone OS/, "")), P = g.manufacturer, F = g.product) : /^iP/.test(F) ? (w || (w = "Safari"), x = "iOS" + ((g = / OS ([\d_]+)/i.exec(a)) ? " " + g[1].replace(/_/g, ".") : "")) : "Konqueror" != w || /buntu/i.test(x) ? P && "Google" != P && (/Chrome/.test(w) &&
            !/\bMobile Safari\b/i.test(a) || /\bVita\b/.test(F)) || /\bAndroid\b/.test(x) && /^Chrome/.test(w) && /\bVersion\//i.test(a) ? (w = "Android Browser", x = /\bAndroid\b/.test(x) ? x : "Android") : "Silk" == w ? (/\bMobi/i.test(a) || (x = "Android", p.unshift("desktop mode")), /Accelerated *= *true/i.test(a) && p.unshift("accelerated")) : "PaleMoon" == w && (g = /\bFirefox\/([\d.]+)\b/.exec(a)) ? p.push("identifying as Firefox " + g[1]) : "Firefox" == w && (g = /\b(Mobile|Tablet|TV)\b/i.exec(a)) ? (x || (x = "Firefox OS"), F || (F = g[1])) : !w || (g = !/\bMinefield\b/i.test(a) &&
            /\b(?:Firefox|Safari)\b/.exec(w)) ? (w && !F && /[\/,]|^[^(]+?\)/.test(a.slice(a.indexOf(g + "/") + 8)) && (w = null), (g = F || P || x) && (F || P || /\b(?:Android|Symbian OS|Tablet OS|webOS)\b/.test(x)) && (w = /[a-z]+(?: Hat)?/i.exec(/\bAndroid\b/.test(x) ? x : g) + " Browser")) : "Electron" == w && (g = (/\bChrome\/([\d.]+)\b/.exec(a) || 0)[1]) && p.push("Chromium " + g) : x = "Kubuntu";
        k || (k = n(["(?:Cloud9|CriOS|CrMo|Edge|FxiOS|IEMobile|Iron|Opera ?Mini|OPiOS|OPR|Raven|SamsungBrowser|Silk(?!/[\\d.]+$))", "Version", h(w), "(?:Firefox|Minefield|NetFront)"]));
        if (g = "iCab" == E && 3 < parseFloat(k) && "WebKit" || /\bOpera\b/.test(w) && (/\bOPR\b/.test(a) ? "Blink" : "Presto") || /\b(?:Midori|Nook|Safari)\b/i.test(a) && !/^(?:Trident|EdgeHTML)$/.test(E) && "WebKit" || !E && /\bMSIE\b/i.test(a) && ("Mac OS" == x ? "Tasman" : "Trident") || "WebKit" == E && /\bPlayStation\b(?! Vita\b)/i.test(w) && "NetFront") E = [g];
        "IE" == w && (g = (/; *(?:XBLWP|ZuneWP)(\d+)/i.exec(a) || 0)[1]) ? (w += " Mobile", x = "Windows Phone " + (/\+$/.test(g) ? g : g + ".x"), p.unshift("desktop mode")) : /\bWPDesktop\b/i.test(a) ? (w = "IE Mobile", x = "Windows Phone 8.x",
            p.unshift("desktop mode"), k || (k = (/\brv:([\d.]+)/.exec(a) || 0)[1])) : "IE" != w && "Trident" == E && (g = /\brv:([\d.]+)/.exec(a)) && (w && p.push("identifying as " + w + (k ? " " + k : "")), w = "IE", k = g[1]);
        if (S) {
            if (e(l, "global"))
                if (y && (g = y.lang.System, R = g.getProperty("os.arch"), x = x || g.getProperty("os.name") + " " + g.getProperty("os.version")), A) {
                    try {
                        k = l.require("ringo/engine").version.join("."), w = "RingoJS"
                    } catch (X) {
                        (g = l.system) && g.global.system == l.system && (w = "Narwhal", x || (x = g[0].os || null))
                    }
                    w || (w = "Rhino")
                } else "object" == typeof l.process &&
                    !l.process.browser && (g = l.process) && ("object" == typeof g.versions && ("string" == typeof g.versions.electron ? (p.push("Node " + g.versions.node), w = "Electron", k = g.versions.electron) : "string" == typeof g.versions.nw && (p.push("Chromium " + k, "Node " + g.versions.node), w = "NW.js", k = g.versions.nw)), w || (w = "Node.js", R = g.arch, x = g.platform, k = (k = /[\d.]+/.exec(g.version)) ? k[0] : null));
            else f(g = l.runtime) == O ? (w = "Adobe AIR", x = g.flash.system.Capabilities.os) : f(g = l.phantom) == Q ? (w = "PhantomJS", k = (g = g.version || null) && g.major + "." + g.minor +
                "." + g.patch) : "number" == typeof U.documentMode && (g = /\bTrident\/(\d+)/i.exec(a)) ? (k = [k, U.documentMode], (g = +g[1] + 4) != k[1] && (p.push("IE " + k[1] + " mode"), E && (E[1] = ""), k[1] = g), k = "IE" == w ? String(k[1].toFixed(1)) : k[0]) : "number" == typeof U.documentMode && /^(?:Chrome|Firefox)\b/.test(w) && (p.push("masking as " + w + " " + k), w = "IE", k = "11.0", E = ["Trident"], x = "Windows");
            x = x && b(x)
        }
        k && (g = /(?:[ab]|dp|pre|[ab]\d+pre)(?:\d+\+?)?$/i.exec(k) || /(?:alpha|beta)(?: ?\d)?/i.exec(a + ";" + (S && q.appMinorVersion)) || /\bMinefield\b/i.test(a) &&
            "a") && (N = /b/i.test(g) ? "beta" : "alpha", k = k.replace(RegExp(g + "\\+?$"), "") + ("beta" == N ? T : V) + (/\d+\+?/.exec(g) || ""));
        if ("Fennec" == w || "Firefox" == w && /\b(?:Android|Firefox OS)\b/.test(x)) w = "Firefox Mobile";
        else if ("Maxthon" == w && k) k = k.replace(/\.[\d.]+/, ".x");
        else if (/\bXbox\b/i.test(F)) "Xbox 360" == F && (x = null), "Xbox 360" == F && /\bIEMobile\b/.test(a) && p.unshift("mobile mode");
        else if (!/^(?:Chrome|IE|Opera)$/.test(w) && (!w || F || /Browser|Mobi/.test(w)) || "Windows CE" != x && !/Mobi/i.test(a))
            if ("IE" == w && S) try {
                null === l.external &&
                    p.unshift("platform preview")
            } catch (X) {
                p.unshift("embedded")
            } else(/\bBlackBerry\b/.test(F) || /\bBB10\b/.test(a)) && (g = (RegExp(F.replace(/ +/g, " *") + "/([.\\d]+)", "i").exec(a) || 0)[1] || k) ? (g = [g, /BB10/.test(a)], x = (g[1] ? (F = null, P = "BlackBerry") : "Device Software") + " " + g[0], k = null) : this != c && "Wii" != F && (S && z || /Opera/.test(w) && /\b(?:MSIE|Firefox)\b/i.test(a) || "Firefox" == w && /\bOS X (?:\d+\.){2,}/.test(x) || "IE" == w && (x && !/^Win/.test(x) && 5.5 < k || /\bWindows XP\b/.test(x) && 8 < k || 8 == k && !/\bTrident\b/.test(a))) && !v.test(g =
                r.call(c, a.replace(v, "") + ";")) && g.name && (g = "ing as " + g.name + ((g = g.version) ? " " + g : ""), v.test(w) ? (/\bIE\b/.test(g) && "Mac OS" == x && (x = null), g = "identify" + g) : (g = "mask" + g, w = m ? b(m.replace(/([a-z])([A-Z])/g, "$1 $2")) : "Opera", /\bIE\b/.test(g) && (x = null), S || (k = null)), E = ["Presto"], p.push(g));
            else w += " Mobile";
        if (g = (/\bAppleWebKit\/([\d.]+\+?)/i.exec(a) || 0)[1]) {
            g = [parseFloat(g.replace(/\.(\d)$/, ".0$1")), g];
            if ("Safari" == w && "+" == g[1].slice(-1)) w = "WebKit Nightly", N = "alpha", k = g[1].slice(0, -1);
            else if (k == g[1] || k == (g[2] =
                    (/\bSafari\/([\d.]+\+?)/i.exec(a) || 0)[1])) k = null;
            g[1] = (/\bChrome\/([\d.]+)/i.exec(a) || 0)[1];
            537.36 == g[0] && 537.36 == g[2] && 28 <= parseFloat(g[1]) && "WebKit" == E && (E = ["Blink"]);
            S && (C || g[1]) ? (E && (E[1] = "like Chrome"), g = g[1] || (g = g[0], 530 > g ? 1 : 532 > g ? 2 : 532.05 > g ? 3 : 533 > g ? 4 : 534.03 > g ? 5 : 534.07 > g ? 6 : 534.1 > g ? 7 : 534.13 > g ? 8 : 534.16 > g ? 9 : 534.24 > g ? 10 : 534.3 > g ? 11 : 535.01 > g ? 12 : 535.02 > g ? "13+" : 535.07 > g ? 15 : 535.11 > g ? 16 : 535.19 > g ? 17 : 536.05 > g ? 18 : 536.1 > g ? 19 : 537.01 > g ? 20 : 537.11 > g ? "21+" : 537.13 > g ? 23 : 537.18 > g ? 24 : 537.24 > g ? 25 : 537.36 > g ? 26 : "Blink" !=
                E ? "27" : "28")) : (E && (E[1] = "like Safari"), g = (g = g[0], 400 > g ? 1 : 500 > g ? 2 : 526 > g ? 3 : 533 > g ? 4 : 534 > g ? "4+" : 535 > g ? 5 : 537 > g ? 6 : 538 > g ? 7 : 601 > g ? 8 : "8"));
            E && (E[1] += " " + (g += "number" == typeof g ? ".x" : /[.+]/.test(g) ? "" : "+"));
            "Safari" == w && (!k || 45 < parseInt(k)) && (k = g)
        }
        "Opera" == w && (g = /\bzbov|zvav$/.exec(x)) ? (w += " ", p.unshift("desktop mode"), "zvav" == g ? (w += "Mini", k = null) : w += "Mobile", x = x.replace(RegExp(" *" + g + "$"), "")) : "Safari" == w && /\bChrome\b/.exec(E && E[1]) && (p.unshift("desktop mode"), w = "Chrome Mobile", k = null, /\bOS X\b/.test(x) ? (P =
            "Apple", x = "iOS 4.3+") : x = null);
        k && 0 == k.indexOf(g = /[\d.]+$/.exec(x)) && -1 < a.indexOf("/" + g + "-") && (x = String(x.replace(g, "")).replace(/^ +| +$/g, ""));
        E && !/\b(?:Avant|Nook)\b/.test(w) && (/Browser|Lunascape|Maxthon/.test(w) || "Safari" != w && /^iOS/.test(x) && /\bSafari\b/.test(E[1]) || /^(?:Adobe|Arora|Breach|Midori|Opera|Phantom|Rekonq|Rock|Samsung Internet|Sleipnir|Web)/.test(w) && E[1]) && (g = E[E.length - 1]) && p.push(g);
        p.length && (p = ["(" + p.join("; ") + ")"]);
        P && F && 0 > F.indexOf(P) && p.push("on " + P);
        F && p.push((/^on /.test(p[p.length -
            1]) ? "" : "on ") + F);
        if (x) {
            var W = (g = / ([\d.+]+)$/.exec(x)) && "/" == x.charAt(x.length - g[0].length - 1);
            x = {
                architecture: 32,
                family: g && !W ? x.replace(g[0], "") : x,
                version: g ? g[1] : null,
                toString: function() {
                    var a = this.version;
                    return this.family + (a && !W ? " " + a : "") + (64 == this.architecture ? " 64-bit" : "")
                }
            }
        }(g = /\b(?:AMD|IA|Win|WOW|x86_|x)64\b/i.exec(R)) && !/\bi686\b/i.test(R) ? (x && (x.architecture = 64, x.family = x.family.replace(RegExp(" *" + g), "")), w && (/\bWOW64\b/i.test(a) || S && /\w(?:86|32)$/.test(q.cpuClass || q.platform) && !/\bWin64; x64\b/i.test(a)) &&
            p.unshift("32-bit")) : x && /^OS X/.test(x.family) && "Chrome" == w && 39 <= parseFloat(k) && (x.architecture = 64);
        a || (a = null);
        l = {};
        l.description = a;
        l.layout = E && E[0];
        l.manufacturer = P;
        l.name = w;
        l.prerelease = N;
        l.product = F;
        l.ua = a;
        l.version = w && k;
        l.os = x || {
            architecture: null,
            family: null,
            version: null,
            toString: function() {
                return "null"
            }
        };
        l.parse = r;
        l.toString = function() {
            return this.description || ""
        };
        l.version && p.unshift(k);
        l.name && p.unshift(w);
        x && w && (x != String(x).split(" ")[0] || x != w.split(" ")[0] && !F) && p.push(F ? "(" + x + ")" : "on " +
            x);
        p.length && (l.description = p.join(" "));
        return l
    }
    var n = {
            "function": !0,
            object: !0
        },
        u = n[typeof window] && window || this,
        q = n[typeof exports] && exports;
    n = n[typeof module] && module && !module.nodeType && module;
    var l = q && n && "object" == typeof global && global;
    !l || l.global !== l && l.window !== l && l.self !== l || (u = l);
    var k = Math.pow(2, 53) - 1,
        v = /\bOpera/;
    l = Object.prototype;
    var y = l.hasOwnProperty,
        B = l.toString,
        p = r();
    "function" == typeof define && "object" == typeof define.amd && define.amd ? (u.platform = p, define(function() {
            return p
        })) : q &&
        n ? c(p, function(a, b) {
            q[b] = a
        }) : u.platform = p
}).call(this);

function buildIOSMeta() {
    for (var a = [{
            name: "viewport",
            content: "width=device-width, height=device-height, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no"
        }, {
            name: "apple-mobile-web-app-capable",
            content: "yes"
        }, {
            name: "apple-mobile-web-app-status-bar-style",
            content: "black"
        }], d = 0; d < a.length; d++) {
        var b = document.createElement("meta");
        b.name = a[d].name;
        b.content = a[d].content;
        var c = window.document.head.querySelector('meta[name="' + b.name + '"]');
        c && c.parentNode.removeChild(c);
        window.document.head.appendChild(b)
    }
}

function hideIOSFullscreenPanel() {
    jQuery(".xxx-ios-fullscreen-message").css("display", "none");
    jQuery(".xxx-ios-fullscreen-scroll").css("display", "none");
    jQuery(".xxx-game-iframe-full").removeClass("xxx-game-iframe-iphone-se")
}

function buildIOSFullscreenPanel() {
    jQuery("body").append('<div class="xxx-ios-fullscreen-message"><div class="xxx-ios-fullscreen-swipe"></div></div><div class="xxx-ios-fullscreen-scroll"></div>')
}

function showIOSFullscreenPanel() {
    jQuery(".xxx-ios-fullscreen-message").css("display", "block");
    jQuery(".xxx-ios-fullscreen-scroll").css("display", "block")
}

function __iosResize() {
    window.scrollTo(0, 0);
    console.log(window.devicePixelRatio);
    console.log(window.innerWidth);
    console.log(window.innerHeight);
    if ("iPhone" === platform.product) switch (window.devicePixelRatio) {
        case 2:
            switch (window.innerWidth) {
                case 568:
                    320 !== window.innerHeight && jQuery(".xxx-game-iframe-full").addClass("xxx-game-iframe-iphone-se");
                    break;
                case 667:
                    375 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                case 808:
                    414 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                default:
                    hideIOSFullscreenPanel()
            }
            break;
        case 3:
            switch (window.innerWidth) {
                case 736:
                    414 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                case 724:
                    375 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                case 808:
                    414 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                default:
                    hideIOSFullscreenPanel()
            }
            break;
        default:
            hideIOSFullscreenPanel()
    }
}

function iosResize() {
    __iosResize();
    setTimeout(function() {
        __iosResize()
    }, 500)
}

function iosInIframe() {
    try {
        return window.self !== window.top
    } catch (a) {
        return !0
    }
}
$(document).ready(function() {
    platform && "iPhone" === platform.product && "safari" !== platform.name.toLowerCase() && (buildIOSFullscreenPanel(), buildIOSMeta())
});
jQuery(window).resize(function() {
    platform && "iPhone" === platform.product && "safari" !== platform.name.toLowerCase() && iosResize()
});
(function() {
    var a = "undefined" !== typeof window && "undefined" !== typeof window.document ? window.document : {},
        d = "undefined" !== typeof module && module.exports,
        b = "undefined" !== typeof Element && "ALLOW_KEYBOARD_INPUT" in Element,
        c = function() {
            for (var b, c = ["requestFullscreen exitFullscreen fullscreenElement fullscreenEnabled fullscreenchange fullscreenerror".split(" "), "webkitRequestFullscreen webkitExitFullscreen webkitFullscreenElement webkitFullscreenEnabled webkitfullscreenchange webkitfullscreenerror".split(" "),
                    "webkitRequestFullScreen webkitCancelFullScreen webkitCurrentFullScreenElement webkitCancelFullScreen webkitfullscreenchange webkitfullscreenerror".split(" "), "mozRequestFullScreen mozCancelFullScreen mozFullScreenElement mozFullScreenEnabled mozfullscreenchange mozfullscreenerror".split(" "), "msRequestFullscreen msExitFullscreen msFullscreenElement msFullscreenEnabled MSFullscreenChange MSFullscreenError".split(" ")
                ], d = 0, f = c.length, e = {}; d < f; d++)
                if ((b = c[d]) && b[1] in a) {
                    for (d = 0; d < b.length; d++) e[c[0][d]] =
                        b[d];
                    return e
                }
            return !1
        }(),
        f = {
            change: c.fullscreenchange,
            error: c.fullscreenerror
        },
        e = {
            request: function(d) {
                var f = c.requestFullscreen;
                d = d || a.documentElement;
                if (/5\.1[.\d]* Safari/.test(navigator.userAgent)) d[f]();
                else d[f](b && Element.ALLOW_KEYBOARD_INPUT)
            },
            exit: function() {
                a[c.exitFullscreen]()
            },
            toggle: function(a) {
                this.isFullscreen ? this.exit() : this.request(a)
            },
            onchange: function(a) {
                this.on("change", a)
            },
            onerror: function(a) {
                this.on("error", a)
            },
            on: function(b, c) {
                var d = f[b];
                d && a.addEventListener(d, c, !1)
            },
            off: function(b,
                c) {
                var d = f[b];
                d && a.removeEventListener(d, c, !1)
            },
            raw: c
        };
    c ? (Object.defineProperties(e, {
        isFullscreen: {
            get: function() {
                return !!a[c.fullscreenElement]
            }
        },
        element: {
            enumerable: !0,
            get: function() {
                return a[c.fullscreenElement]
            }
        },
        enabled: {
            enumerable: !0,
            get: function() {
                return !!a[c.fullscreenEnabled]
            }
        }
    }), d ? module.exports = e : window.screenfull = e) : d ? module.exports = !1 : window.screenfull = !1
})();
var s_iOffsetX, s_iOffsetY, s_bIsRetina;
(function(a) {
    (jQuery.browser = jQuery.browser || {}).mobile = /android|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(ad|hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|tablet|treo|up\.(browser|link)|vodafone|wap|webos|windows (ce|phone)|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(a.substr(0,
        4))
})(navigator.userAgent || navigator.vendor || window.opera);
$(window).resize(function() {
    sizeHandler()
});

function trace(a) {
    console.log(a)
}

function getSize(a) {
    var d = a.toLowerCase(),
        b = window.document,
        c = b.documentElement;
    if (void 0 === window["inner" + a]) a = c["client" + a];
    else if (window["inner" + a] != c["client" + a]) {
        var f = b.createElement("body");
        f.id = "vpw-test-b";
        f.style.cssText = "overflow:scroll";
        var e = b.createElement("div");
        e.id = "vpw-test-d";
        e.style.cssText = "position:absolute;top:-1000px";
        e.innerHTML = "<style>@media(" + d + ":" + c["client" + a] + "px){body#vpw-test-b div#vpw-test-d{" + d + ":7px!important}}</style>";
        f.appendChild(e);
        c.insertBefore(f, b.head);
        a = 7 == e["offset" + a] ? c["client" + a] : window["inner" + a];
        c.removeChild(f)
    } else a = window["inner" + a];
    return a
}
window.addEventListener("orientationchange", onOrientationChange);

function onOrientationChange() {
    window.matchMedia("(orientation: portrait)").matches && sizeHandler();
    window.matchMedia("(orientation: landscape)").matches && sizeHandler()
}

function isIOS() {
    isRetina();
    for (var a = "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";"); a.length;)
        if (navigator.platform === a.pop()) return s_bIsIphone = !0;
    return s_bIsIphone = !1
}

function isRetina() {
    s_bIsRetina = matchMedia("(-webkit-min-device-pixel-ratio: 2), (min-device-pixel-ratio: 2), (min-resolution: 192dpi)").matches ? !0 : !1
}

function getIOSWindowHeight() {
    return document.documentElement.clientWidth / window.innerWidth * window.innerHeight
}

function getHeightOfIOSToolbars() {
    var a = (0 === window.orientation ? screen.height : screen.width) - getIOSWindowHeight();
    return 1 < a ? a : 0
}

function sizeHandler() {
    window.scrollTo(0, 1);
    if ($("#canvas")) {
        var a = "safari" === platform.name.toLowerCase() ? getIOSWindowHeight() : getSize("Height");
        var d = getSize("Width");
        _checkOrientation(d, a);
        var b = Math.min(a / CANVAS_HEIGHT, d / CANVAS_WIDTH),
            c = CANVAS_WIDTH * b;
        b *= CANVAS_HEIGHT;
        if (b < a) {
            var f = a - b;
            b += f;
            c += CANVAS_WIDTH / CANVAS_HEIGHT * f
        } else c < d && (f = d - c, c += f, b += CANVAS_HEIGHT / CANVAS_WIDTH * f);
        f = a / 2 - b / 2;
        var e = d / 2 - c / 2,
            h = CANVAS_WIDTH / c;
        if (e * h < -EDGEBOARD_X || f * h < -EDGEBOARD_Y) b = Math.min(a / (CANVAS_HEIGHT - 2 * EDGEBOARD_Y),
            d / (CANVAS_WIDTH - 2 * EDGEBOARD_X)), c = CANVAS_WIDTH * b, b *= CANVAS_HEIGHT, f = (a - b) / 2, e = (d - c) / 2, h = CANVAS_WIDTH / c;
        s_iOffsetX = -1 * e * h;
        s_iOffsetY = -1 * f * h;
        0 <= f && (s_iOffsetY = 0);
        0 <= e && (s_iOffsetX = 0);
        null !== s_oInterface && s_oInterface.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        null !== s_oMenu && s_oMenu.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        s_bIsRetina ? (canvas = document.getElementById("canvas"), s_oStage.canvas.width = 2 * c, s_oStage.canvas.height = 2 * b, canvas.style.width = c + "px", canvas.style.height = b + "px", d = Math.min(c / CANVAS_WIDTH,
            b / CANVAS_HEIGHT), s_iScaleFactor = 2 * d, s_oStage.scaleX = s_oStage.scaleY = 2 * d) : s_bMobile ? ($("#canvas").css("width", c + "px"), $("#canvas").css("height", b + "px")) : (s_oStage.canvas.width = c, s_oStage.canvas.height = b, s_iScaleFactor = Math.min(c / CANVAS_WIDTH, b / CANVAS_HEIGHT), s_oStage.scaleX = s_oStage.scaleY = s_iScaleFactor);
        0 > f || (f = (a - b) / 2);
        $("#canvas").css("top", f + "px");
        $("#canvas").css("left", e + "px");
        fullscreenHandler()
    }
}

function _checkOrientation(a, d) {
    s_bMobile && ENABLE_CHECK_ORIENTATION && (a > d ? "landscape" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"), s_oMain.stopUpdate()) : "portrait" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"),
        s_oMain.stopUpdate()))
}

function createBitmap(a, d, b) {
    var c = new createjs.Bitmap(a),
        f = new createjs.Shape;
    d && b ? f.graphics.beginFill("#fff").drawRect(0, 0, d, b) : f.graphics.beginFill("#ff0").drawRect(0, 0, a.width, a.height);
    c.hitArea = f;
    return c
}

function createSprite(a, d, b, c, f, e) {
    a = null !== d ? new createjs.Sprite(a, d) : new createjs.Sprite(a);
    d = new createjs.Shape;
    d.graphics.beginFill("#000000").drawRect(-b, -c, f, e);
    a.hitArea = d;
    return a
}

function randomFloatBetween(a, d, b) {
    "undefined" === typeof b && (b = 2);
    return parseFloat(Math.min(a + Math.random() * (d - a), d).toFixed(b))
}

function shuffle(a) {
    for (var d = a.length, b, c; 0 !== d;) c = Math.floor(Math.random() * d), --d, b = a[d], a[d] = a[c], a[c] = b;
    return a
}

function formatTime(a) {
    a /= 1E3;
    var d = Math.floor(a / 60);
    a = parseFloat(a - 60 * d).toFixed(1);
    var b = "";
    b = 10 > d ? b + ("0" + d + ":") : b + (d + ":");
    return 10 > a ? b + ("0" + a) : b + a
}
Array.prototype.sortOn = function() {
    var a = this.slice();
    if (!arguments.length) return a.sort();
    var d = Array.prototype.slice.call(arguments);
    return a.sort(function(a, c) {
        for (var b = d.slice(), e = b.shift(); a[e] == c[e] && b.length;) e = b.shift();
        return a[e] == c[e] ? 0 : a[e] > c[e] ? 1 : -1
    })
};

function roundDecimal(a, d) {
    var b = Math.pow(10, d);
    return Math.round(b * a) / b
}

function tweenVectors(a, d, b, c) {
    c.set(a.getX() + b * (d.getX() - a.getX()), a.getY() + b * (d.getY() - a.getY()));
    return c
}

function NoClickDelay(a) {
    this.element = a;
    window.Touch && this.element.addEventListener("touchstart", this, !1)
}
NoClickDelay.prototype = {
    handleEvent: function(a) {
        switch (a.type) {
            case "touchstart":
                this.onTouchStart(a);
                break;
            case "touchmove":
                this.onTouchMove(a);
                break;
            case "touchend":
                this.onTouchEnd(a)
        }
    },
    onTouchStart: function(a) {
        a.preventDefault();
        this.moved = !1;
        this.element.addEventListener("touchmove", this, !1);
        this.element.addEventListener("touchend", this, !1)
    },
    onTouchMove: function(a) {
        this.moved = !0
    },
    onTouchEnd: function(a) {
        this.element.removeEventListener("touchmove", this, !1);
        this.element.removeEventListener("touchend",
            this, !1);
        if (!this.moved) {
            a = document.elementFromPoint(a.changedTouches[0].clientX, a.changedTouches[0].clientY);
            3 === a.nodeType && (a = a.parentNode);
            var d = document.createEvent("MouseEvents");
            d.initEvent("click", !0, !0);
            a.dispatchEvent(d)
        }
    }
};

function playSound(a, d, b) {
    return !1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile ? (s_aSounds[a].play(), s_aSounds[a].volume(d), s_aSounds[a].loop(b), s_aSounds[a]) : null
}

function stopSound(a) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].stop()
}

function setVolume(a, d) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].volume(d)
}

function setMute(a, d) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].mute(d)
}

function ctlArcadeResume() {
    null !== s_oMain && s_oMain.startUpdate()
}

function ctlArcadePause() {
    null !== s_oMain && s_oMain.stopUpdate()
}

function getParamValue(a) {
    for (var d = window.location.search.substring(1).split("&"), b = 0; b < d.length; b++) {
        var c = d[b].split("=");
        if (c[0] == a) return c[1]
    }
}

function fullscreenHandler() {
    ENABLE_FULLSCREEN && !1 !== screenfull.enabled && (s_bFullscreen = screenfull.isFullscreen, null !== s_oInterface && s_oInterface.resetFullscreenBut(), null !== s_oMenu && s_oMenu.resetFullscreenBut())
}
if (screenfull.enabled) screenfull.on("change", function() {
    s_bFullscreen = screenfull.isFullscreen;
    null !== s_oInterface && s_oInterface.resetFullscreenBut();
    null !== s_oMenu && s_oMenu.resetFullscreenBut()
});

function CSpriteLibrary() {
    var a = {},
        d, b, c, f, e, h;
    this.init = function(a, r, n) {
        d = {};
        c = b = 0;
        f = a;
        e = r;
        h = n
    };
    this.addSprite = function(c, f) {
        if (!a.hasOwnProperty(c)) {
            var e = new Image;
            a[c] = d[c] = {
                szPath: f,
                oSprite: e,
                bLoaded: !1
            };
            b++
        }
    };
    this.getSprite = function(b) {
        return a.hasOwnProperty(b) ? a[b].oSprite : null
    };
    this._onSpritesLoaded = function() {
        b = 0;
        e.call(h)
    };
    this._onSpriteLoaded = function() {
        f.call(h);
        ++c === b && this._onSpritesLoaded()
    };
    this.loadSprites = function() {
        for (var a in d) d[a].oSprite.oSpriteLibrary = this, d[a].oSprite.szKey =
            a, d[a].oSprite.onload = function() {
                this.oSpriteLibrary.setLoaded(this.szKey);
                this.oSpriteLibrary._onSpriteLoaded(this.szKey)
            }, d[a].oSprite.onerror = function(a) {
                var b = a.currentTarget;
                setTimeout(function() {
                    d[b.szKey].oSprite.src = d[b.szKey].szPath
                }, 500)
            }, d[a].oSprite.src = d[a].szPath
    };
    this.setLoaded = function(b) {
        a[b].bLoaded = !0
    };
    this.isLoaded = function(b) {
        return a[b].bLoaded
    };
    this.getNumSprites = function() {
        return b
    }
}
var CANVAS_WIDTH = 1700,
    CANVAS_HEIGHT = 768,
    EDGEBOARD_X = 338,
    EDGEBOARD_Y = 0,
    FPS_TIME = 1E3 / 24,
    DISABLE_SOUND_MOBILE = !1,
    FONT_GAME_1 = "ArialBold",
    FONT_GAME_2 = "Digital-7",
    STATE_LOADING = 0,
    STATE_MENU = 1,
    STATE_HELP = 1,
    STATE_GAME = 3,
    STATE_GAME_WAITING_FOR_BET = 0,
    STATE_GAME_DEALING = 1,
    STATE_GAME_HITTING = 2,
    STATE_GAME_SPLIT = 3,
    STATE_GAME_FINALIZE = 4,
    STATE_GAME_SHOW_WINNER = 5,
    STATE_CARD_DEALING = 0,
    STATE_CARD_SPLIT = 1,
    STATE_CARD_REMOVING = 2,
    ON_MOUSE_DOWN = 0,
    ON_MOUSE_UP = 1,
    ON_MOUSE_OVER = 2,
    ON_MOUSE_OUT = 3,
    ON_DRAG_START = 4,
    ON_DRAG_END =
    5,
    SIT_DOWN = "SIT_DOWN",
    PASS_TURN = "PASS_TURN",
    PLAYER_LOSE = "PLAYER_LOSE",
    ASSIGN_FICHES = "ASSIGN_FICHES",
    FICHES_END_MOV = "FICHES_END_MOV",
    RESTORE_ACTION = "RESTORE_ACTION",
    END_HAND = "END_HAND",
    ON_CARD_SHOWN = "ON_CARD_SHOWN",
    ON_CARD_ANIMATION_ENDING = "ON_CARD_ANIMATION_ENDING",
    SPLIT_CARD_END_ANIM = "SPLIT_CARD_END_ANIM",
    ON_CARD_TO_REMOVE = "ON_CARD_TO_REMOVE",
    NUM_FICHES = 6,
    CARD_WIDTH = 44,
    CARD_HEIGHT = 63,
    MIN_BET, MAX_BET, TOTAL_MONEY, FICHE_WIDTH, WIN_OCCURRENCE, TIME_FICHES_MOV = 600,
    TIME_CARD_DEALING = 250,
    TIME_CARD_REMOVE =
    1E3,
    TIME_SHOW_FINAL_CARDS = 4E3,
    TIME_END_HAND = 1500,
    BET_TIME = 1E4,
    COLOR_FICHE_PER_VALUE = "#000 #000 #000 #fff #000 #fff".split(" "),
    SIZE_FONT_FICHE = [12, 18, 18, 18, 18, 20],
    AD_SHOW_COUNTER, ENABLE_FULLSCREEN, ENABLE_CHECK_ORIENTATION, SHOW_CREDITS;
TEXT_PLAY = "PLAY";
TEXT_SIT_DOWN = "SIT DOWN";
TEXT_CLEAR = "CLEAR";
TEXT_REBET = "REBET";
TEXT_DEAL = "DEAL";
TEXT_HIT = "HIT";
TEXT_STAND = "STAND";
TEXT_DOUBLE = "DOUBLE";
TEXT_SPLIT = "SPLIT";
TEXT_MIN_BET = "MIN BET";
TEXT_MAX_BET = "MAX BET";
TEXT_NO = "NO";
TEXT_YES = "YES";
TEXT_RECHARGE = "RECHARGE";
TEXT_EXIT = "EXIT";
TEXT_CURRENCY = "$";
TEXT_DISPLAY_MSG_WAITING_BET = "WAITING FOR YOUR BET";
TEXT_DISPLAY_MSG_SIT_DOWN = "PLEASE SIT DOWN TO START PLAYING";
TEXT_DISPLAY_MSG_YOUR_ACTION = "WAITING FOR PLAYER ACTION";
TEXT_DISPLAY_MSG_DEALER_TURN = "DEALER TURN";
TEXT_DISPLAY_MSG_PLAYER_LOSE = "HAND WON BY DEALER ";
TEXT_DISPLAY_MSG_PLAYER_WIN = "HAND WON BY PLAYER ";
TEXT_DISPLAY_MSG_PLAYER_STANDOFF = "STANDOFF";
TEXT_DISPLAY_MSG_DEALING = "DEALING...";
TEXT_SHOW_WIN_PLAYER = "YOU WIN ";
TEXT_SHOW_LOSE_PLAYER = "YOU LOSE ";
TEXT_SHOW_STANDOFF = "STANDOFF";
TEXT_INSURANCE = "Do you want Insurance?";
TEXT_NO_MONEY = "YOU DON'T HAVE ENOUGH MONEY!!!";
TEXT_ERROR_MIN_BET = "YOUR BET IS LOWER THAN MINIMUM BET!!";
TEXT_ERROR_MAX_BET = "THIS BET IS HIGHER OF THE GAME MAXIMUM BET!!";
TEXT_CREDITS_DEVELOPED = "DEVELOPED BY";
var TEXT_PRELOADER_CONTINUE = "START";
TEXT_SHARE_IMAGE = "200x200.jpg";
TEXT_SHARE_TITLE = "Congratulations!";
TEXT_SHARE_MSG1 = "You collected <strong>";
TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!";
TEXT_SHARE_SHARE1 = "My score is ";
TEXT_SHARE_SHARE2 = " points! Can you do better?";

function CPreloader() {
    var a, d, b, c, f, e, h, t, r, n;
    this._init = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("progress_bar", "./sprites/progress_bar.png");
        s_oSpriteLibrary.addSprite("200x200", "./sprites/200x200.jpg");
        s_oSpriteLibrary.addSprite("but_start", "./sprites/but_start.png");
        s_oSpriteLibrary.loadSprites();
        n = new createjs.Container;
        s_oStage.addChild(n)
    };
    this.unload = function() {
        n.removeAllChildren();
        r.unload()
    };
    this._onImagesLoaded = function() {};
    this._onAllImagesLoaded = function() {
        this.attachSprites();
        s_oMain.preloaderReady()
    };
    this.attachSprites = function() {
        var u = new createjs.Shape;
        u.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        n.addChild(u);
        u = s_oSpriteLibrary.getSprite("200x200");
        h = createBitmap(u);
        h.regX = .5 * u.width;
        h.regY = .5 * u.height;
        h.x = CANVAS_WIDTH / 2;
        h.y = CANVAS_HEIGHT / 2 - 180;
        n.addChild(h);
        t = new createjs.Shape;
        t.graphics.beginFill("rgba(0,0,0,0.01)").drawRoundRect(h.x - 100, h.y - 100, 200, 200, 10);
        n.addChild(t);
        h.mask = t;
        u = s_oSpriteLibrary.getSprite("progress_bar");
        c = createBitmap(u);
        c.x = CANVAS_WIDTH / 2 - u.width / 2;
        c.y = CANVAS_HEIGHT / 2 + 50;
        n.addChild(c);
        a = u.width;
        d = u.height;
        f = new createjs.Shape;
        f.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(c.x, c.y, 1, d);
        n.addChild(f);
        c.mask = f;
        b = new createjs.Text("", "30px " + FONT_GAME_1, "#fff");
        b.x = CANVAS_WIDTH / 2;
        b.y = CANVAS_HEIGHT / 2 + 100;
        b.textBaseline = "alphabetic";
        b.textAlign = "center";
        n.addChild(b);
        u = s_oSpriteLibrary.getSprite("but_start");
        r = new CTextButton(CANVAS_WIDTH / 2, CANVAS_HEIGHT /
            2, u, TEXT_PRELOADER_CONTINUE, "Arial", "#000", "bold 40", n);
        r.addEventListener(ON_MOUSE_UP, this._onButStartRelease, this);
        r.setVisible(!1);
        e = new createjs.Shape;
        e.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        n.addChild(e);
        createjs.Tween.get(e).to({
            alpha: 0
        }, 500).call(function() {
            createjs.Tween.removeTweens(e);
            n.removeChild(e)
        })
    };
    this._onButStartRelease = function() {
        s_oMain._onRemovePreloader()
    };
    this.refreshLoader = function(e) {
        b.text = e + "%";
        100 === e && (s_oMain._onRemovePreloader(), b.visible = !1, c.visible = !1);
        f.graphics.clear();
        e = Math.floor(e * a / 100);
        f.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(c.x, c.y, e, d)
    };
    this._init()
}

function CMain(a) {
    var d, b = 0,
        c = 0,
        f = STATE_LOADING,
        e, h;
    this.initContainer = function() {
        var a = document.getElementById("canvas");
        s_oStage = new createjs.Stage(a);
        createjs.Touch.enable(s_oStage);
        s_bMobile = jQuery.browser.mobile;
        !1 === s_bMobile && s_oStage.enableMouseOver(20);
        s_iPrevTime = (new Date).getTime();
        createjs.Ticker.setFPS(30);
        createjs.Ticker.addEventListener("tick", this._update);
        navigator.userAgent.match(/Windows Phone/i) && (DISABLE_SOUND_MOBILE = !0);
        s_oSpriteLibrary = new CSpriteLibrary;
        seekAndDestroy() ? e =
            new CPreloader : window.location.href = "http://www.codethislab.com/contact-us.html";
        s_oGameSettings = new CGameSettings;
        d = !0
    };
    this.preloaderReady = function() {
        this._loadImages();
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || this._initSounds()
    };
    this.soundLoaded = function() {
        b++;
        e.refreshLoader(Math.floor(b / c * 100))
    };
    this._initSounds = function() {
        var a = [];
        a.push({
            path: "./sounds/",
            filename: "card",
            loop: !1,
            volume: 1,
            ingamename: "card"
        });
        a.push({
            path: "./sounds/",
            filename: "chip",
            loop: !1,
            volume: 1,
            ingamename: "chip"
        });
        a.push({
            path: "./sounds/",
            filename: "fiche_collect",
            loop: !1,
            volume: 1,
            ingamename: "fiche_collect"
        });
        a.push({
            path: "./sounds/",
            filename: "press_but",
            loop: !1,
            volume: 1,
            ingamename: "press_but"
        });
        a.push({
            path: "./sounds/",
            filename: "win",
            loop: !1,
            volume: 1,
            ingamename: "win"
        });
        a.push({
            path: "./sounds/",
            filename: "lose",
            loop: !1,
            volume: 1,
            ingamename: "lose"
        });
        c += a.length;
        s_aSounds = [];
        for (var b = 0; b < a.length; b++) s_aSounds[a[b].ingamename] = new Howl({
            src: [a[b].path + a[b].filename + ".mp3"],
            autoplay: !1,
            preload: !0,
            loop: a[b].loop,
            volume: a[b].volume,
            onload: s_oMain.soundLoaded
        })
    };
    this._loadImages = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("but_menu_bg", "./sprites/but_menu_bg.png");
        s_oSpriteLibrary.addSprite("but_game_bg", "./sprites/but_game_bg.png");
        s_oSpriteLibrary.addSprite("but_game_small_bg", "./sprites/but_game_small_bg.png");
        s_oSpriteLibrary.addSprite("but_game_very_small_bg", "./sprites/but_game_very_small_bg.png");
        s_oSpriteLibrary.addSprite("but_exit", "./sprites/but_exit.png");
        s_oSpriteLibrary.addSprite("bg_menu",
            "./sprites/bg_menu.jpg");
        s_oSpriteLibrary.addSprite("audio_icon", "./sprites/audio_icon.png");
        s_oSpriteLibrary.addSprite("bg_game_1", "./sprites/bg_game_1.jpg");
        s_oSpriteLibrary.addSprite("bg_game_2", "./sprites/bg_game_2.jpg");
        s_oSpriteLibrary.addSprite("bg_game_3", "./sprites/bg_game_3.jpg");
        s_oSpriteLibrary.addSprite("bg_game_4", "./sprites/bg_game_4.jpg");
        s_oSpriteLibrary.addSprite("seat", "./sprites/seat.png");
        s_oSpriteLibrary.addSprite("card_spritesheet", "./sprites/card_spritesheet.png");
        s_oSpriteLibrary.addSprite("arrow_hand",
            "./sprites/arrow_hand.png");
        s_oSpriteLibrary.addSprite("msg_box", "./sprites/msg_box.png");
        s_oSpriteLibrary.addSprite("display_bg", "./sprites/display_bg.png");
        s_oSpriteLibrary.addSprite("bet_bg", "./sprites/bet_bg.png");
        s_oSpriteLibrary.addSprite("money_bg", "./sprites/money_bg.png");
        s_oSpriteLibrary.addSprite("but_fullscreen", "./sprites/but_fullscreen.png");
        s_oSpriteLibrary.addSprite("logo_ctl", "./sprites/logo_ctl.png");
        s_oSpriteLibrary.addSprite("but_credits", "./sprites/but_credits.png");
        for (var a =
                0; a < NUM_FICHES; a++) s_oSpriteLibrary.addSprite("fiche_" + a, "./sprites/fiche_" + a + ".png");
        c += s_oSpriteLibrary.getNumSprites();
        s_oSpriteLibrary.loadSprites()
    };
    this._onImagesLoaded = function() {
        b++;
        e.refreshLoader(Math.floor(b / c * 100))
    };
    this._onAllImagesLoaded = function() {};
    this._onRemovePreloader = function() {
        e.unload();
        this.gotoMenu()
    };
    this.gotoMenu = function() {
        new CMenu;
        f = STATE_MENU
    };
    this.gotoGame = function() {
        h = new CGame(t);
        f = STATE_GAME
    };
    this.gotoHelp = function() {
        new CHelp;
        f = STATE_HELP
    };
    this.stopUpdate = function() {
        d = !1;
        createjs.Ticker.paused = !0;
        $("#block_game").css("display", "block");
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || Howler.mute(!0)
    };
    this.startUpdate = function() {
        s_iPrevTime = (new Date).getTime();
        d = !0;
        createjs.Ticker.paused = !1;
        $("#block_game").css("display", "none");
        (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) && s_bAudioActive && Howler.mute(!1)
    };
    this._update = function(a) {
        if (d) {
            var b = (new Date).getTime();
            s_iTimeElaps = b - s_iPrevTime;
            s_iCntTime += s_iTimeElaps;
            s_iCntFps++;
            s_iPrevTime = b;
            1E3 <= s_iCntTime && (s_iCurFps =
                s_iCntFps, s_iCntTime -= 1E3, s_iCntFps = 0);
            f === STATE_GAME && h.update();
            s_oStage.update(a)
        }
    };
    s_oMain = this;
    var t = a;
    ENABLE_CHECK_ORIENTATION = a.check_orientation;
    ENABLE_FULLSCREEN = a.fullscreen;
    SHOW_CREDITS = a.show_credits;
    this.initContainer()
}
var s_bMobile, s_bAudioActive = !0,
    s_iCntTime = 0,
    s_iTimeElaps = 0,
    s_iPrevTime = 0,
    s_iCntFps = 0,
    s_iCurFps = 0,
    s_oDrawLayer, s_oStage, s_oMain, s_oSpriteLibrary, s_oGameSettings, s_bFullscreen = !1,
    s_aSounds;

function CTextButton(a, d, b, c, f, e, h, t) {
    var r, n, u, q, l, k, v, y, B, p, A, H;
    this._init = function(a, b, c, d, f, e, h) {
        r = !1;
        n = 1;
        l = [];
        k = [];
        H = createBitmap(c);
        u = c.width;
        q = c.height;
        p = new createjs.Container;
        p.x = a;
        p.y = b;
        p.regX = c.width / 2;
        p.regY = c.height / 2;
        s_bMobile || (p.cursor = "pointer");
        p.addChild(H, A);
        t.addChild(p);
        A = new CTLText(p, 10, 6, c.width - 20, c.height - 10, h, "center", e, f, 1, 0, 0, d, !0, !0, !1, !1);
        this._initListener()
    };
    this.unload = function() {
        p.off("mousedown", v);
        p.off("pressup", y);
        t.removeChild(p)
    };
    this.setVisible = function(a) {
        p.visible =
            a
    };
    this.setAlign = function(a) {
        A.textAlign = a
    };
    this.setTextX = function(a) {
        A.x = a
    };
    this.setScale = function(a) {
        n = p.scaleX = p.scaleY = a
    };
    this.enable = function() {
        r = !1;
        p.filters = [];
        p.cache(0, 0, u, q)
    };
    this.disable = function() {
        r = !0;
        var a = (new createjs.ColorMatrix).adjustSaturation(-100);
        p.filters = [new createjs.ColorMatrixFilter(a)];
        p.cache(0, 0, u, q)
    };
    this._initListener = function() {
        v = p.on("mousedown", this.buttonDown);
        y = p.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        l[a] = b;
        k[a] = c
    };
    this.addEventListenerWithParams =
        function(a, b, c, d) {
            l[a] = b;
            k[a] = c;
            B = d
        };
    this.buttonRelease = function() {
        r || (playSound("press_but", 1, !1), p.scaleX = n, p.scaleY = n, l[ON_MOUSE_UP] && l[ON_MOUSE_UP].call(k[ON_MOUSE_UP], B))
    };
    this.buttonDown = function() {
        r || (p.scaleX = .9 * n, p.scaleY = .9 * n, l[ON_MOUSE_DOWN] && l[ON_MOUSE_DOWN].call(k[ON_MOUSE_DOWN]))
    };
    this.setPosition = function(a, b) {
        p.x = a;
        p.y = b
    };
    this.tweenPosition = function(a, b, c, d, f, e, h) {
        createjs.Tween.get(p).wait(d).to({
            x: a,
            y: b
        }, c, f).call(function() {
            void 0 !== e && e.call(h)
        })
    };
    this.changeText = function(a) {
        A.refreshText(a)
    };
    this.setX = function(a) {
        p.x = a
    };
    this.setY = function(a) {
        p.y = a
    };
    this.getButtonImage = function() {
        return p
    };
    this.getX = function() {
        return p.x
    };
    this.getY = function() {
        return p.y
    };
    this.getSprite = function() {
        return p
    };
    this.getScale = function() {
        return p.scaleX
    };
    this._init(a, d, b, c, f, e, h)
}

function CGfxButton(a, d, b) {
    var c, f, e, h, t, r = [],
        n, u, q;
    this._init = function(a, b, d) {
        c = !1;
        h = [];
        t = [];
        f = d.width;
        e = d.height;
        q = createBitmap(d);
        q.x = a;
        q.y = b;
        q.regX = d.width / 2;
        q.regY = d.height / 2;
        q.cursor = "pointer";
        s_oStage.addChild(q);
        this._initListener()
    };
    this.unload = function() {
        q.off("mousedown", n);
        q.off("pressup", u);
        s_oStage.removeChild(q)
    };
    this.setVisible = function(a) {
        q.visible = a
    };
    this._initListener = function() {
        n = q.on("mousedown", this.buttonDown);
        u = q.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a,
        b, c) {
        h[a] = b;
        t[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, d) {
        h[a] = b;
        t[a] = c;
        r = d
    };
    this.buttonRelease = function() {
        c || (playSound("press_but", 1, !1), q.scaleX = 1, q.scaleY = 1, h[ON_MOUSE_UP] && h[ON_MOUSE_UP].call(t[ON_MOUSE_UP], r))
    };
    this.buttonDown = function() {
        c || (q.scaleX = .9, q.scaleY = .9, h[ON_MOUSE_DOWN] && h[ON_MOUSE_DOWN].call(t[ON_MOUSE_DOWN], r))
    };
    this.setPosition = function(a, b) {
        q.x = a;
        q.y = b
    };
    this.setX = function(a) {
        q.x = a
    };
    this.setY = function(a) {
        q.y = a
    };
    this.enable = function() {
        c = !1;
        q.filters = [];
        q.cache(0, 0,
            f, e)
    };
    this.disable = function() {
        c = !0;
        var a = (new createjs.ColorMatrix).adjustSaturation(-100).adjustBrightness(40);
        q.filters = [new createjs.ColorMatrixFilter(a)];
        q.cache(0, 0, f, e)
    };
    this.getButtonImage = function() {
        return q
    };
    this.getX = function() {
        return q.x
    };
    this.getY = function() {
        return q.y
    };
    this._init(a, d, b);
    return this
}

function CToggle(a, d, b, c, f) {
    var e, h, t, r;
    this._init = function(a, b, c, d) {
        h = [];
        t = [];
        var f = new createjs.SpriteSheet({
            images: [c],
            frames: {
                width: c.width / 2,
                height: c.height,
                regX: c.width / 2 / 2,
                regY: c.height / 2
            },
            animations: {
                state_true: [0],
                state_false: [1]
            }
        });
        e = d;
        r = createSprite(f, "state_" + e, c.width / 2 / 2, c.height / 2, c.width / 2, c.height);
        r.x = a;
        r.y = b;
        r.stop();
        n.addChild(r);
        this._initListener()
    };
    this.unload = function() {
        r.off("mousedown", this.buttonDown);
        r.off("pressup", this.buttonRelease);
        s_bMobile || r.off("mouseover", this.buttonOver);
        n.removeChild(r)
    };
    this._initListener = function() {
        r.on("mousedown", this.buttonDown);
        r.on("pressup", this.buttonRelease);
        if (!s_bMobile) r.on("mouseover", this.buttonOver)
    };
    this.addEventListener = function(a, b, c) {
        h[a] = b;
        t[a] = c
    };
    this.setActive = function(a) {
        e = a;
        r.gotoAndStop("state_" + e)
    };
    this.buttonRelease = function() {
        r.scaleX = 1;
        r.scaleY = 1;
        playSound("press_but", 1, 0);
        e = !e;
        r.gotoAndStop("state_" + e);
        h[ON_MOUSE_UP] && h[ON_MOUSE_UP].call(t[ON_MOUSE_UP], e)
    };
    this.buttonDown = function() {
        r.scaleX = .9;
        r.scaleY = .9;
        h[ON_MOUSE_DOWN] &&
            h[ON_MOUSE_DOWN].call(t[ON_MOUSE_DOWN])
    };
    this.buttonOver = function(a) {
        s_bMobile || (a.target.cursor = "pointer")
    };
    this.setPosition = function(a, b) {
        r.x = a;
        r.y = b
    };
    var n = f;
    this._init(a, d, b, c)
}

function CMenu() {
    var a, d, b, c, f, e, h, t, r, n, u, q, l = null,
        k = null;
    this._init = function() {
        h = createBitmap(s_oSpriteLibrary.getSprite("bg_menu"));
        s_oStage.addChild(h);
        var v = s_oSpriteLibrary.getSprite("but_menu_bg");
        t = new CTextButton(CANVAS_WIDTH / 2, CANVAS_HEIGHT - 164, v, TEXT_PLAY, FONT_GAME_1, "#ffffff", 40, s_oStage);
        t.addEventListener(ON_MOUSE_UP, this._onButPlayRelease, this);
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) v = s_oSpriteLibrary.getSprite("audio_icon"), f = CANVAS_WIDTH - v.width / 4 - 10, e = v.height / 2 + 10, r = new CToggle(f,
            e, v, s_bAudioActive, s_oStage), r.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this);
        var y = s_oSpriteLibrary.getSprite("but_credits");
        v = window.document;
        var B = v.documentElement;
        l = B.requestFullscreen || B.mozRequestFullScreen || B.webkitRequestFullScreen || B.msRequestFullscreen;
        k = v.exitFullscreen || v.mozCancelFullScreen || v.webkitExitFullscreen || v.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (l = !1);
        l && screenfull.enabled ? (v = s_oSpriteLibrary.getSprite("but_fullscreen"), b = v.width / 4 + 10, c = v.height / 2 + 10, u = new CToggle(b,
            c, v, s_bFullscreen, s_oStage), u.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this), a = b + 10 + v.width / 2, d = v.height / 2 + 10) : (a = 10 + y.width / 2, d = y.height / 2 + 10);
        SHOW_CREDITS && (q = new CGfxButton(a, d, y), q.addEventListener(ON_MOUSE_UP, this._onCredits, this));
        n = new createjs.Shape;
        n.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(n);
        createjs.Tween.get(n).to({
            alpha: 0
        }, 400).call(function() {
            n.visible = !1
        });
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.refreshButtonPos =
        function(h, k) {
            !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || r.setPosition(f - h, k + e);
            l && screenfull.enabled && u.setPosition(b + h, c + k);
            SHOW_CREDITS && q.setPosition(a + h, d + k)
        };
    this.unload = function() {
        t.unload();
        t = null;
        SHOW_CREDITS && q.unload();
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) r.unload(), r = null;
        l && screenfull.enabled && u.unload();
        s_oStage.removeAllChildren();
        s_oMenu = null
    };
    this._onButPlayRelease = function() {
        this.unload();
        s_oMain.gotoGame();
        $(s_oMain).trigger("start_session")
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this.resetFullscreenBut = function() {
        l && screenfull.enabled && u.setActive(s_bFullscreen)
    };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? k.call(window.document) : l.call(window.document.documentElement);
        sizeHandler()
    };
    this._onCredits = function() {
        new CCreditsPanel
    };
    s_oMenu = this;
    this._init()
}
var s_oMenu = null;

function CGame(a) {
    var d = !1,
        b, c, f, e = !1,
        h, t, r, n, u, q, l, k, v, y, B, p, A, H, I, J, D, G, L, C, O, M, K, Q, V, T, U, z, m, g, R;
    this._init = function() {
        r = MAX_BET;
        n = MIN_BET;
        u = -1;
        p = t = 0;
        s_oTweenController = new CTweenController;
        U = createBitmap(s_oSpriteLibrary.getSprite("bg_game_" + (Math.floor(4 * Math.random()) + 1)));
        s_oStage.addChild(U);
        m = new CSeat;
        m.setCredit(TOTAL_MONEY);
        m.addEventListener(SIT_DOWN, this._onSitDown, this);
        m.addEventListener(RESTORE_ACTION, this._onSetPlayerActions);
        m.addEventListener(PASS_TURN, this._passTurnToDealer);
        m.addEventListener(END_HAND, this._onEndHand);
        m.addEventListener(PLAYER_LOSE, this._playerLose);
        T = new createjs.Container;
        s_oStage.addChild(T);
        z = new CInterface(TOTAL_MONEY);
        z.displayMsg(TEXT_DISPLAY_MSG_SIT_DOWN);
        this.reset(!0);
        O = new CVector2;
        O.set(1214, 228);
        M = new CVector2;
        M.set(788, 180);
        K = new CVector2;
        K.set(418, 820);
        Q = new CVector2;
        Q.set(CANVAS_WIDTH / 2, -100);
        V = new CVector2(408, 208);
        G = [m.getCardOffset(), M];
        z.disableBetFiches();
        g = new CGameOver;
        R = new CMsgBox;
        m.getCredit() < s_oGameSettings.getFichesValueAt(0) ?
            (this._gameOver(), this.changeState(-1)) : d = !0
    };
    this.unload = function() {
        d = !1;
        for (var a = 0; a < A.length; a++) A[a].unload();
        a = m.getPlayerCards();
        for (var b = 0; b < a.length; b++) a[b].unload();
        z.unload();
        g.unload();
        R.unload();
        s_oStage.removeAllChildren()
    };
    this.reset = function(a) {
        b = !0;
        f = c = !1;
        v = k = l = q = t = h = 0;
        m.reset();
        A = [];
        A.splice(0);
        I = [];
        I.splice(0);
        z.reset();
        z.enableBetFiches();
        a ? this.shuffleCard() : (y > D.length / 2 || B > H.length / 2) && this.shuffleCard()
    };
    this.setMoney = function(a) {
        m.setCredit(a);
        z.refreshCredit(a);
        s_oInterface.enableBetFiches();
        s_oInterface.enable(!0, !1, !1, !1, !1)
    };
    this.shuffleCard = function() {
        J = [];
        J = s_oGameSettings.getShuffledCardDeck();
        D = [];
        H = [];
        for (var a = 0; a < J.length; a++) 0 === a % 2 ? D.push(J[a]) : H.push(J[a]);
        B = y = 0;
        L = [];
        for (a = 0; a < J.length; a++) L[a] = 0
    };
    this.changeState = function(a) {
        u = a;
        switch (u) {
            case STATE_GAME_DEALING:
                if ((N < 2 * m.getCurBet() ? WIN_OCCURRENCE : 100 * Math.random()) < WIN_OCCURRENCE) {
                    e = !0;
                    do a = s_oGameSettings.getRandDealerPattern(); while (!1 === this._checkIfDealerPatternCanBeUsed(a));
                    C = [];
                    for (var b = 0; b < a.length; b++) C[b] = a[b]
                } else e = !1;
                z.disableButtons();
                z.displayMsg(TEXT_DISPLAY_MSG_DEALING);
                this._dealing()
        }
    };
    this._checkIfDealerPatternCanBeUsed = function(a) {
        for (var b = 0; b < a.length; b++)
            if (1 < L[a[b]]) return !1;
        return !0
    };
    this.attachCardToDeal = function(a, b, c, d) {
        var f = new CCard(O.getX(), O.getY(), T);
        if (c)
            if (e) {
                var h = C.shift();
                B++
            } else {
                do {
                    h = H[B];
                    B++;
                    B > H.length / 2 && (this.shuffleCard(), B = 0);
                    var g = s_oGameSettings.getCardValue(h);
                    11 === g && 21 < l + g && (g = 1)
                } while (21 < l + g || 16 < l + g && l + g < m.getHandValue(0) && 21 > m.getHandValue(0))
            }
        else if (e) {
            do h = D[y], y++,
                y > D.length / 2 && (this.shuffleCard(), y = 0), g = s_oGameSettings.getCardValue(h), 11 === g && 21 < m.getHandValue(0) + g && (g = 1); while (21 < m.getHandValue(0) + g)
        } else {
            do h = D[y], y++, y > D.length / 2 && (this.shuffleCard(), y = 0), g = s_oGameSettings.getCardValue(h), 11 === g && 21 < m.getHandValue(0) + g && (g = 1); while (16 < m.getHandValue(0) + g && 22 > m.getHandValue(0) + g)
        }
        f.setInfo(a, b, h, s_oGameSettings.getCardValue(h), c, d);
        L[h] += 1;
        f.addEventListener(ON_CARD_ANIMATION_ENDING, this.cardFromDealerArrived);
        A.push(f);
        playSound("card", 1, !1)
    };
    this.cardFromDealerArrived =
        function(a, b, c) {
            for (var d = 0; d < A.length; d++)
                if (A[d] === a) {
                    A.splice(d, 1);
                    break
                }!1 === b ? (m.addCardToHand(a), m.increaseHandValue(a.getValue()), 2 < c && m.refreshCardValue()) : (l += a.getValue(), 2 < k && z.refreshDealerCardValue(l), 11 === a.getValue() && v++, I.push(a));
            3 > c ? s_oGame._dealing() : (s_oGame._checkHand(), !1 === b && f && (f = !1, s_oGame._onStandPlayer()))
        };
    this._onStandPlayer = function() {
        m.stand()
    };
    this._checkHand = function() {
        var a;
        if (b) m.checkHand();
        else if (z.refreshDealerCardValue(l), 21 === l)
            for (0 < h && 2 === I.length && (m.increaseCredit(2 *
                    h), N -= 2 * h, z.refreshCredit(m.getCredit())), a = 0; a < m.getNumHands(); a++) this._playerLose(a);
        else 21 < l ? 0 < v ? (v--, l -= 10, z.refreshDealerCardValue(l), 17 > l ? this.hitDealer() : this._checkWinner()) : this._checkWinner() : 17 > l ? this.hitDealer() : this._checkWinner()
    };
    this._playerWin = function(a) {
        var b = 1;
        21 === m.getHandValue(a) && 2 === m.getNumCardsForHand(a) && (b = BLACKJACK_PAYOUT);
        b = m.getBetForHand(a) + parseFloat((m.getBetForHand(a) * b).toFixed(2));
        m.increaseCredit(b);
        N -= b;
        m.showWinner(a, TEXT_SHOW_WIN_PLAYER, b);
        z.displayMsg(TEXT_DISPLAY_MSG_PLAYER_WIN);
        m.initMovement(a, K.getX(), K.getY());
        21 === l ? m.initInsuranceMov(K.getX(), K.getY()) : m.initInsuranceMov(Q.getX(), Q.getY())
    };
    this._playerLose = function(a) {
        m.showWinner(a, TEXT_SHOW_LOSE_PLAYER, 0);
        z.displayMsg(TEXT_DISPLAY_MSG_PLAYER_LOSE);
        m.initMovement(a, Q.getX(), Q.getY());
        21 === l ? m.initInsuranceMov(K.getX(), K.getY()) : m.initInsuranceMov(Q.getX(), Q.getY())
    };
    this.playerStandOff = function(a) {
        m.increaseCredit(m.getBetForHand(a));
        N -= m.getBetForHand(a);
        m.showWinner(a, TEXT_SHOW_STANDOFF, 0);
        z.displayMsg(TEXT_DISPLAY_MSG_PLAYER_STANDOFF);
        m.initMovement(a, K.getX(), K.getY());
        21 === l ? m.initInsuranceMov(K.getX(), K.getY()) : m.initInsuranceMov(Q.getX(), Q.getY())
    };
    this._dealing = function() {
        if (q < 2 * G.length) {
            var a = new CCard(O.getX(), O.getY(), T),
                b = new CVector2(O.getX(), O.getY());
            if (1 === q % G.length) {
                k++;
                var c = new CVector2(M.getX() + (CARD_WIDTH + 2) * (1 < q ? 1 : 0), M.getY());
                var d = e ? C.shift() : H[B];
                a.setInfo(b, c, d, s_oGameSettings.getCardValue(d), !0, k);
                L[d] += 1;
                B++;
                2 === k && a.addEventListener(ON_CARD_SHOWN, this._onCardShown)
            } else {
                if (!e && 1 === y && 21 === s_oGameSettings.getCardValue(D[y]) +
                    s_oGameSettings.getCardValue(D[y - 1])) {
                    c = s_oGameSettings.getCardValue(D[y - 1]);
                    do D.shift(); while (21 === c + s_oGameSettings.getCardValue(D[y]))
                }
                a.setInfo(b, m.getAttachCardOffset(), D[y], s_oGameSettings.getCardValue(D[y]), !1, m.newCardDealed());
                L[D[y]] += 1;
                y++
            }
            A.push(a);
            q++;
            a.addEventListener(ON_CARD_ANIMATION_ENDING, this.cardFromDealerArrived);
            a.addEventListener(ON_CARD_TO_REMOVE, this._onRemoveCard);
            playSound("card", 1, !1)
        } else this._checkAvailableActionForPlayer()
    };
    this.hitDealer = function() {
        var a = new CVector2(O.getX(),
                O.getY()),
            b = new CVector2(M.getX() + (CARD_WIDTH + 3) * k, M.getY());
        k++;
        this.attachCardToDeal(a, b, !0, k);
        this.changeState(STATE_GAME_HITTING);
        playSound("card", 1, !1)
    };
    this._checkWinner = function() {
        for (var a = 0; a < m.getNumHands(); a++) 21 < m.getHandValue(a) ? this._playerLose(a) : 21 < l ? this._playerWin(a) : 22 > m.getHandValue(a) && m.getHandValue(a) > l ? this._playerWin(a) : m.getHandValue(a) === l ? this.playerStandOff(a) : this._playerLose(a)
    };
    this._onEndHand = function() {
        for (var a = new CVector2(V.getX(), V.getY()), b = 0; b < I.length; b++) I[b].initRemoving(a),
            I[b].hideCard();
        b = m.getPlayerCards();
        for (var c = 0; c < b.length; c++) b[c].initRemoving(a), b[c].hideCard();
        m.clearText();
        z.clearDealerText();
        t = 0;
        s_oGame.changeState(STATE_GAME_SHOW_WINNER);
        playSound("fiche_collect", 1, !1);
        p++;
        p === AD_SHOW_COUNTER && (p = 0, $(s_oMain).trigger("show_interlevel_ad"))
    };
    this.ficheSelected = function(a, b) {
        var c = m.getCurBet();
        a > m.getCredit() ? R.show(TEXT_NO_MONEY) : c + a > r ? R.show(TEXT_ERROR_MAX_BET) : (c = Number((c + a).toFixed(1)), m.decreaseCredit(a), N += a, m.changeBet(c), m.refreshFiches(a, b, 0,
            0), m.bet(c, !1), z.enable(!0, !1, !1, !1, !1), z.refreshCredit(m.getCredit()))
    };
    this._checkAvailableActionForPlayer = function() {
        this.changeState(-1);
        var a = m.getHandValue(0);
        if (21 === a) m.refreshCardValue(), this._passTurnToDealer();
        else {
            21 < a && m.removeAce();
            m.refreshCardValue();
            a = !1;
            m.isSplitAvailable() && m.getCredit() >= 1.5 * m.getCurBet() && (a = !0);
            z.displayMsg(TEXT_DISPLAY_MSG_YOUR_ACTION);
            var b = !1;
            2 === m.getNumCardsForHand(0) && 8 < m.getHandValue(0) && 16 > m.getHandValue(0) && m.getCredit() >= m.getCurBet() && !c && (b = !0);
            z.enable(!1, !0, !0, b, a);
            11 === I[0].getValue() && m.getCredit() >= m.getCurBet() / 2 && (h = m.getCurBet() / 2, z.showInsurancePanel())
        }
    };
    this._passTurnToDealer = function() {
        b && (b = !1, z.disableButtons(), I[1].showCard(), playSound("card", 1, !1), z.displayMsg(TEXT_DISPLAY_MSG_DEALER_TURN))
    };
    this._gameOver = function() {
        g.show()
    };
    this.onFicheSelected = function(a, b) {
        this.ficheSelected(b, a)
    };
    this._onSetPlayerActions = function(a, b, c, d, f) {
        z.enable(a, b, c, d, f);
        m.refreshCardValue()
    };
    this._onSitDown = function() {
        this.changeState(STATE_GAME_WAITING_FOR_BET);
        z.enableBetFiches()
    };
    this.onDeal = function() {
        m.getCredit() + m.getCurBet() < s_oGameSettings.getFichesValueAt(0) ? this._gameOver() : n > m.getCurBet() ? (R.show(TEXT_ERROR_MIN_BET), s_oInterface.enableBetFiches(), s_oInterface.enable(!0, !1, !1, !1, !1)) : (this.changeState(STATE_GAME_DEALING), $(s_oMain).trigger("bet_placed", m.getCurBet()))
    };
    this.onHit = function() {
        var a = new CVector2(O.getX(), O.getY()),
            b = new CVector2(m.getAttachCardOffset().getX(), m.getAttachCardOffset().getY());
        this.attachCardToDeal(a, b, !1, m.newCardDealed());
        this.changeState(STATE_GAME_HITTING)
    };
    this.onStand = function() {
        m.stand()
    };
    this.onDouble = function() {
        var a = m.getCurBet();
        var b = a + a;
        m.doubleAction(b);
        m.changeBet(b);
        m.decreaseCredit(a);
        N += a;
        N < 2 * b && (e = !1);
        m.bet(b);
        z.refreshCredit(m.getCredit());
        this.onHit();
        f = !0;
        $(s_oMain).trigger("bet_placed", a)
    };
    this.onSplit = function() {
        N < 4 * m.getCurBet() && (e = !1);
        m.split();
        this.changeState(STATE_GAME_SPLIT)
    };
    this._onSplitCardEndAnim = function() {
        var a = m.getCurBet(),
            b = a;
        a += b;
        m.bet(a, !0);
        c = !0;
        z.enable(!1, !0, !0, !1, !1);
        m.setSplitHand();
        m.refreshCardValue();
        m.changeBet(a - b);
        m.decreaseCredit(b);
        N += b;
        z.refreshCredit(m.getCredit());
        $(s_oMain).trigger("bet_placed", b)
    };
    this.clearBets = function() {
        var a = m.getStartingBet();
        0 < a && (m.clearBet(), m.increaseCredit(a), N -= a, z.refreshCredit(m.getCredit()))
    };
    this.rebet = function() {
        this.clearBets();
        m.rebet() ? (z.enable(!0, !1, !1, !1, !1), z.refreshCredit(m.getCredit()), t = BET_TIME) : z.disableRebet()
    };
    this.onBuyInsurance = function() {
        var a = m.getCurBet();
        a += h;
        m.insurance(a, -h, h);
        z.refreshCredit(m.getCredit())
    };
    this._onCardShown = function() {
        s_oGame._checkHand()
    };
    this._onRemoveCard = function(a) {
        a.unload()
    };
    this.onExit = function() {
        this.unload();
        $(s_oMain).trigger("save_score", [m.getCredit()]);
        $(s_oMain).trigger("end_session");
        $(s_oMain).trigger("share_event", m.getCredit());
        s_oMain.gotoMenu()
    };
    this.getState = function() {
        return u
    };
    this._updateWaitingBet = function() {
        t += s_iTimeElaps;
        t > BET_TIME ? (t = 0, m.getCurBet() < n || (z.disableBetFiches(), z.enable(!0, !1, !1, !1, !1), this.changeState(STATE_GAME_DEALING), $(s_oMain).trigger("bet_placed",
            m.getCurBet()))) : z.displayMsg(TEXT_MIN_BET + ":" + n + "\n" + TEXT_MAX_BET + ":" + r, TEXT_DISPLAY_MSG_WAITING_BET + " " + Math.floor((BET_TIME - t) / 1E3))
    };
    this._updateDealing = function() {
        for (var a = 0; a < A.length; a++) A[a].update()
    };
    this._updateHitting = function() {
        for (var a = 0; a < A.length; a++) A[a].update()
    };
    this._updateSplit = function() {
        m.updateSplit()
    };
    this._updateShowWinner = function() {
        m.updateFichesController(s_iTimeElaps);
        for (var a = m.getPlayerCards(), b = 0; b < a.length; b++) a[b].update();
        for (a = 0; a < I.length; a++) I[a].update();
        t += s_iTimeElaps;
        t > TIME_END_HAND && (t = 0, this.reset(!1), z.reset(), m.getCredit() < s_oGameSettings.getFichesValueAt(0) ? (this._gameOver(), this.changeState(-1)) : this.changeState(STATE_GAME_WAITING_FOR_BET), z.refreshCredit(m.getCredit()))
    };
    this.update = function() {
        if (!1 !== d) switch (u) {
            case STATE_GAME_WAITING_FOR_BET:
                this._updateWaitingBet();
                break;
            case STATE_GAME_DEALING:
                this._updateDealing();
                break;
            case STATE_GAME_HITTING:
                this._updateHitting();
                break;
            case STATE_GAME_SPLIT:
                this._updateSplit();
                break;
            case STATE_GAME_SHOW_WINNER:
                this._updateShowWinner()
        }
    };
    s_oGame = this;
    TOTAL_MONEY = a.money;
    MIN_BET = a.min_bet;
    MAX_BET = a.max_bet;
    BET_TIME = a.bet_time;
    BLACKJACK_PAYOUT = a.blackjack_payout;
    WIN_OCCURRENCE = a.win_occurrence;
    var N = a.game_cash;
    AD_SHOW_COUNTER = a.ad_show_counter;
    this._init()
}
var s_oGame, s_oTweenController;

function CInterface(a) {
    var d, b, c, f, e, h, t, r, n, u, q, l, k, v, y, B, p, A, H, I, J, D, G = null,
        L = null;
    this._init = function(a) {
        var C = s_oSpriteLibrary.getSprite("but_exit");
        c = CANVAS_WIDTH - C.width / 2 - 2;
        f = C.height / 2 + 2;
        r = new CGfxButton(c, f, C, !0);
        r.addEventListener(ON_MOUSE_UP, this._onExit, this);
        !1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile ? (e = r.getX() - C.width, h = C.height / 2 + 2, B = new CToggle(e, h, s_oSpriteLibrary.getSprite("audio_icon"), s_bAudioActive, s_oStage), B.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this), d = e - C.width -
            2, b = h) : (d = r.getX() - C.width, b = C.height / 2 + 2);
        C = window.document;
        var M = C.documentElement;
        G = M.requestFullscreen || M.mozRequestFullScreen || M.webkitRequestFullScreen || M.msRequestFullscreen;
        L = C.exitFullscreen || C.mozCancelFullScreen || C.webkitExitFullscreen || C.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (G = !1);
        G && screenfull.enabled && (C = s_oSpriteLibrary.getSprite("but_fullscreen"), D = new CToggle(d, b, C, s_bFullscreen, s_oStage), D.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        C = createBitmap(s_oSpriteLibrary.getSprite("display_bg"));
        C.x = 280;
        C.y = 6;
        s_oStage.addChild(C);
        C = s_oSpriteLibrary.getSprite("bet_bg");
        M = createBitmap(C);
        M.x = 340;
        M.y = CANVAS_HEIGHT - C.height + 4;
        s_oStage.addChild(M);
        C = s_oSpriteLibrary.getSprite("but_game_small_bg");
        n = new CTextButton(444, CANVAS_HEIGHT - 30, C, TEXT_CLEAR, FONT_GAME_1, "#ffffff", 14, s_oStage);
        n.addEventListener(ON_MOUSE_UP, this._onButClearRelease, this);
        u = new CTextButton(632, CANVAS_HEIGHT - 30, C, TEXT_REBET, FONT_GAME_1, "#ffffff", 14, s_oStage);
        u.addEventListener(ON_MOUSE_UP, this._onButRebetRelease, this);
        H = new CTLText(s_oStage,
            400, 18, 190, 40, 24, "left", "#ffde00", FONT_GAME_2, 1, 0, 0, " ", !0, !0, !0, !1);
        I = new CTLText(s_oStage, 400, 60, 190, 40, 18, "left", "#ffde00", FONT_GAME_2, 1, 0, 0, " ", !0, !0, !0, !1);
        A = new createjs.Text("", "20px " + FONT_GAME_1, "#fff");
        A.shadow = new createjs.Shadow("#000000", 2, 2, 1);
        A.x = 758;
        A.y = 180;
        A.textAlign = "right";
        s_oStage.addChild(A);
        C = createBitmap(s_oSpriteLibrary.getSprite("money_bg"));
        C.x = 1127;
        C.y = CANVAS_HEIGHT - 100;
        s_oStage.addChild(C);
        p = new CTLText(s_oStage, 1130, CANVAS_HEIGHT - 95, 224, 29, 29, "center", "#ffde00", FONT_GAME_2,
            1, 0, 0, TEXT_CURRENCY + a.toFixed(2), !0, !0, !0, !1);
        C = s_oSpriteLibrary.getSprite("but_game_bg");
        q = new CTextButton(908, CANVAS_HEIGHT - 30, C, TEXT_DEAL, FONT_GAME_1, "#ffffff", 20, s_oStage);
        q.addEventListener(ON_MOUSE_UP, this._onButDealRelease, this);
        l = new CTextButton(1008, CANVAS_HEIGHT - 30, C, TEXT_HIT, FONT_GAME_1, "#ffffff", 20, s_oStage);
        l.addEventListener(ON_MOUSE_UP, this._onButHitRelease, this);
        k = new CTextButton(1108, CANVAS_HEIGHT - 30, C, TEXT_STAND, FONT_GAME_1, "#ffffff", 20, s_oStage);
        k.addEventListener(ON_MOUSE_UP, this._onButStandRelease,
            this);
        v = new CTextButton(1208, CANVAS_HEIGHT - 30, C, TEXT_DOUBLE, FONT_GAME_1, "#ffffff", 20, s_oStage);
        v.addEventListener(ON_MOUSE_UP, this._onButDoubleRelease, this);
        y = new CTextButton(1308, CANVAS_HEIGHT - 30, C, TEXT_SPLIT, FONT_GAME_1, "#ffffff", 20, s_oStage);
        y.addEventListener(ON_MOUSE_UP, this._onButSplitRelease, this);
        a = [{
            x: 387,
            y: 666
        }, {
            x: 447,
            y: 666
        }, {
            x: 507,
            y: 666
        }, {
            x: 567,
            y: 666
        }, {
            x: 627,
            y: 666
        }, {
            x: 687,
            y: 666
        }];
        t = [];
        M = s_oGameSettings.getFichesValues();
        for (var K = 0; K < NUM_FICHES; K++) t[K] = new CFiche(a[K].x, a[K].y, K, M[K], !0, s_oStage), t[K].addEventListenerWithParams(ON_MOUSE_UP, this._onFicheClicked, this, [M[K], K]);
        J = new CInsurancePanel;
        FICHE_WIDTH = C.width;
        this.disableButtons();
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.unload = function() {
        r.unload();
        r = null;
        !1 === DISABLE_SOUND_MOBILE && (B.unload(), B = null);
        G && screenfull.enabled && D.unload();
        s_oInterface = null
    };
    this.refreshButtonPos = function(a, p) {
        r.setPosition(c - a, p + f);
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || B.setPosition(e - a, p + h);
        G && screenfull.enabled && D.setPosition(d -
            a, b + p)
    };
    this.reset = function() {
        this.disableButtons()
    };
    this.enableBetFiches = function() {
        for (var a = 0; a < NUM_FICHES; a++) t[a].enable();
        n.enable();
        u.enable()
    };
    this.disableBetFiches = function() {
        for (var a = 0; a < NUM_FICHES; a++) t[a].disable();
        n.disable();
        u.disable()
    };
    this.disableRebet = function() {
        u.disable()
    };
    this.disableButtons = function() {
        q.disable();
        l.disable();
        k.disable();
        v.disable();
        y.disable()
    };
    this.enable = function(a, b, c, d, f) {
        a ? q.enable() : q.disable();
        b ? l.enable() : l.disable();
        c ? k.enable() : k.disable();
        d ? v.enable() :
            v.disable();
        f ? y.enable() : y.disable()
    };
    this.refreshCredit = function(a) {
        p.refreshText(TEXT_CURRENCY + a.toFixed(2))
    };
    this.refreshDealerCardValue = function(a) {
        A.text = "" + a
    };
    this.displayMsg = function(a, b) {
        H.refreshText(a);
        void 0 !== b && I.refreshText(b)
    };
    this.showInsurancePanel = function() {
        J.show(TEXT_INSURANCE)
    };
    this.clearDealerText = function() {
        A.text = ""
    };
    this._onFicheClicked = function(a) {
        s_oGame.onFicheSelected(a[1], a[0])
    };
    this._onButClearRelease = function() {
        s_oGame.clearBets()
    };
    this._onButRebetRelease = function() {
        s_oGame.rebet()
    };
    this._onButDealRelease = function() {
        this.disableBetFiches();
        this.disableButtons();
        s_oGame.onDeal()
    };
    this._onButHitRelease = function() {
        this.disableButtons();
        s_oGame.onHit()
    };
    this._onButStandRelease = function() {
        this.disableButtons();
        s_oGame.onStand()
    };
    this._onButDoubleRelease = function() {
        this.disableButtons();
        s_oGame.onDouble()
    };
    this._onButSplitRelease = function() {
        this.disableButtons();
        s_oGame.onSplit()
    };
    this._onExit = function() {
        s_oGame.onExit()
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this.resetFullscreenBut = function() {
        G && screenfull.enabled && D.setActive(s_bFullscreen)
    };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? L.call(window.document) : G.call(window.document.documentElement);
        sizeHandler()
    };
    s_oInterface = this;
    this._init(a);
    return this
}
var s_oInterface = null;

function CTweenController() {
    this.tweenValue = function(a, d, b) {
        return a + b * (d - a)
    };
    this.easeLinear = function(a, d, b, c) {
        return b * a / c + d
    };
    this.easeInCubic = function(a, d, b, c) {
        c = (a /= c) * a * a;
        return d + b * c
    };
    this.easeBackInQuart = function(a, d, b, c) {
        c = (a /= c) * a;
        return d + b * (2 * c * c + 2 * c * a + -3 * c)
    };
    this.easeInBack = function(a, d, b, c) {
        return b * (a /= c) * a * (2.70158 * a - 1.70158) + d
    };
    this.easeOutCubic = function(a, d, b, c) {
        return b * ((a = a / c - 1) * a * a + 1) + d
    }
}

function CSeat() {
    var a, d, b, c, f, e, h, t, r, n, u, q, l, k, v, y, B, p, A, H, I, J, D, G, L;
    this._init = function() {
        n = new createjs.Container;
        n.x = 734;
        n.y = 360;
        var a = createBitmap(s_oSpriteLibrary.getSprite("seat"));
        a.x = 66;
        a.y = 175;
        n.addChild(a);
        a = s_oSpriteLibrary.getSprite("but_game_small_bg");
        v = new CTextButton(115, 221, a, TEXT_SIT_DOWN, FONT_GAME_1, "#ffffff", 20, n);
        v.addEventListener(ON_MOUSE_UP, this._onSitDown, this);
        l = new createjs.Text("", "20px " + FONT_GAME_1, "#ffde00");
        l.shadow = new createjs.Shadow("#000000", 2, 2, 1);
        l.x = 84;
        l.y =
            208;
        l.textAlign = "right";
        n.addChild(l);
        k = new createjs.Text("", "20px " + FONT_GAME_1, "#ffde00");
        k.shadow = new createjs.Shadow("#000000", 2, 2, 1);
        k.x = 175;
        k.y = 208;
        k.textAlign = "left";
        n.addChild(k);
        u = new createjs.Text("", "20px " + FONT_GAME_1, "#ffffff");
        u.shadow = new createjs.Shadow("#000000", 2, 2, 1);
        u.x = 56;
        u.y = 105;
        u.textAlign = "right";
        n.addChild(u);
        q = new createjs.Text("", "20px " + FONT_GAME_1, "#ffffff");
        q.shadow = new createjs.Shadow("#000000", 2, 2, 1);
        q.x = 138;
        q.y = 105;
        q.textAlign = "left";
        n.addChild(q);
        A = new createjs.Text("",
            "20px " + FONT_GAME_1, "#ffffff");
        A.shadow = new createjs.Shadow("#000000", 2, 2, 1);
        A.x = 0;
        A.y = 240;
        A.textAlign = "center";
        n.addChild(A);
        H = new createjs.Text("", "20px " + FONT_GAME_1, "#ffffff");
        H.shadow = new createjs.Shadow("#000000", 2, 2, 1);
        H.x = 150;
        H.y = 240;
        H.textAlign = "left";
        n.addChild(H);
        I = createBitmap(s_oSpriteLibrary.getSprite("arrow_hand"));
        I.visible = !1;
        n.addChild(I);
        s_oStage.addChild(n);
        y = new CVector2;
        y.set(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
        J = new CFichesController({
            x: 834,
            y: 566
        }, y);
        f = 0;
        e = [];
        h = [];
        this.reset();
        B = new CVector2;
        B.set(64, 163);
        r = new CVector2(B.getX(), B.getY());
        p = new CVector2;
        p.set(172, 163);
        G = [];
        L = []
    };
    this.unload = function() {
        s_oStage.removeChild(n)
    };
    this.addEventListener = function(a, b, c) {
        G[a] = b;
        L[a] = c
    };
    this.reset = function() {
        c = b = 0;
        d = a = !1;
        for (var f = 0; f < e.length; f++) e[f].getFichesController().reset();
        e = [];
        f = new CHandController(B, J);
        e.push(f);
        for (f = 0; f < h.length; f++) h[f].unload();
        h = [];
        t = [];
        J.addEventListener(FICHES_END_MOV, this._onFichesEndMove);
        D = null;
        this.clearText()
    };
    this.clearText = function() {
        l.text =
            "";
        k.text = "";
        u.text = "";
        q.text = ""
    };
    this.clearBet = function() {
        J.reset();
        t = [];
        l.text = "";
        e[b].changeBet(0)
    };
    this.addCardToHand = function(a) {
        e[b].addCard(a);
        h.push(a);
        a.addEventListener(ON_CARD_TO_REMOVE, this._onRemoveCard)
    };
    this.increaseHandValue = function(a) {
        e[b].increaseHandValue(a)
    };
    this.refreshCardValue = function() {
        u.text = "" + this.getHandValue(0);
        0 < this.getHandValue(1) && (q.text = "" + this.getHandValue(1))
    };
    this.setCredit = function(a) {
        f = a
    };
    this.increaseCredit = function(a) {
        f += a
    };
    this.changeBet = function(a) {
        e[b].changeBet(a)
    };
    this.checkHand = function() {
        var c = e[b].getValue();
        if (21 === c) this.checkPlayerLastHand(PASS_TURN);
        else if (21 < c) 0 < e[b].getAces() ? (e[b].removeAce(), 21 === e[b].getValue() ? this.checkPlayerLastHand(PASS_TURN) : a ? this.checkPlayerLastHand(PASS_TURN) : G[RESTORE_ACTION] && G[RESTORE_ACTION].call(L[RESTORE_ACTION], !1, !0, !0, !1, !1), this.refreshCardValue()) : 1 < e.length || d ? this.checkPlayerLastHand(PASS_TURN) : this.checkPlayerLastHand(PLAYER_LOSE);
        else if (a) this.checkPlayerLastHand(PASS_TURN);
        else {
            var f = !1;
            2 === e[b].getNumCards() &&
                8 < c && 16 > c ? f = !0 : 0 < this.getAces() && (21 < c ? (c -= 10, this.removeAce(), 8 < c && 16 > c && (f = !0)) : (c -= 10, 2 === e[b].getNumCards() && 8 < c && 16 > c && (f = !0)));
            G[RESTORE_ACTION] && G[RESTORE_ACTION].call(L[RESTORE_ACTION], !1, !0, !0, f, !1)
        }
    };
    this.checkPlayerLastHand = function(a) {
        b--; - 1 < b ? (G[RESTORE_ACTION] && G[RESTORE_ACTION].call(L[RESTORE_ACTION], !1, !0, !0, !1, !1), I.x = B.getX()) : (G[a] && G[a].call(L[a], 0), this.removeArrow())
    };
    this.bet = function(a, b) {
        b ? (l.text = TEXT_CURRENCY + a / 2, k.text = TEXT_CURRENCY + a / 2) : l.text = TEXT_CURRENCY + a
    };
    this.setSplitHand =
        function() {
            for (var a = [], c = 0; c < t.length; c++) a.push(t[c]);
            D = new CFichesController({
                x: 950,
                y: 566
            }, y);
            D.refreshFiches(a, 0, 0, !1);
            D.addEventListener(D.FICHES_END_MOV, this._onFichesEndMove);
            a = new CHandController(p, D);
            e.push(a);
            e[1].addCard(e[0].getCard(1));
            e[0].removeCard(1);
            1 === e[0].getValue() && (e[0].setHandValue(11), e[0].increaseAces());
            e[1].setHandValue(e[0].getValue());
            b = e.length - 1
        };
    this.decreaseCredit = function(a) {
        f -= a
    };
    this.stand = function() {
        this.checkPlayerLastHand(PASS_TURN)
    };
    this.refreshFiches = function(a,
        b, c, d) {
        t.push({
            value: a,
            index: b
        });
        J.refreshFiches(t, c, d)
    };
    this.initMovement = function(a, b, c) {
        this.getFichesController(a).initMovement(b, c, !1)
    };
    this.initInsuranceMov = function(a, b) {
        J.initInsuranceMov(a, b)
    };
    this.showWinner = function(a, b, c) {
        0 < c ? (0 === a ? A.text = b + ": " + c : H.text = b + ": " + c, playSound("win", 1, !1)) : (0 === a ? A.text = b : H.text = b, playSound("lose", 1, !1));
        var d = this;
        0 === a ? createjs.Tween.get(A).to({
            alpha: 1
        }, TIME_SHOW_FINAL_CARDS).call(function() {
            d.endWinAnim()
        }) : createjs.Tween.get(H).to({
            alpha: 1
        }, TIME_SHOW_FINAL_CARDS).call(function() {
            d.endWinAnim()
        });
        $(s_oMain).trigger("save_score", [f])
    };
    this.endWinAnim = function() {
        A && H && (A.text = "", H.text = "", G[END_HAND] && G[END_HAND].call(L[END_HAND]))
    };
    this.newCardDealed = function() {
        c++;
        return c
    };
    this.removeAce = function() {
        e[b].removeAce()
    };
    this.removeArrow = function() {
        I.visible = !1
    };
    this.doubleAction = function(a) {
        e[b].changeBet(a);
        a = [];
        for (var c = 0; c < t.length; c++) a.push(t[c]);
        1 < e.length ? 1 === b ? D.refreshFiches(a, 0, 40) : J.refreshFiches(a, 0, 40) : J.refreshFiches(a, 0, 40)
    };
    this.split = function() {
        h[0].initSplit(new CVector2(n.x +
            B.getX(), n.y + B.getY()));
        h[1].initSplit(new CVector2(n.x + p.getX(), n.y + p.getY()));
        h[1].addEventListener(SPLIT_CARD_END_ANIM, this._onSplitCardEndAnim)
    };
    this.insurance = function(a, b, c) {
        this.changeBet(a);
        this.increaseCredit(b);
        a = J.createFichesPile(c, !0);
        t = [];
        for (b = 0; b < a.length; b++) t.push({
            value: a[b].value,
            index: a[b].index
        });
        d = !0
    };
    this.rebet = function() {
        var a = J.getPrevBet();
        if (a > f || 0 === a) return !1;
        this.decreaseCredit(a);
        this.changeBet(a);
        var b = J.createFichesPile(a, !1);
        t = [];
        for (var c = 0; c < b.length; c++) t.push({
            value: b[c].value,
            index: b[c].index
        });
        this.bet(a, !1);
        return !0
    };
    this._onSitDown = function() {
        v.setVisible(!1);
        G[SIT_DOWN] && G[SIT_DOWN].call(L[SIT_DOWN])
    };
    this._onFichesEndMove = function() {
        G[ASSIGN_FICHES] && G[ASSIGN_FICHES].call(L[ASSIGN_FICHES])
    };
    this._onRemoveCard = function(a) {
        for (var b = 0; b < h.length; b++)
            if (h[b] === a) {
                h.splice(b, 1);
                break
            }
    };
    this._onSplitCardEndAnim = function() {
        s_oGame._onSplitCardEndAnim();
        I.x = p.getX();
        I.y = p.getY() + 70;
        I.visible = !0
    };
    this.updateFichesController = function(a) {
        D && D.update(a);
        J.update(a)
    };
    this.updateSplit =
        function() {
            for (var a = 0; a < h.length; a++) h[a].update(s_iTimeElaps)
        };
    this.isSplitAvailable = function() {
        return h[0] && h[1] ? 0 === Math.abs(h[0].getFotogram() - h[1].getFotogram()) % 13 ? !0 : !1 : !1
    };
    this.getAttachCardOffset = function() {
        if (0 === b) r.set(n.x + B.getX() + CARD_WIDTH / 2 * e[b].getNumCards(), n.y + B.getY() - CARD_HEIGHT / 2 * e[b].getNumCards());
        else {
            var a = n.x + p.getX() + CARD_WIDTH / 2 * e[b].getNumCards(),
                c = n.y + p.getY() - CARD_HEIGHT / 2 * e[b].getNumCards();
            r.set(a, c)
        }
        return r
    };
    this.getCurBet = function() {
        return e[b].getCurBet()
    };
    this.getCredit =
        function() {
            return f
        };
    this.getHandValue = function(a) {
        return a > e.length - 1 ? 0 : e[a].getValue()
    };
    this.getNumHands = function() {
        return e.length
    };
    this.getNumCardsForHand = function(a) {
        return e[a].getNumCards()
    };
    this.getBetForHand = function(a) {
        return e[a].getCurBet()
    };
    this.getAces = function() {
        return e[b].getAces()
    };
    this.getFichesController = function(a) {
        return e[a].getFichesController()
    };
    this.getCardOffset = function() {
        return B
    };
    this.getPlayerCards = function() {
        return h
    };
    this.getStartingBet = function() {
        return J.getValue()
    };
    this._init()
}

function CFichesController(a, d) {
    var b, c, f, e, h, t, r, n, u, q, l, k, v, y, B;
    this._init = function(a, d) {
        k = new createjs.Container;
        k.x = a.x;
        k.y = a.y;
        s_oStage.addChild(k);
        v = new createjs.Container;
        v.x = 400;
        v.y = 230;
        s_oStage.addChild(v);
        r = new CVector2;
        r.set(k.x, k.y);
        q = new CVector2;
        q.setV(d);
        h = t = e = 0;
        c = b = !1;
        y = [];
        B = []
    };
    this.addEventListener = function(a, b, c) {
        y[a] = b;
        B[a] = c
    };
    this.reset = function() {
        f = b = !1;
        h = 0;
        k.removeAllChildren();
        v.removeAllChildren();
        k.x = r.getX();
        k.y = r.getY();
        v.x = q.getX();
        v.y = q.getY()
    };
    this.refreshFiches = function(a,
        c, d, f) {
        a = a.sortOn("value", "index");
        var e = d;
        f && (b = !0);
        for (var p = h = 0, l = 0; l < a.length; l++) {
            var n = k;
            f && (n = v);
            (new CFiche(c, e, a[l].index, a[l].value, !1, n)).setScale(.7);
            e -= 5;
            p++;
            9 < p && (p = 0, c += FICHE_WIDTH, e = d);
            h += a[l].value
        }
        playSound("chip", 1, !1)
    };
    this.createFichesPile = function(a, b) {
        var c = s_oGameSettings.getFichesValues(),
            d = [];
        do {
            for (var f = c[c.length - 1], e = c.length - 1; f > a;) e--, f = c[e];
            e = Math.floor(a / f);
            for (var h = 0; h < e; h++) d.push({
                value: f,
                index: s_oGameSettings.getIndexForFiches(f)
            });
            f = a % f;
            a = f = parseFloat(f.toFixed(2))
        } while (0 <
            f);
        this.refreshFiches(d, 0, 0, b);
        return d
    };
    this.rebet = function() {
        this.createFichesPile(t, !1)
    };
    this.initMovement = function(a, b, d) {
        t = h;
        c = d;
        n = new CVector2(k.x, k.y);
        u = new CVector2(a, b)
    };
    this.initInsuranceMov = function(a, b) {
        l = new CVector2(a, b)
    };
    this.getValue = function() {
        return h
    };
    this.getPrevBet = function() {
        return t
    };
    this._updateInsuranceFiches = function() {
        if (b) {
            var a = easeInOutCubic(e, 0, 1, TIME_FICHES_MOV);
            a = tweenVectors(q, l, a, new CVector2);
            v.x = a.getX();
            v.y = a.getY()
        }
    };
    this.update = function(a) {
        if (!f)
            if (e += a, e > TIME_FICHES_MOV) e =
                0, f = !0, y[FICHES_END_MOV] && y[FICHES_END_MOV].call(B[FICHES_END_MOV], c, h);
            else {
                a = easeInOutCubic(e, 0, 1, TIME_FICHES_MOV);
                var b = new CVector2;
                b = tweenVectors(n, u, a, b);
                k.x = b.getX();
                k.y = b.getY();
                this._updateInsuranceFiches()
            }
    };
    this._init(a, d)
}

function CVector2(a, d) {
    var b, c;
    this._init = function(a, d) {
        b = a;
        c = d
    };
    this.add = function(a, d) {
        b += a;
        c += d
    };
    this.addV = function(a) {
        b += a.getX();
        c += a.getY()
    };
    this.scalarDivision = function(a) {
        b /= a;
        c /= a
    };
    this.subV = function(a) {
        b -= a.getX();
        c -= a.getY()
    };
    this.scalarProduct = function(a) {
        b *= a;
        c *= a
    };
    this.invert = function() {
        b *= -1;
        c *= -1
    };
    this.dotProduct = function(a) {
        return b * a.getX() + c * a.getY()
    };
    this.set = function(a, d) {
        b = a;
        c = d
    };
    this.setV = function(a) {
        b = a.getX();
        c = a.getY()
    };
    this.length = function() {
        return Math.sqrt(b * b + c * c)
    };
    this.length2 =
        function() {
            return b * b + c * c
        };
    this.normalize = function() {
        var a = this.length();
        0 < a && (b /= a, c /= a)
    };
    this.getNormalize = function(a) {
        this.length();
        a.set(b, c);
        a.normalize()
    };
    this.rot90CCW = function() {
        var a = b;
        b = -c;
        c = a
    };
    this.rot90CW = function() {
        var a = b;
        b = c;
        c = -a
    };
    this.getRotCCW = function(a) {
        a.set(b, c);
        a.rot90CCW()
    };
    this.getRotCW = function(a) {
        a.set(b, c);
        a.rot90CW()
    };
    this.ceil = function() {
        b = Math.ceil(b);
        c = Math.ceil(c)
    };
    this.round = function() {
        b = Math.round(b);
        c = Math.round(c)
    };
    this.toString = function() {
        return "Vector2: " + b + ", " +
            c
    };
    this.print = function() {
        trace("Vector2: " + b + ", " + c)
    };
    this.getX = function() {
        return b
    };
    this.getY = function() {
        return c
    };
    this._init(a, d)
}

function CGameSettings() {
    var a, d, b, c;
    this._init = function() {
        b = [];
        a = [];
        for (var d = 0; 2 > d; d++)
            for (var e = 0; 52 > e; e++) {
                a.push(e);
                var h = (e + 1) % 13;
                if (10 < h || 0 === h) h = 10;
                1 === h && (h = 11);
                b.push(h)
            }
        c = [.1, 1, 5, 10, 25, 100]
    };
    this.getFichesValues = function() {
        return c
    };
    this.getFichesValueAt = function(a) {
        return c[a]
    };
    this.getIndexForFiches = function(a) {
        for (var b = 0, d = 0; d < c.length; d++) c[d] === a && (b = d);
        return b
    };
    this.generateFichesPile = function(a) {
        var b = [],
            d = c.length - 1,
            f = c[d];
        do {
            var r = a % f;
            r = CMath.roundDecimal(r, 1);
            a = Math.floor(a /
                f);
            for (var n = 0; n < a; n++) b.push(f);
            d--;
            f = c[d];
            a = r
        } while (0 < r && -1 < d);
        return b
    };
    this.timeToString = function(a) {
        a = Math.round(a / 1E3);
        var b = Math.floor(a / 60);
        a -= 60 * b;
        var c = "";
        c = 10 > b ? c + ("0" + b + ":") : c + (b + ":");
        return 10 > a ? c + ("0" + a) : c + a
    };
    this.getShuffledCardDeck = function() {
        for (var b = [], c = 0; c < a.length; c++) b[c] = a[c];
        for (d = []; 0 < b.length;) d.push(b.splice(Math.round(Math.random() * (b.length - 1)), 1)[0]);
        return d
    };
    this.getCardValue = function(a) {
        return b[a]
    };
    this.getRandDealerPattern = function() {
        var a;
        do {
            var b = [];
            for (var c =
                    a = 0; 2 > c; c++) {
                do var d = Math.floor(52 * Math.random()); while (11 === this.getCardValue(d));
                a += this.getCardValue(d);
                b.push(d)
            }
        } while (12 > a || 16 < a);
        a = 21 - a;
        do c = Math.floor(52 * Math.random()); while (this.getCardValue(c) <= a || 11 === this.getCardValue(c));
        b.push(c);
        return b
    };
    this._init()
}
var TYPE_LINEAR = 0,
    TYPE_OUT_CUBIC = 1,
    TYPE_IN_CUBIC = 2,
    TYPE_OUT_BACK = 3,
    TYPE_IN_BACK = 4;

function ease(a, d, b, c, f, e) {
    switch (a) {
        case TYPE_LINEAR:
            var h = easeLinear(d, b, c, f, e);
            break;
        case TYPE_IN_CUBIC:
            h = easeInCubic(d, b, c, f, e);
            break;
        case TYPE_OUT_CUBIC:
            h = easeOutCubic(d, b, c, f, e);
            break;
        case TYPE_IN_BACK:
            h = easeInBack(d, b, c, f, e);
            break;
        case TYPE_OUT_BACK:
            h = easeInBack(d, b, c, f, e)
    }
    return h
}

function easeOutBounce(a, d, b, c) {
    return (a /= c) < 1 / 2.75 ? 7.5625 * b * a * a + d : a < 2 / 2.75 ? b * (7.5625 * (a -= 1.5 / 2.75) * a + .75) + d : a < 2.5 / 2.75 ? b * (7.5625 * (a -= 2.25 / 2.75) * a + .9375) + d : b * (7.5625 * (a -= 2.625 / 2.75) * a + .984375) + d
}

function easeInBounce(a, d, b, c) {
    return b - easeOutBounce(c - a, 0, b, c) + d
}

function easeInOutBounce(a, d, b, c) {
    return a < c / 2 ? .5 * easeInBounce(2 * a, 0, b, c) + d : .5 * easeOutBounce(2 * a - c, 0, b, c) + .5 * b + d
}

function easeInCirc(a, d, b, c) {
    return -b * (Math.sqrt(1 - (a /= c) * a) - 1) + d
}

function easeOutCirc(a, d, b, c) {
    return b * Math.sqrt(1 - (a = a / c - 1) * a) + d
}

function easeInOutCirc(a, d, b, c) {
    return 1 > (a /= c / 2) ? -b / 2 * (Math.sqrt(1 - a * a) - 1) + d : b / 2 * (Math.sqrt(1 - (a -= 2) * a) + 1) + d
}

function easeInCubic(a, d, b, c, f) {
    return b * (a /= c) * a * a + d
}

function easeOutCubic(a, d, b, c, f) {
    return b * ((a = a / c - 1) * a * a + 1) + d
}

function easeInOutCubic(a, d, b, c, f) {
    return 1 > (a /= c / 2) ? b / 2 * a * a * a + d : b / 2 * ((a -= 2) * a * a + 2) + d
}

function easeInElastic(a, d, b, c, f, e, h) {
    if (0 == a) return d;
    if (1 == (a /= c)) return d + b;
    h || (h = .3 * c);
    !e || e < Math.abs(b) ? (e = b, f = h / 4) : f = h / (2 * Math.PI) * Math.asin(b / e);
    return -(e * Math.pow(2, 10 * --a) * Math.sin(2 * (a * c - f) * Math.PI / h)) + d
}

function easeOutElastic(a, d, b, c, f, e, h) {
    if (0 == a) return d;
    if (1 == (a /= c)) return d + b;
    h || (h = .3 * c);
    !e || e < Math.abs(b) ? (e = b, f = h / 4) : f = h / (2 * Math.PI) * Math.asin(b / e);
    return e * Math.pow(2, -10 * a) * Math.sin(2 * (a * c - f) * Math.PI / h) + b + d
}

function easeInOutElastic(a, d, b, c, f, e, h) {
    if (0 == a) return d;
    if (1 == (a /= c)) return d + b;
    h || (h = .3 * c);
    !e || e < Math.abs(b) ? (e = b, f = h / 4) : f = h / (2 * Math.PI) * Math.asin(b / e);
    return 1 > a ? -.5 * e * Math.pow(2, 10 * --a) * Math.sin(2 * (a * c - f) * Math.PI / h) + d : e * Math.pow(2, -10 * --a) * Math.sin(2 * (a * c - f) * Math.PI / h) * .5 + b + d
}

function easeInExpo(a, d, b, c) {
    return 0 == a ? d : b * Math.pow(2, 10 * (a / c - 1)) + d
}

function easeOutExpo(a, d, b, c) {
    return a == c ? d + b : b * (-Math.pow(2, -10 * a / c) + 1) + d
}

function easeInOutExpo(a, d, b, c) {
    return 0 == a ? d : a == c ? d + b : 1 > (a /= c / 2) ? b / 2 * Math.pow(2, 10 * (a - 1)) + d : b / 2 * (-Math.pow(2, -10 * --a) + 2) + d
}

function easeLinear(a, d, b, c) {
    return b * a / c + d
}

function easeInQuad(a, d, b, c) {
    return b * (a /= c) * a + d
}

function easeOutQuad(a, d, b, c) {
    return -b * (a /= c) * (a - 2) + d
}

function easeInOutQuad(a, d, b, c) {
    return 1 > (a /= c / 2) ? b / 2 * a * a + d : -b / 2 * (--a * (a - 2) - 1) + d
}

function easeInQuart(a, d, b, c) {
    return b * (a /= c) * a * a * a + d
}

function easeOutQuart(a, d, b, c) {
    return -b * ((a = a / c - 1) * a * a * a - 1) + d
}

function easeInOutQuart(a, d, b, c) {
    return 1 > (a /= c / 2) ? b / 2 * a * a * a * a + d : -b / 2 * ((a -= 2) * a * a * a - 2) + d
}

function easeInQuint(a, d, b, c) {
    return b * (a /= c) * a * a * a * a + d
}

function easeOutQuint(a, d, b, c) {
    return b * ((a = a / c - 1) * a * a * a * a + 1) + d
}

function easeInOutQuint(a, d, b, c) {
    return 1 > (a /= c / 2) ? b / 2 * a * a * a * a * a + d : b / 2 * ((a -= 2) * a * a * a * a + 2) + d
}

function easeInSine(a, d, b, c) {
    return -b * Math.cos(a / c * (Math.PI / 2)) + b + d
}

function easeOutSine(a, d, b, c) {
    return b * Math.sin(a / c * (Math.PI / 2)) + d
}

function easeInOutSine(a, d, b, c) {
    return -b / 2 * (Math.cos(Math.PI * a / c) - 1) + d
}

function easeInBack(a, d, b, c) {
    return b * (a /= c) * a * (2.70158 * a - 1.70158) + d
}

function easeOutBack(a, d, b, c) {
    return b * ((a = a / c - 1) * a * (2.70158 * a + 1.70158) + 1) + d
}

function CHandController(a, d) {
    var b, c, f, e, h, t;
    this._init = function(a, d) {
        f = c = b = 0;
        e = [];
        h = a;
        t = d
    };
    this.addCard = function(a) {
        e.push(a);
        11 === a.getValue() && c++
    };
    this.removeCard = function(a) {
        var d = e[a];
        b -= d.getValue();
        11 === d.getValue() && c--;
        e.splice(a, 1)
    };
    this.changeBet = function(a) {
        f = a
    };
    this.removeAce = function() {
        b -= 10;
        c--
    };
    this.setHandValue = function(a) {
        b = a
    };
    this.increaseAces = function() {
        c++
    };
    this.increaseHandValue = function(a) {
        b += a
    };
    this.getValue = function() {
        return b
    };
    this.getCurBet = function() {
        return f
    };
    this.getDoubleBet =
        function() {
            return f
        };
    this.getAces = function() {
        return c
    };
    this.getCard = function(a) {
        return e[a]
    };
    this.getNumCards = function() {
        return e.length
    };
    this.getAttachOffset = function() {
        return h
    };
    this.getFichesController = function() {
        return t
    };
    this._init(a, d)
}

function CCard(a, d, b) {
    var c, f, e = -1,
        h, t, r, n, u, q, l, k, v, y;
    this._init = function(a, b, c) {
        y = c;
        c = {
            images: [s_oSpriteLibrary.getSprite("card_spritesheet")],
            frames: {
                width: CARD_WIDTH,
                height: CARD_HEIGHT,
                regX: CARD_WIDTH / 2,
                regY: CARD_HEIGHT / 2
            },
            animations: {
                card_1_1: [0],
                card_1_2: [1],
                card_1_3: [2],
                card_1_4: [3],
                card_1_5: [4],
                card_1_6: [5],
                card_1_7: [6],
                card_1_8: [7],
                card_1_9: [8],
                card_1_10: [9],
                card_1_J: [10],
                card_1_Q: [11],
                card_1_K: [12],
                card_2_1: [13],
                card_2_2: [14],
                card_2_3: [15],
                card_2_4: [16],
                card_2_5: [17],
                card_2_6: [18],
                card_2_7: [19],
                card_2_8: [20],
                card_2_9: [21],
                card_2_10: [22],
                card_2_J: [23],
                card_2_Q: [24],
                card_2_K: [25],
                card_3_1: [26],
                card_3_2: [27],
                card_3_3: [28],
                card_3_4: [29],
                card_3_5: [30],
                card_3_6: [31],
                card_3_7: [32],
                card_3_8: [33],
                card_3_9: [34],
                card_3_10: [35],
                card_3_J: [36],
                card_3_Q: [37],
                card_3_K: [38],
                card_4_1: [39],
                card_4_2: [40],
                card_4_3: [41],
                card_4_4: [42],
                card_4_5: [43],
                card_4_6: [44],
                card_4_7: [45],
                card_4_8: [46],
                card_4_9: [47],
                card_4_10: [48],
                card_4_J: [49],
                card_4_Q: [50],
                card_4_K: [51],
                back: [52]
            }
        };
        c = new createjs.SpriteSheet(c);
        v = createSprite(c,
            "back", CARD_WIDTH / 2, CARD_HEIGHT / 2, CARD_WIDTH, CARD_HEIGHT);
        v.x = a;
        v.y = b;
        v.stop();
        y.addChild(v);
        l = [];
        k = []
    };
    this.unload = function() {
        q = u = null;
        y.removeChild(v)
    };
    this.addEventListener = function(a, b, c) {
        l[a] = b;
        k[a] = c
    };
    this.setInfo = function(a, b, d, k, l, v) {
        f = !1;
        n = 0;
        h = d;
        t = k;
        u = a;
        q = b;
        r = v;
        c = l;
        e = STATE_CARD_DEALING
    };
    this.removeFromTable = function() {
        l[ON_CARD_TO_REMOVE] && l[ON_CARD_TO_REMOVE].call(k[ON_CARD_TO_REMOVE], this)
    };
    this.initSplit = function(a) {
        u = new CVector2(v.x, v.y);
        q = a;
        n = 0;
        e = STATE_CARD_SPLIT
    };
    this.initRemoving =
        function(a) {
            u = new CVector2(v.x, v.y);
            q = a;
            n = 0;
            e = STATE_CARD_REMOVING
        };
    this.setValue = function() {
        v.gotoAndStop(h);
        var a = this;
        createjs.Tween.get(v).to({
            scaleX: 1
        }, 100).call(function() {
            a.cardShown()
        })
    };
    this.showCard = function() {
        var a = this;
        createjs.Tween.get(v).to({
            scaleX: .1
        }, 100).call(function() {
            a.setValue()
        })
    };
    this.hideCard = function() {
        var a = this;
        createjs.Tween.get(v).to({
            scaleX: .1
        }, 100).call(function() {
            a.setBack()
        })
    };
    this.setBack = function() {
        v.gotoAndStop("back");
        var a = this;
        createjs.Tween.get(v).to({
                scaleX: 1
            },
            100).call(function() {
            a.cardHidden()
        })
    };
    this.cardShown = function() {
        l[ON_CARD_SHOWN] && l[ON_CARD_SHOWN].call(k[ON_CARD_SHOWN])
    };
    this.cardHidden = function() {
        f = !0
    };
    this.getValue = function() {
        return t
    };
    this.getFotogram = function() {
        return h
    };
    this._updateDealing = function() {
        n += s_iTimeElaps;
        if (n > TIME_CARD_DEALING) e = -1, n = 0, v.x = q.getX(), v.y = q.getY(), v.rotation = 360, l[ON_CARD_ANIMATION_ENDING] && l[ON_CARD_ANIMATION_ENDING].call(k[ON_CARD_ANIMATION_ENDING], this, c, r), !1 === (c && 2 === r) && this.showCard();
        else {
            this.visible = !0;
            var a = easeInOutCubic(n, 0, 1, TIME_CARD_DEALING),
                b = new CVector2;
            b = tweenVectors(u, q, a, b);
            v.x = b.getX();
            v.y = b.getY();
            !1 === c && (v.rotation = 36E3 * a / 100)
        }
    };
    this._updateSplit = function() {
        n += s_iTimeElaps;
        if (n > TIME_CARD_DEALING) n = 0, l[SPLIT_CARD_END_ANIM] && l[SPLIT_CARD_END_ANIM].call(k[SPLIT_CARD_END_ANIM]), e = -1;
        else {
            var a = easeInOutCubic(n, 0, 1, TIME_CARD_DEALING),
                b = new CVector2;
            b = tweenVectors(u, q, a, b);
            v.x = b.getX();
            v.y = b.getY()
        }
    };
    this._updateRemoving = function() {
        n += s_iTimeElaps;
        if (n > TIME_CARD_REMOVE) n = 0, f = v.visible = !1, e = -1, l[ON_CARD_TO_REMOVE] && l[ON_CARD_TO_REMOVE].call(k[ON_CARD_TO_REMOVE], this);
        else {
            var a = easeInOutCubic(n, 0, 1, TIME_CARD_REMOVE),
                b = new CVector2;
            b = tweenVectors(u, q, a, b);
            v.x = b.getX();
            v.y = b.getY();
            v.rotation = 4500 * a / 100
        }
    };
    this.update = function() {
        switch (e) {
            case STATE_CARD_DEALING:
                this._updateDealing();
                break;
            case STATE_CARD_SPLIT:
                this._updateSplit();
                break;
            case STATE_CARD_REMOVING:
                !0 === f && this._updateRemoving()
        }
    };
    s_oCard = this;
    this._init(a, d, b)
}
var s_oCard;

function CInsurancePanel() {
    var a, d, b, c;
    this._init = function() {
        c = new createjs.Container;
        s_oStage.addChild(c);
        c.visible = !1;
        var f = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        c.addChild(f);
        b = new CTLText(c, CANVAS_WIDTH / 2 - 190, 290, 360, 100, 50, "center", "#fff", FONT_GAME_1, 1, 0, 0, " ", !0, !0, !0, !1);
        b.setShadow("#000000", 2, 2, 2);
        f = s_oSpriteLibrary.getSprite("but_game_small_bg");
        a = new CTextButton(CANVAS_WIDTH / 2 - 100, CANVAS_HEIGHT - 300, f, TEXT_NO, FONT_GAME_1, "#ffffff", 20, c);
        a.addEventListener(ON_MOUSE_UP, this._onButNoRelease,
            this);
        d = new CTextButton(CANVAS_WIDTH / 2 + 100, CANVAS_HEIGHT - 300, f, TEXT_YES, FONT_GAME_1, "#ffffff", 20, c);
        d.addEventListener(ON_MOUSE_UP, this._onButYesRelease, this)
    };
    this.unload = function() {
        s_oStage.removeChild(c)
    };
    this.show = function(a) {
        b.refreshText(a);
        c.visible = !0
    };
    this._onButNoRelease = function() {
        c.visible = !1
    };
    this._onButYesRelease = function() {
        c.visible = !1;
        s_oGame.onBuyInsurance()
    };
    this._init()
}

function CGameOver() {
    var a, d, b, c;
    this._init = function() {
        c = new createjs.Container;
        s_oStage.addChild(c);
        c.on("click", function() {});
        var f = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        c.addChild(f);
        a = new CTLText(c, CANVAS_WIDTH / 2 - 190, 290, 360, 100, 32, "center", "#fff", FONT_GAME_1, 1, 0, 0, TEXT_NO_MONEY, !0, !0, !0, !1);
        a.setShadow("#000000", 2, 2, 2);
        d = new CTextButton(CANVAS_WIDTH / 2 - 100, 450, s_oSpriteLibrary.getSprite("but_game_bg"), TEXT_RECHARGE, FONT_GAME_1, "#fff", 14, c);
        d.addEventListener(ON_MOUSE_UP, this._onRecharge,
            this);
        b = new CTextButton(CANVAS_WIDTH / 2 + 100, 450, s_oSpriteLibrary.getSprite("but_game_bg"), TEXT_EXIT, FONT_GAME_1, "#fff", 14, c);
        b.addEventListener(ON_MOUSE_UP, this._onExit, this);
        this.hide()
    };
    this.unload = function() {
        d.unload();
        b.unload();
        c.off("click", function() {})
    };
    this.show = function() {
        c.visible = !0
    };
    this.hide = function() {
        c.visible = !1
    };
    this._onRecharge = function() {
        c.visible = !1;
        $(s_oMain).trigger("recharge")
    };
    this._onExit = function() {
        c.visible = !1;
        s_oInterface.enableBetFiches();
        s_oInterface.enable(!0, !1, !1, !1, !1)
    };
    this._init()
}

function CMsgBox() {
    var a, d, b;
    this._init = function() {
        b = new createjs.Container;
        b.alpha = 0;
        b.visible = !1;
        s_oStage.addChild(b);
        a = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        b.addChild(a);
        d = new CTLText(b, CANVAS_WIDTH / 2 - 180, CANVAS_HEIGHT / 2 - 50, 360, 100, 34, "center", "#fff", FONT_GAME_1, 1, 0, 0, " ", !0, !0, !0, !1);
        d.setShadow("#000", 2, 2, 2)
    };
    this.unload = function() {
        b.off("mousedown", this._onExit)
    };
    this._initListener = function() {
        b.on("mousedown", this._onExit)
    };
    this.show = function(a) {
        d.refreshText(a);
        b.visible = !0;
        var c = this;
        createjs.Tween.get(b).to({
            alpha: 1
        }, 500).call(function() {
            c._initListener()
        });
        setTimeout(function() {
            c._onExit()
        }, 3E3)
    };
    this._onExit = function() {
        b.visible && (b.off("mousedown"), b.visible = !1)
    };
    this._init();
    return this
}

function CCreditsPanel() {
    var a, d, b, c, f, e, h, t, r, n, u;
    this._init = function() {
        u = new createjs.Container;
        u.alpha = 0;
        s_oStage.addChild(u);
        var q = new createjs.Shape;
        q.graphics.beginFill("rgba(0,0,0,0.7)").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        u.addChild(q);
        b = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        u.addChild(b);
        t = new createjs.Shape;
        t.graphics.beginFill("#0f0f0f").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        t.alpha = .01;
        t.on("click", this._onLogoButRelease);
        u.addChild(t);
        q = s_oSpriteLibrary.getSprite("but_menu_bg");
        a = CANVAS_WIDTH / 2;
        d = CANVAS_HEIGHT - 164;
        f = new CTextButton(a, d, q, TEXT_EXIT, FONT_GAME_1, "#ffffff", 40, s_oStage);
        f.addEventListener(ON_MOUSE_UP, this.unload, this);
        h = new createjs.Text(TEXT_CREDITS_DEVELOPED, "38px " + FONT_GAME_1, "#000");
        h.textAlign = "center";
        h.textBaseline = "alphabetic";
        h.x = CANVAS_WIDTH / 2;
        h.y = 330;
        h.outline = 2;
        u.addChild(h);
        e = new createjs.Text(TEXT_CREDITS_DEVELOPED, "38px " + FONT_GAME_1, "#fff");
        e.textAlign = "center";
        e.textBaseline = "alphabetic";
        e.x = CANVAS_WIDTH / 2;
        e.y = 330;
        u.addChild(e);
        q = s_oSpriteLibrary.getSprite("logo_ctl");
        c = createBitmap(q);
        c.regX = q.width / 2;
        c.regY = q.height / 2;
        c.x = CANVAS_WIDTH / 2;
        c.y = CANVAS_HEIGHT / 2;
        u.addChild(c);
        n = new createjs.Text("www.codethislab.com", "30px " + FONT_GAME_1, "#000");
        n.textAlign = "center";
        n.textBaseline = "alphabetic";
        n.x = CANVAS_WIDTH / 2;
        n.y = 460;
        n.outline = 2;
        u.addChild(n);
        r = new createjs.Text("www.codethislab.com", "30px " + FONT_GAME_1, "#fff");
        r.textAlign = "center";
        r.textBaseline = "alphabetic";
        r.x = CANVAS_WIDTH / 2;
        r.y = 460;
        u.addChild(r);
        createjs.Tween.get(u).to({
            alpha: 1
        }, 600, createjs.Ease.cubicOut);
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.refreshButtonPos = function(a, b) {};
    this.unload = function() {
        t.off("click", this._onLogoButRelease);
        f.unload();
        f = null;
        s_oStage.removeChild(u)
    };
    this._onLogoButRelease = function() {
        window.open("http://www.codethislab.com/index.php?&l=en", "_blank")
    };
    this._init()
}

function CFiche(a, d, b, c, f, e) {
    var h, t, r, n, u, q, l, k;
    this._init = function(a, b, c, d, f) {
        k = new createjs.Container;
        k.x = a;
        k.y = b;
        e.addChild(k);
        a = s_oSpriteLibrary.getSprite("fiche_" + c);
        l = createBitmap(a);
        k.addChild(l);
        new CTLText(k, 9, 7, 22, 18, SIZE_FONT_FICHE[c], "center", COLOR_FICHE_PER_VALUE[c], FONT_GAME_1, 1, 0, 0, d, !0, !0, !1, !1);
        f && (h = !1, t = a.width, r = a.height, n = [], u = [], k.on("mousedown", this.buttonDown), k.on("pressup", this.buttonRelease))
    };
    this.addEventListener = function(a, b, c) {
        n[a] = b;
        u[a] = c
    };
    this.addEventListenerWithParams =
        function(a, b, c, d) {
            n[a] = b;
            u[a] = c;
            q = d
        };
    this.enable = function() {
        h = !1;
        k.filters = [];
        k.cache(0, 0, t, r)
    };
    this.disable = function() {
        h = !0;
        var a = (new createjs.ColorMatrix).adjustSaturation(-100).adjustBrightness(40);
        k.filters = [new createjs.ColorMatrixFilter(a)];
        k.cache(0, 0, t, r)
    };
    this.setScale = function(a) {
        k.scaleX = a;
        k.scaleY = a
    };
    this.buttonRelease = function() {
        h || (playSound("press_but", 1, !1), k.scaleX = 1, k.scaleY = 1, n[ON_MOUSE_UP] && n[ON_MOUSE_UP].call(u[ON_MOUSE_UP], q))
    };
    this.buttonDown = function() {
        h || (k.scaleX = .9, k.scaleY =
            .9, n[ON_MOUSE_DOWN] && n[ON_MOUSE_DOWN].call(u[ON_MOUSE_DOWN], q))
    };
    this._init(a, d, b, c, f)
}
CTLText.prototype = {
    constructor: CTLText,
    __autofit: function() {
        if (this._bFitText) {
            for (var a = this._iFontSize;
                (this._oText.getBounds().height > this._iHeight - 2 * this._iPaddingV || this._oText.getBounds().width > this._iWidth - 2 * this._iPaddingH) && !(a--, this._oText.font = a + "px " + this._szFont, this._oText.lineHeight = Math.round(a * this._fLineHeightFactor), this.__updateY(), this.__verticalAlign(), 8 > a););
            this._iFontSize = a
        }
    },
    __verticalAlign: function() {
        if (this._bVerticalAlign) {
            var a = this._oText.getBounds().height;
            this._oText.y -=
                (a - this._iHeight) / 2 + this._iPaddingV
        }
    },
    __updateY: function() {
        this._oText.y = this._y + this._iPaddingV;
        switch (this._oText.textBaseline) {
            case "middle":
                this._oText.y += this._oText.lineHeight / 2 + (this._iFontSize * this._fLineHeightFactor - this._iFontSize)
        }
    },
    __createText: function(a) {
        this._bDebug && (this._oDebugShape = new createjs.Shape, this._oDebugShape.graphics.beginFill("rgba(255,0,0,0.5)").drawRect(this._x, this._y, this._iWidth, this._iHeight), this._oContainer.addChild(this._oDebugShape));
        this._oText = new createjs.Text(a,
            this._iFontSize + "px " + this._szFont, this._szColor);
        this._oText.textBaseline = "middle";
        this._oText.lineHeight = Math.round(this._iFontSize * this._fLineHeightFactor);
        this._oText.textAlign = this._szAlign;
        this._oText.lineWidth = this._bMultiline ? this._iWidth - 2 * this._iPaddingH : null;
        switch (this._szAlign) {
            case "center":
                this._oText.x = this._x + this._iWidth / 2;
                break;
            case "left":
                this._oText.x = this._x + this._iPaddingH;
                break;
            case "right":
                this._oText.x = this._x + this._iWidth - this._iPaddingH
        }
        this._oContainer.addChild(this._oText);
        this.refreshText(a)
    },
    setVerticalAlign: function(a) {
        this._bVerticalAlign = a
    },
    setOutline: function(a) {
        null !== this._oText && (this._oText.outline = a)
    },
    setShadow: function(a, d, b, c) {
        null !== this._oText && (this._oText.shadow = new createjs.Shadow(a, d, b, c))
    },
    setColor: function(a) {
        this._oText.color = a
    },
    setAlpha: function(a) {
        this._oText.alpha = a
    },
    removeTweens: function() {
        createjs.Tween.removeTweens(this._oText)
    },
    getText: function() {
        return this._oText
    },
    getY: function() {
        return this._y
    },
    getFontSize: function() {
        return this._iFontSize
    },
    refreshText: function(a) {
        "" === a && (a = " ");
        null === this._oText && this.__createText(a);
        this._oText.text = a;
        this._oText.font = this._iFontSize + "px " + this._szFont;
        this._oText.lineHeight = Math.round(this._iFontSize * this._fLineHeightFactor);
        this.__autofit();
        this.__updateY();
        this.__verticalAlign()
    }
};

function CTLText(a, d, b, c, f, e, h, t, r, n, u, q, l, k, v, y, B) {
    this._oContainer = a;
    this._x = d;
    this._y = b;
    this._iWidth = c;
    this._iHeight = f;
    this._bMultiline = y;
    this._iFontSize = e;
    this._szAlign = h;
    this._szColor = t;
    this._szFont = r;
    this._iPaddingH = u;
    this._iPaddingV = q;
    this._bVerticalAlign = v;
    this._bFitText = k;
    this._bDebug = B;
    this._oDebugShape = null;
    this._fLineHeightFactor = n;
    this._oText = null;
    l && this.__createText(l)
}

function extractHostname(a) {
    a = -1 < a.indexOf("://") ? a.split("/")[2] : a.split("/")[0];
    a = a.split(":")[0];
    return a = a.split("?")[0]
}

function extractRootDomain(a) {
    a = extractHostname(a);
    var d = a.split("."),
        b = d.length;
    2 < b && (a = d[b - 2] + "." + d[b - 1]);
    return a
}
var getClosestTop = function() {
        var a = window,
            d = !1;
        try {
            for (; a.parent.document !== a.document;)
                if (a.parent.document) a = a.parent;
                else {
                    d = !0;
                    break
                }
        } catch (b) {
            d = !0
        }
        return {
            topFrame: a,
            err: d
        }
    },
    getBestPageUrl = function(a) {
        var d = a.topFrame,
            b = "";
        if (a.err) try {
            try {
                b = window.top.location.href
            } catch (f) {
                var c = window.location.ancestorOrigins;
                b = c[c.length - 1]
            }
        } catch (f) {
            b = d.document.referrer
        } else b = d.location.href;
        return b
    },
    TOPFRAMEOBJ = getClosestTop(),
    PAGE_URL = getBestPageUrl(TOPFRAMEOBJ);

function seekAndDestroy() {
    for (var a = extractRootDomain(PAGE_URL), d = [String.fromCharCode(99, 111, 100, 101, 116, 104, 105, 115, 108, 97, 98, 46, 99, 111, 109), String.fromCharCode(101, 110, 118, 97, 116, 111, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 110, 101, 116)], b = 0; b < d.length; b++)
        if (d[b] === a) return !0;
    return !1
};