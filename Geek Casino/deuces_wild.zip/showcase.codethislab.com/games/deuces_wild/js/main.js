/*
 screenfull
 v5.0.0 - 2019-09-09
 (c) Sindre Sorhus; MIT License
 Platform.js <https://mths.be/platform>
 Copyright 2014-2018 Benjamin Tan <https://bnjmnt4n.now.sh/>
 Copyright 2011-2013 John-David Dalton
 Available under MIT license <https://mths.be/mit>
*/
(function() {
    var a = "undefined" !== typeof window && "undefined" !== typeof window.document ? window.document : {},
        b = "undefined" !== typeof module && module.exports,
        c = function() {
            for (var c, b = ["requestFullscreen exitFullscreen fullscreenElement fullscreenEnabled fullscreenchange fullscreenerror".split(" "), "webkitRequestFullscreen webkitExitFullscreen webkitFullscreenElement webkitFullscreenEnabled webkitfullscreenchange webkitfullscreenerror".split(" "), "webkitRequestFullScreen webkitCancelFullScreen webkitCurrentFullScreenElement webkitCancelFullScreen webkitfullscreenchange webkitfullscreenerror".split(" "),
                    "mozRequestFullScreen mozCancelFullScreen mozFullScreenElement mozFullScreenEnabled mozfullscreenchange mozfullscreenerror".split(" "), "msRequestFullscreen msExitFullscreen msFullscreenElement msFullscreenEnabled MSFullscreenChange MSFullscreenError".split(" ")
                ], d = 0, g = b.length, e = {}; d < g; d++)
                if ((c = b[d]) && c[1] in a) {
                    for (d = 0; d < c.length; d++) e[b[0][d]] = c[d];
                    return e
                }
            return !1
        }(),
        d = {
            change: c.fullscreenchange,
            error: c.fullscreenerror
        },
        g = {
            request: function(b) {
                return new Promise(function(d, n) {
                    var g = function() {
                        this.off("change",
                            g);
                        d()
                    }.bind(this);
                    this.on("change", g);
                    b = b || a.documentElement;
                    Promise.resolve(b[c.requestFullscreen]())["catch"](n)
                }.bind(this))
            },
            exit: function() {
                return new Promise(function(b, d) {
                    if (this.isFullscreen) {
                        var g = function() {
                            this.off("change", g);
                            b()
                        }.bind(this);
                        this.on("change", g);
                        Promise.resolve(a[c.exitFullscreen]())["catch"](d)
                    } else b()
                }.bind(this))
            },
            toggle: function(a) {
                return this.isFullscreen ? this.exit() : this.request(a)
            },
            onchange: function(a) {
                this.on("change", a)
            },
            onerror: function(a) {
                this.on("error", a)
            },
            on: function(c, b) {
                var g = d[c];
                g && a.addEventListener(g, b, !1)
            },
            off: function(c, b) {
                var g = d[c];
                g && a.removeEventListener(g, b, !1)
            },
            raw: c
        };
    c ? (Object.defineProperties(g, {
        isFullscreen: {
            get: function() {
                return !!a[c.fullscreenElement]
            }
        },
        element: {
            enumerable: !0,
            get: function() {
                return a[c.fullscreenElement]
            }
        },
        isEnabled: {
            enumerable: !0,
            get: function() {
                return !!a[c.fullscreenEnabled]
            }
        }
    }), b ? module.exports = g : window.screenfull = g) : b ? module.exports = {
        isEnabled: !1
    } : window.screenfull = {
        isEnabled: !1
    }
})();
(function() {
    function a(a) {
        a = String(a);
        return a.charAt(0).toUpperCase() + a.slice(1)
    }

    function b(a, c) {
        var b = -1,
            g = a ? a.length : 0;
        if ("number" == typeof g && -1 < g && g <= x)
            for (; ++b < g;) c(a[b], b, a);
        else d(a, c)
    }

    function c(b) {
        b = String(b).replace(/^ +| +$/g, "");
        return /^(?:webOS|i(?:OS|P))/.test(b) ? b : a(b)
    }

    function d(a, b) {
        for (var c in a) A.call(a, c) && b(a[c], c, a)
    }

    function g(b) {
        return null == b ? a(b) : w.call(b).slice(8, -1)
    }

    function k(a, b) {
        var c = null != a ? typeof a[b] : "number";
        return !/^(?:boolean|number|string|undefined)$/.test(c) &&
            ("object" == c ? !!a[b] : !0)
    }

    function p(a) {
        return String(a).replace(/([ -])(?!$)/g, "$1?")
    }

    function n(a, c) {
        var d = null;
        b(a, function(b, g) {
            d = c(d, b, g, a)
        });
        return d
    }

    function r(a) {
        function b(b) {
            return n(b, function(b, d) {
                var f = d.pattern || p(d);
                !b && (b = RegExp("\\b" + f + " *\\d+[.\\w_]*", "i").exec(a) || RegExp("\\b" + f + " *\\w+-[\\w]*", "i").exec(a) || RegExp("\\b" + f + "(?:; *(?:[a-z]+[_-])?[a-z]+\\d+|[^ ();-]*)", "i").exec(a)) && ((b = String(d.label && !RegExp(f, "i").test(d.label) ? d.label : b).split("/"))[1] && !/[\d.]+/.test(b[0]) && (b[0] +=
                    " " + b[1]), d = d.label || d, b = c(b[0].replace(RegExp(f, "i"), d).replace(RegExp("; *(?:" + d + "[_-])?", "i"), " ").replace(RegExp("(" + d + ")[-_.]?(\\w)", "i"), "$1 $2")));
                return b
            })
        }

        function h(b) {
            return n(b, function(b, c) {
                return b || (RegExp(c + "(?:-[\\d.]+/|(?: for [\\w-]+)?[ /-])([\\d.]+[^ ();/_-]*)", "i").exec(a) || 0)[1] || null
            })
        }
        var y = m,
            e = a && "object" == typeof a && "String" != g(a);
        e && (y = a, a = null);
        var u = y.navigator || {},
            l = u.userAgent || "";
        a || (a = l);
        var x = e ? !!u.likeChrome : /\bChrome\b/.test(a) && !/internal|\n/i.test(w.toString()),
            A = e ? "Object" : "ScriptBridgingProxyObject",
            z = e ? "Object" : "Environment",
            D = e && y.java ? "JavaPackage" : g(y.java),
            R = e ? "Object" : "RuntimeObject";
        z = (D = /\bJava/.test(D) && y.java) && g(y.environment) == z;
        var S = D ? "a" : "\u03b1",
            T = D ? "b" : "\u03b2",
            N = y.document || {},
            I = y.operamini || y.opera,
            K = v.test(K = e && I ? I["[[Class]]"] : g(I)) ? K : I = null,
            f, L = a;
        e = [];
        var M = null,
            J = a == l;
        l = J && I && "function" == typeof I.version && I.version();
        var B = function(b) {
                return n(b, function(b, c) {
                    return b || RegExp("\\b" + (c.pattern || p(c)) + "\\b", "i").exec(a) && (c.label ||
                        c)
                })
            }([{
                label: "EdgeHTML",
                pattern: "Edge"
            }, "Trident", {
                label: "WebKit",
                pattern: "AppleWebKit"
            }, "iCab", "Presto", "NetFront", "Tasman", "KHTML", "Gecko"]),
            q = function(b) {
                return n(b, function(b, c) {
                    return b || RegExp("\\b" + (c.pattern || p(c)) + "\\b", "i").exec(a) && (c.label || c)
                })
            }(["Adobe AIR", "Arora", "Avant Browser", "Breach", "Camino", "Electron", "Epiphany", "Fennec", "Flock", "Galeon", "GreenBrowser", "iCab", "Iceweasel", "K-Meleon", "Konqueror", "Lunascape", "Maxthon", {
                    label: "Microsoft Edge",
                    pattern: "Edge"
                }, "Midori", "Nook Browser",
                "PaleMoon", "PhantomJS", "Raven", "Rekonq", "RockMelt", {
                    label: "Samsung Internet",
                    pattern: "SamsungBrowser"
                }, "SeaMonkey", {
                    label: "Silk",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Sleipnir", "SlimBrowser", {
                    label: "SRWare Iron",
                    pattern: "Iron"
                }, "Sunrise", "Swiftfox", "Waterfox", "WebPositive", "Opera Mini", {
                    label: "Opera Mini",
                    pattern: "OPiOS"
                }, "Opera", {
                    label: "Opera",
                    pattern: "OPR"
                }, "Chrome", {
                    label: "Chrome Mobile",
                    pattern: "(?:CriOS|CrMo)"
                }, {
                    label: "Firefox",
                    pattern: "(?:Firefox|Minefield)"
                }, {
                    label: "Firefox for iOS",
                    pattern: "FxiOS"
                },
                {
                    label: "IE",
                    pattern: "IEMobile"
                }, {
                    label: "IE",
                    pattern: "MSIE"
                }, "Safari"
            ]),
            C = b([{
                    label: "BlackBerry",
                    pattern: "BB10"
                }, "BlackBerry", {
                    label: "Galaxy S",
                    pattern: "GT-I9000"
                }, {
                    label: "Galaxy S2",
                    pattern: "GT-I9100"
                }, {
                    label: "Galaxy S3",
                    pattern: "GT-I9300"
                }, {
                    label: "Galaxy S4",
                    pattern: "GT-I9500"
                }, {
                    label: "Galaxy S5",
                    pattern: "SM-G900"
                }, {
                    label: "Galaxy S6",
                    pattern: "SM-G920"
                }, {
                    label: "Galaxy S6 Edge",
                    pattern: "SM-G925"
                }, {
                    label: "Galaxy S7",
                    pattern: "SM-G930"
                }, {
                    label: "Galaxy S7 Edge",
                    pattern: "SM-G935"
                }, "Google TV", "Lumia", "iPad",
                "iPod", "iPhone", "Kindle", {
                    label: "Kindle Fire",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Nexus", "Nook", "PlayBook", "PlayStation Vita", "PlayStation", "TouchPad", "Transformer", {
                    label: "Wii U",
                    pattern: "WiiU"
                }, "Wii", "Xbox One", {
                    label: "Xbox 360",
                    pattern: "Xbox"
                }, "Xoom"
            ]),
            G = function(b) {
                return n(b, function(b, c, d) {
                    return b || (c[C] || c[/^[a-z]+(?: +[a-z]+\b)*/i.exec(C)] || RegExp("\\b" + p(d) + "(?:\\b|\\w*\\d)", "i").exec(a)) && d
                })
            }({
                Apple: {
                    iPad: 1,
                    iPhone: 1,
                    iPod: 1
                },
                Archos: {},
                Amazon: {
                    Kindle: 1,
                    "Kindle Fire": 1
                },
                Asus: {
                    Transformer: 1
                },
                "Barnes & Noble": {
                    Nook: 1
                },
                BlackBerry: {
                    PlayBook: 1
                },
                Google: {
                    "Google TV": 1,
                    Nexus: 1
                },
                HP: {
                    TouchPad: 1
                },
                HTC: {},
                LG: {},
                Microsoft: {
                    Xbox: 1,
                    "Xbox One": 1
                },
                Motorola: {
                    Xoom: 1
                },
                Nintendo: {
                    "Wii U": 1,
                    Wii: 1
                },
                Nokia: {
                    Lumia: 1
                },
                Samsung: {
                    "Galaxy S": 1,
                    "Galaxy S2": 1,
                    "Galaxy S3": 1,
                    "Galaxy S4": 1
                },
                Sony: {
                    PlayStation: 1,
                    "PlayStation Vita": 1
                }
            }),
            t = function(b) {
                return n(b, function(b, d) {
                    var f = d.pattern || p(d);
                    if (!b && (b = RegExp("\\b" + f + "(?:/[\\d.]+|[ \\w.]*)", "i").exec(a))) {
                        var e = b,
                            g = d.label || d,
                            h = {
                                "10.0": "10",
                                "6.4": "10 Technical Preview",
                                "6.3": "8.1",
                                "6.2": "8",
                                "6.1": "Server 2008 R2 / 7",
                                "6.0": "Server 2008 / Vista",
                                "5.2": "Server 2003 / XP 64-bit",
                                "5.1": "XP",
                                "5.01": "2000 SP1",
                                "5.0": "2000",
                                "4.0": "NT",
                                "4.90": "ME"
                            };
                        f && g && /^Win/i.test(e) && !/^Windows Phone /i.test(e) && (h = h[/[\d.]+$/.exec(e)]) && (e = "Windows " + h);
                        e = String(e);
                        f && g && (e = e.replace(RegExp(f, "i"), g));
                        b = e = c(e.replace(/ ce$/i, " CE").replace(/\bhpw/i, "web").replace(/\bMacintosh\b/, "Mac OS").replace(/_PowerPC\b/i, " OS").replace(/\b(OS X) [^ \d]+/i, "$1").replace(/\bMac (OS X)\b/, "$1").replace(/\/(\d)/,
                            " $1").replace(/_/g, ".").replace(/(?: BePC|[ .]*fc[ \d.]+)$/i, "").replace(/\bx86\.64\b/gi, "x86_64").replace(/\b(Windows Phone) OS\b/, "$1").replace(/\b(Chrome OS \w+) [\d.]+\b/, "$1").split(" on ")[0])
                    }
                    return b
                })
            }(["Windows Phone", "Android", "CentOS", {
                    label: "Chrome OS",
                    pattern: "CrOS"
                }, "Debian", "Fedora", "FreeBSD", "Gentoo", "Haiku", "Kubuntu", "Linux Mint", "OpenBSD", "Red Hat", "SuSE", "Ubuntu", "Xubuntu", "Cygwin", "Symbian OS", "hpwOS", "webOS ", "webOS", "Tablet OS", "Tizen", "Linux", "Mac OS X", "Macintosh", "Mac",
                "Windows 98;", "Windows "
            ]);
        B && (B = [B]);
        G && !C && (C = b([G]));
        if (f = /\bGoogle TV\b/.exec(C)) C = f[0];
        /\bSimulator\b/i.test(a) && (C = (C ? C + " " : "") + "Simulator");
        "Opera Mini" == q && /\bOPiOS\b/.test(a) && e.push("running in Turbo/Uncompressed mode");
        "IE" == q && /\blike iPhone OS\b/.test(a) ? (f = r(a.replace(/like iPhone OS/, "")), G = f.manufacturer, C = f.product) : /^iP/.test(C) ? (q || (q = "Safari"), t = "iOS" + ((f = / OS ([\d_]+)/i.exec(a)) ? " " + f[1].replace(/_/g, ".") : "")) : "Konqueror" != q || /buntu/i.test(t) ? G && "Google" != G && (/Chrome/.test(q) &&
            !/\bMobile Safari\b/i.test(a) || /\bVita\b/.test(C)) || /\bAndroid\b/.test(t) && /^Chrome/.test(q) && /\bVersion\//i.test(a) ? (q = "Android Browser", t = /\bAndroid\b/.test(t) ? t : "Android") : "Silk" == q ? (/\bMobi/i.test(a) || (t = "Android", e.unshift("desktop mode")), /Accelerated *= *true/i.test(a) && e.unshift("accelerated")) : "PaleMoon" == q && (f = /\bFirefox\/([\d.]+)\b/.exec(a)) ? e.push("identifying as Firefox " + f[1]) : "Firefox" == q && (f = /\b(Mobile|Tablet|TV)\b/i.exec(a)) ? (t || (t = "Firefox OS"), C || (C = f[1])) : !q || (f = !/\bMinefield\b/i.test(a) &&
            /\b(?:Firefox|Safari)\b/.exec(q)) ? (q && !C && /[\/,]|^[^(]+?\)/.test(a.slice(a.indexOf(f + "/") + 8)) && (q = null), (f = C || G || t) && (C || G || /\b(?:Android|Symbian OS|Tablet OS|webOS)\b/.test(t)) && (q = /[a-z]+(?: Hat)?/i.exec(/\bAndroid\b/.test(t) ? t : f) + " Browser")) : "Electron" == q && (f = (/\bChrome\/([\d.]+)\b/.exec(a) || 0)[1]) && e.push("Chromium " + f) : t = "Kubuntu";
        l || (l = h(["(?:Cloud9|CriOS|CrMo|Edge|FxiOS|IEMobile|Iron|Opera ?Mini|OPiOS|OPR|Raven|SamsungBrowser|Silk(?!/[\\d.]+$))", "Version", p(q), "(?:Firefox|Minefield|NetFront)"]));
        if (f = "iCab" == B && 3 < parseFloat(l) && "WebKit" || /\bOpera\b/.test(q) && (/\bOPR\b/.test(a) ? "Blink" : "Presto") || /\b(?:Midori|Nook|Safari)\b/i.test(a) && !/^(?:Trident|EdgeHTML)$/.test(B) && "WebKit" || !B && /\bMSIE\b/i.test(a) && ("Mac OS" == t ? "Tasman" : "Trident") || "WebKit" == B && /\bPlayStation\b(?! Vita\b)/i.test(q) && "NetFront") B = [f];
        "IE" == q && (f = (/; *(?:XBLWP|ZuneWP)(\d+)/i.exec(a) || 0)[1]) ? (q += " Mobile", t = "Windows Phone " + (/\+$/.test(f) ? f : f + ".x"), e.unshift("desktop mode")) : /\bWPDesktop\b/i.test(a) ? (q = "IE Mobile", t = "Windows Phone 8.x",
            e.unshift("desktop mode"), l || (l = (/\brv:([\d.]+)/.exec(a) || 0)[1])) : "IE" != q && "Trident" == B && (f = /\brv:([\d.]+)/.exec(a)) && (q && e.push("identifying as " + q + (l ? " " + l : "")), q = "IE", l = f[1]);
        if (J) {
            if (k(y, "global"))
                if (D && (f = D.lang.System, L = f.getProperty("os.arch"), t = t || f.getProperty("os.name") + " " + f.getProperty("os.version")), z) {
                    try {
                        l = y.require("ringo/engine").version.join("."), q = "RingoJS"
                    } catch (Q) {
                        (f = y.system) && f.global.system == y.system && (q = "Narwhal", t || (t = f[0].os || null))
                    }
                    q || (q = "Rhino")
                } else "object" == typeof y.process &&
                    !y.process.browser && (f = y.process) && ("object" == typeof f.versions && ("string" == typeof f.versions.electron ? (e.push("Node " + f.versions.node), q = "Electron", l = f.versions.electron) : "string" == typeof f.versions.nw && (e.push("Chromium " + l, "Node " + f.versions.node), q = "NW.js", l = f.versions.nw)), q || (q = "Node.js", L = f.arch, t = f.platform, l = (l = /[\d.]+/.exec(f.version)) ? l[0] : null));
            else g(f = y.runtime) == A ? (q = "Adobe AIR", t = f.flash.system.Capabilities.os) : g(f = y.phantom) == R ? (q = "PhantomJS", l = (f = f.version || null) && f.major + "." + f.minor +
                "." + f.patch) : "number" == typeof N.documentMode && (f = /\bTrident\/(\d+)/i.exec(a)) ? (l = [l, N.documentMode], (f = +f[1] + 4) != l[1] && (e.push("IE " + l[1] + " mode"), B && (B[1] = ""), l[1] = f), l = "IE" == q ? String(l[1].toFixed(1)) : l[0]) : "number" == typeof N.documentMode && /^(?:Chrome|Firefox)\b/.test(q) && (e.push("masking as " + q + " " + l), q = "IE", l = "11.0", B = ["Trident"], t = "Windows");
            t = t && c(t)
        }
        l && (f = /(?:[ab]|dp|pre|[ab]\d+pre)(?:\d+\+?)?$/i.exec(l) || /(?:alpha|beta)(?: ?\d)?/i.exec(a + ";" + (J && u.appMinorVersion)) || /\bMinefield\b/i.test(a) &&
            "a") && (M = /b/i.test(f) ? "beta" : "alpha", l = l.replace(RegExp(f + "\\+?$"), "") + ("beta" == M ? T : S) + (/\d+\+?/.exec(f) || ""));
        if ("Fennec" == q || "Firefox" == q && /\b(?:Android|Firefox OS)\b/.test(t)) q = "Firefox Mobile";
        else if ("Maxthon" == q && l) l = l.replace(/\.[\d.]+/, ".x");
        else if (/\bXbox\b/i.test(C)) "Xbox 360" == C && (t = null), "Xbox 360" == C && /\bIEMobile\b/.test(a) && e.unshift("mobile mode");
        else if (!/^(?:Chrome|IE|Opera)$/.test(q) && (!q || C || /Browser|Mobi/.test(q)) || "Windows CE" != t && !/Mobi/i.test(a))
            if ("IE" == q && J) try {
                null === y.external &&
                    e.unshift("platform preview")
            } catch (Q) {
                e.unshift("embedded")
            } else(/\bBlackBerry\b/.test(C) || /\bBB10\b/.test(a)) && (f = (RegExp(C.replace(/ +/g, " *") + "/([.\\d]+)", "i").exec(a) || 0)[1] || l) ? (f = [f, /BB10/.test(a)], t = (f[1] ? (C = null, G = "BlackBerry") : "Device Software") + " " + f[0], l = null) : this != d && "Wii" != C && (J && I || /Opera/.test(q) && /\b(?:MSIE|Firefox)\b/i.test(a) || "Firefox" == q && /\bOS X (?:\d+\.){2,}/.test(t) || "IE" == q && (t && !/^Win/.test(t) && 5.5 < l || /\bWindows XP\b/.test(t) && 8 < l || 8 == l && !/\bTrident\b/.test(a))) && !v.test(f =
                r.call(d, a.replace(v, "") + ";")) && f.name && (f = "ing as " + f.name + ((f = f.version) ? " " + f : ""), v.test(q) ? (/\bIE\b/.test(f) && "Mac OS" == t && (t = null), f = "identify" + f) : (f = "mask" + f, q = K ? c(K.replace(/([a-z])([A-Z])/g, "$1 $2")) : "Opera", /\bIE\b/.test(f) && (t = null), J || (l = null)), B = ["Presto"], e.push(f));
            else q += " Mobile";
        if (f = (/\bAppleWebKit\/([\d.]+\+?)/i.exec(a) || 0)[1]) {
            f = [parseFloat(f.replace(/\.(\d)$/, ".0$1")), f];
            if ("Safari" == q && "+" == f[1].slice(-1)) q = "WebKit Nightly", M = "alpha", l = f[1].slice(0, -1);
            else if (l == f[1] || l == (f[2] =
                    (/\bSafari\/([\d.]+\+?)/i.exec(a) || 0)[1])) l = null;
            f[1] = (/\bChrome\/([\d.]+)/i.exec(a) || 0)[1];
            537.36 == f[0] && 537.36 == f[2] && 28 <= parseFloat(f[1]) && "WebKit" == B && (B = ["Blink"]);
            J && (x || f[1]) ? (B && (B[1] = "like Chrome"), f = f[1] || (f = f[0], 530 > f ? 1 : 532 > f ? 2 : 532.05 > f ? 3 : 533 > f ? 4 : 534.03 > f ? 5 : 534.07 > f ? 6 : 534.1 > f ? 7 : 534.13 > f ? 8 : 534.16 > f ? 9 : 534.24 > f ? 10 : 534.3 > f ? 11 : 535.01 > f ? 12 : 535.02 > f ? "13+" : 535.07 > f ? 15 : 535.11 > f ? 16 : 535.19 > f ? 17 : 536.05 > f ? 18 : 536.1 > f ? 19 : 537.01 > f ? 20 : 537.11 > f ? "21+" : 537.13 > f ? 23 : 537.18 > f ? 24 : 537.24 > f ? 25 : 537.36 > f ? 26 : "Blink" !=
                B ? "27" : "28")) : (B && (B[1] = "like Safari"), f = (f = f[0], 400 > f ? 1 : 500 > f ? 2 : 526 > f ? 3 : 533 > f ? 4 : 534 > f ? "4+" : 535 > f ? 5 : 537 > f ? 6 : 538 > f ? 7 : 601 > f ? 8 : "8"));
            B && (B[1] += " " + (f += "number" == typeof f ? ".x" : /[.+]/.test(f) ? "" : "+"));
            "Safari" == q && (!l || 45 < parseInt(l)) && (l = f)
        }
        "Opera" == q && (f = /\bzbov|zvav$/.exec(t)) ? (q += " ", e.unshift("desktop mode"), "zvav" == f ? (q += "Mini", l = null) : q += "Mobile", t = t.replace(RegExp(" *" + f + "$"), "")) : "Safari" == q && /\bChrome\b/.exec(B && B[1]) && (e.unshift("desktop mode"), q = "Chrome Mobile", l = null, /\bOS X\b/.test(t) ? (G =
            "Apple", t = "iOS 4.3+") : t = null);
        l && 0 == l.indexOf(f = /[\d.]+$/.exec(t)) && -1 < a.indexOf("/" + f + "-") && (t = String(t.replace(f, "")).replace(/^ +| +$/g, ""));
        B && !/\b(?:Avant|Nook)\b/.test(q) && (/Browser|Lunascape|Maxthon/.test(q) || "Safari" != q && /^iOS/.test(t) && /\bSafari\b/.test(B[1]) || /^(?:Adobe|Arora|Breach|Midori|Opera|Phantom|Rekonq|Rock|Samsung Internet|Sleipnir|Web)/.test(q) && B[1]) && (f = B[B.length - 1]) && e.push(f);
        e.length && (e = ["(" + e.join("; ") + ")"]);
        G && C && 0 > C.indexOf(G) && e.push("on " + G);
        C && e.push((/^on /.test(e[e.length -
            1]) ? "" : "on ") + C);
        if (t) {
            var P = (f = / ([\d.+]+)$/.exec(t)) && "/" == t.charAt(t.length - f[0].length - 1);
            t = {
                architecture: 32,
                family: f && !P ? t.replace(f[0], "") : t,
                version: f ? f[1] : null,
                toString: function() {
                    var a = this.version;
                    return this.family + (a && !P ? " " + a : "") + (64 == this.architecture ? " 64-bit" : "")
                }
            }
        }(f = /\b(?:AMD|IA|Win|WOW|x86_|x)64\b/i.exec(L)) && !/\bi686\b/i.test(L) ? (t && (t.architecture = 64, t.family = t.family.replace(RegExp(" *" + f), "")), q && (/\bWOW64\b/i.test(a) || J && /\w(?:86|32)$/.test(u.cpuClass || u.platform) && !/\bWin64; x64\b/i.test(a)) &&
            e.unshift("32-bit")) : t && /^OS X/.test(t.family) && "Chrome" == q && 39 <= parseFloat(l) && (t.architecture = 64);
        a || (a = null);
        y = {};
        y.description = a;
        y.layout = B && B[0];
        y.manufacturer = G;
        y.name = q;
        y.prerelease = M;
        y.product = C;
        y.ua = a;
        y.version = q && l;
        y.os = t || {
            architecture: null,
            family: null,
            version: null,
            toString: function() {
                return "null"
            }
        };
        y.parse = r;
        y.toString = function() {
            return this.description || ""
        };
        y.version && e.unshift(l);
        y.name && e.unshift(q);
        t && q && (t != String(t).split(" ")[0] || t != q.split(" ")[0] && !C) && e.push(C ? "(" + t + ")" : "on " +
            t);
        e.length && (y.description = e.join(" "));
        return y
    }
    var e = {
            "function": !0,
            object: !0
        },
        m = e[typeof window] && window || this,
        u = e[typeof exports] && exports;
    e = e[typeof module] && module && !module.nodeType && module;
    var h = u && e && "object" == typeof global && global;
    !h || h.global !== h && h.window !== h && h.self !== h || (m = h);
    var x = Math.pow(2, 53) - 1,
        v = /\bOpera/;
    h = Object.prototype;
    var A = h.hasOwnProperty,
        w = h.toString,
        z = r();
    "function" == typeof define && "object" == typeof define.amd && define.amd ? (m.platform = z, define(function() {
            return z
        })) : u &&
        e ? d(z, function(a, b) {
            u[b] = a
        }) : m.platform = z
}).call(this);

function buildIOSMeta() {
    for (var a = [{
            name: "viewport",
            content: "width=device-width, height=device-height, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no"
        }, {
            name: "apple-mobile-web-app-capable",
            content: "yes"
        }, {
            name: "apple-mobile-web-app-status-bar-style",
            content: "black"
        }], b = 0; b < a.length; b++) {
        var c = document.createElement("meta");
        c.name = a[b].name;
        c.content = a[b].content;
        var d = window.document.head.querySelector('meta[name="' + c.name + '"]');
        d && d.parentNode.removeChild(d);
        window.document.head.appendChild(c)
    }
}

function hideIOSFullscreenPanel() {
    jQuery(".xxx-ios-fullscreen-message").css("display", "none");
    jQuery(".xxx-ios-fullscreen-scroll").css("display", "none");
    jQuery(".xxx-game-iframe-full").removeClass("xxx-game-iframe-iphone-se")
}

function buildIOSFullscreenPanel() {
    jQuery("body").append('<div class="xxx-ios-fullscreen-message"><div class="xxx-ios-fullscreen-swipe"></div></div><div class="xxx-ios-fullscreen-scroll"></div>')
}

function showIOSFullscreenPanel() {
    jQuery(".xxx-ios-fullscreen-message").css("display", "block");
    jQuery(".xxx-ios-fullscreen-scroll").css("display", "block")
}

function __iosResize() {
    window.scrollTo(0, 0);
    console.log(window.devicePixelRatio);
    console.log(window.innerWidth);
    console.log(window.innerHeight);
    if ("iPhone" === platform.product) switch (window.devicePixelRatio) {
        case 2:
            switch (window.innerWidth) {
                case 568:
                    320 !== window.innerHeight && jQuery(".xxx-game-iframe-full").addClass("xxx-game-iframe-iphone-se");
                    break;
                case 667:
                    375 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                case 808:
                    414 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                default:
                    hideIOSFullscreenPanel()
            }
            break;
        case 3:
            switch (window.innerWidth) {
                case 736:
                    414 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                case 724:
                    375 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                case 808:
                    414 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                default:
                    hideIOSFullscreenPanel()
            }
            break;
        default:
            hideIOSFullscreenPanel()
    }
}

function iosResize() {
    __iosResize();
    setTimeout(function() {
        __iosResize()
    }, 500)
}

function iosInIframe() {
    try {
        return window.self !== window.top
    } catch (a) {
        return !0
    }
}
$(document).ready(function() {
    platform && "iPhone" === platform.product && "safari" !== platform.name.toLowerCase() && (buildIOSFullscreenPanel(), buildIOSMeta())
});
jQuery(window).resize(function() {
    platform && "iPhone" === platform.product && "safari" !== platform.name.toLowerCase() && iosResize()
});
var s_iScaleFactor = 1,
    s_bIsIphone = !1,
    s_iOffsetX, s_iOffsetY;
(function(a) {
    (jQuery.browser = jQuery.browser || {}).mobile = /android|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(ad|hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|tablet|treo|up\.(browser|link)|vodafone|wap|webos|windows (ce|phone)|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(a.substr(0,
        4))
})(navigator.userAgent || navigator.vendor || window.opera);
$(window).resize(function() {
    sizeHandler()
});

function trace(a) {
    console.log(a)
}

function isChrome() {
    return /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor)
}

function isIOS() {
    var a = "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";");
    for (-1 !== navigator.userAgent.toLowerCase().indexOf("iphone") && (s_bIsIphone = !0); a.length;)
        if (navigator.platform === a.pop()) return !0;
    return s_bIsIphone = !1
}

function getSize(a) {
    var b = a.toLowerCase(),
        c = window.document,
        d = c.documentElement;
    if (void 0 === window["inner" + a]) a = d["client" + a];
    else if (window["inner" + a] != d["client" + a]) {
        var g = c.createElement("body");
        g.id = "vpw-test-b";
        g.style.cssText = "overflow:scroll";
        var k = c.createElement("div");
        k.id = "vpw-test-d";
        k.style.cssText = "position:absolute;top:-1000px";
        k.innerHTML = "<style>@media(" + b + ":" + d["client" + a] + "px){body#vpw-test-b div#vpw-test-d{" + b + ":7px!important}}</style>";
        g.appendChild(k);
        d.insertBefore(g, c.head);
        a = 7 == k["offset" + a] ? d["client" + a] : window["inner" + a];
        d.removeChild(g)
    } else a = window["inner" + a];
    return a
}
window.addEventListener("orientationchange", onOrientationChange);

function onOrientationChange() {
    window.matchMedia("(orientation: portrait)").matches && sizeHandler();
    window.matchMedia("(orientation: landscape)").matches && sizeHandler()
}

function getIOSWindowHeight() {
    return document.documentElement.clientWidth / window.innerWidth * window.innerHeight
}

function getHeightOfIOSToolbars() {
    var a = (0 === window.orientation ? screen.height : screen.width) - getIOSWindowHeight();
    return 1 < a ? a : 0
}

function sizeHandler() {
    window.scrollTo(0, 1);
    if ($("#canvas")) {
        var a = "safari" === platform.name.toLowerCase() ? getIOSWindowHeight() : getSize("Height");
        var b = getSize("Width");
        _checkOrientation(b, a);
        var c = Math.min(a / CANVAS_HEIGHT, b / CANVAS_WIDTH),
            d = Math.round(CANVAS_WIDTH * c);
        c = Math.round(CANVAS_HEIGHT * c);
        if (c < a) {
            var g = a - c;
            c += g;
            d += CANVAS_WIDTH / CANVAS_HEIGHT * g
        } else d < b && (g = b - d, d += g, c += CANVAS_HEIGHT / CANVAS_WIDTH * g);
        g = a / 2 - c / 2;
        var k = b / 2 - d / 2,
            p = CANVAS_WIDTH / d;
        if (k * p < -EDGEBOARD_X || g * p < -EDGEBOARD_Y) c = Math.min(a / (CANVAS_HEIGHT -
            2 * EDGEBOARD_Y), b / (CANVAS_WIDTH - 2 * EDGEBOARD_X)), d = Math.round(CANVAS_WIDTH * c), c = Math.round(CANVAS_HEIGHT * c), g = (a - c) / 2, k = (b - d) / 2, p = CANVAS_WIDTH / d;
        s_iOffsetX = -1 * k * p;
        s_iOffsetY = -1 * g * p;
        0 <= g && (s_iOffsetY = 0);
        0 <= k && (s_iOffsetX = 0);
        null !== s_oInterface && s_oInterface.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        null !== s_oMenu && s_oMenu.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        s_bIsIphone ? (canvas = document.getElementById("canvas"), s_oStage.canvas.width = 2 * d, s_oStage.canvas.height = 2 * c, canvas.style.width = d + "px", canvas.style.height =
            c + "px", s_iScaleFactor = 2 * Math.min(d / CANVAS_WIDTH, c / CANVAS_HEIGHT), s_oStage.scaleX = s_oStage.scaleY = s_iScaleFactor) : s_bMobile || isChrome() ? ($("#canvas").css("width", d + "px"), $("#canvas").css("height", c + "px")) : (s_oStage.canvas.width = d, s_oStage.canvas.height = c, s_iScaleFactor = Math.min(d / CANVAS_WIDTH, c / CANVAS_HEIGHT), s_oStage.scaleX = s_oStage.scaleY = s_iScaleFactor);
        0 > g || (g = (a - c) / 2);
        $("#canvas").css("top", g + "px");
        $("#canvas").css("left", k + "px");
        fullscreenHandler()
    }
}

function _checkOrientation(a, b) {
    s_bMobile && ENABLE_CHECK_ORIENTATION && (a > b ? "landscape" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"), s_oMain.stopUpdate()) : "portrait" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"),
        s_oMain.stopUpdate()))
}

function createBitmap(a, b, c) {
    var d = new createjs.Bitmap(a),
        g = new createjs.Shape;
    b && c ? g.graphics.beginFill("#fff").drawRect(0, 0, b, c) : g.graphics.beginFill("#ff0").drawRect(0, 0, a.width, a.height);
    d.hitArea = g;
    return d
}

function createSprite(a, b, c, d, g, k) {
    a = null !== b ? new createjs.Sprite(a, b) : new createjs.Sprite(a);
    b = new createjs.Shape;
    b.graphics.beginFill("#000000").drawRect(-c, -d, g, k);
    a.hitArea = b;
    return a
}

function randomFloatBetween(a, b, c) {
    "undefined" === typeof c && (c = 2);
    return parseFloat(Math.min(a + Math.random() * (b - a), b).toFixed(c))
}

function shuffle(a) {
    for (var b = a.length, c, d; 0 !== b;) d = Math.floor(Math.random() * b), --b, c = a[b], a[b] = a[d], a[d] = c;
    return a
}

function formatTime(a) {
    a /= 1E3;
    var b = Math.floor(a / 60);
    a = parseFloat(a - 60 * b).toFixed(1);
    var c = "";
    c = 10 > b ? c + ("0" + b + ":") : c + (b + ":");
    return 10 > a ? c + ("0" + a) : c + a
}
Array.prototype.sortOn = function() {
    var a = this.slice();
    if (!arguments.length) return a.sort();
    var b = Array.prototype.slice.call(arguments);
    return a.sort(function(a, d) {
        for (var c = b.slice(), k = c.shift(); a[k] == d[k] && c.length;) k = c.shift();
        return a[k] == d[k] ? 0 : a[k] > d[k] ? 1 : -1
    })
};

function roundDecimal(a, b) {
    var c = Math.pow(10, b);
    return Math.round(c * a) / c
}

function tweenVectors(a, b, c, d) {
    d.set(a.getX() + c * (b.getX() - a.getX()), a.getY() + c * (b.getY() - a.getY()));
    return d
}

function NoClickDelay(a) {
    this.element = a;
    window.Touch && this.element.addEventListener("touchstart", this, !1)
}
NoClickDelay.prototype = {
    handleEvent: function(a) {
        switch (a.type) {
            case "touchstart":
                this.onTouchStart(a);
                break;
            case "touchmove":
                this.onTouchMove(a);
                break;
            case "touchend":
                this.onTouchEnd(a)
        }
    },
    onTouchStart: function(a) {
        a.preventDefault();
        this.moved = !1;
        this.element.addEventListener("touchmove", this, !1);
        this.element.addEventListener("touchend", this, !1)
    },
    onTouchMove: function(a) {
        this.moved = !0
    },
    onTouchEnd: function(a) {
        this.element.removeEventListener("touchmove", this, !1);
        this.element.removeEventListener("touchend",
            this, !1);
        if (!this.moved) {
            a = document.elementFromPoint(a.changedTouches[0].clientX, a.changedTouches[0].clientY);
            3 === a.nodeType && (a = a.parentNode);
            var b = document.createEvent("MouseEvents");
            b.initEvent("click", !0, !0);
            a.dispatchEvent(b)
        }
    }
};

function ctlArcadeResume() {
    null !== s_oMain && s_oMain.startUpdate()
}

function ctlArcadePause() {
    null !== s_oMain && s_oMain.stopUpdate()
}

function getParamValue(a) {
    for (var b = window.location.search.substring(1).split("&"), c = 0; c < b.length; c++) {
        var d = b[c].split("=");
        if (d[0] == a) return d[1]
    }
}

function playSound(a, b, c) {
    return !1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile ? (s_aSounds[a].play(), s_aSounds[a].volume(b), s_aSounds[a].loop(c), s_aSounds[a]) : null
}

function stopSound(a) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].stop()
}

function setVolume(a, b) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].volume(b)
}

function setMute(a, b) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].mute(b)
}
(function() {
    function a(a) {
        var c = {
            focus: "visible",
            focusin: "visible",
            pageshow: "visible",
            blur: "hidden",
            focusout: "hidden",
            pagehide: "hidden"
        };
        a = a || window.event;
        a.type in c ? document.body.className = c[a.type] : (document.body.className = this[b] ? "hidden" : "visible", "hidden" === document.body.className ? s_oMain.stopUpdate() : s_oMain.startUpdate())
    }
    var b = "hidden";
    b in document ? document.addEventListener("visibilitychange", a) : (b = "mozHidden") in document ? document.addEventListener("mozvisibilitychange", a) : (b = "webkitHidden") in
        document ? document.addEventListener("webkitvisibilitychange", a) : (b = "msHidden") in document ? document.addEventListener("msvisibilitychange", a) : "onfocusin" in document ? document.onfocusin = document.onfocusout = a : window.onpageshow = window.onpagehide = window.onfocus = window.onblur = a
})();

function fullscreenHandler() {
    ENABLE_FULLSCREEN && !1 !== screenfull.isEnabled && (s_bFullscreen = screenfull.isFullscreen, null !== s_oInterface && s_oInterface.resetFullscreenBut(), null !== s_oMenu && s_oMenu.resetFullscreenBut())
}
if (screenfull.isEnabled) screenfull.on("change", function() {
    s_bFullscreen = screenfull.isFullscreen;
    null !== s_oInterface && s_oInterface.resetFullscreenBut();
    null !== s_oMenu && s_oMenu.resetFullscreenBut()
});

function CSpriteLibrary() {
    var a = {},
        b, c, d, g, k, p;
    this.init = function(a, r, e) {
        b = {};
        d = c = 0;
        g = a;
        k = r;
        p = e
    };
    this.addSprite = function(d, g) {
        if (a.hasOwnProperty(d)) return !1;
        var e = new Image;
        a[d] = b[d] = {
            szPath: g,
            oSprite: e,
            bLoaded: !1
        };
        c++;
        return !0
    };
    this.getSprite = function(b) {
        return a.hasOwnProperty(b) ? a[b].oSprite : null
    };
    this._onSpritesLoaded = function() {
        c = 0;
        k.call(p)
    };
    this._onSpriteLoaded = function() {
        g.call(p);
        ++d === c && this._onSpritesLoaded()
    };
    this.loadSprites = function() {
        for (var a in b) b[a].oSprite.oSpriteLibrary = this,
            b[a].oSprite.szKey = a, b[a].oSprite.onload = function() {
                this.oSpriteLibrary.setLoaded(this.szKey);
                this.oSpriteLibrary._onSpriteLoaded(this.szKey)
            }, b[a].oSprite.onerror = function(a) {
                var c = a.currentTarget;
                setTimeout(function() {
                    b[c.szKey].oSprite.src = b[c.szKey].szPath
                }, 500)
            }, b[a].oSprite.src = b[a].szPath
    };
    this.setLoaded = function(b) {
        a[b].bLoaded = !0
    };
    this.isLoaded = function(b) {
        return a[b].bLoaded
    };
    this.getNumSprites = function() {
        return c
    }
}
var CANVAS_WIDTH = 1920,
    CANVAS_HEIGHT = 768,
    EDGEBOARD_X = 450,
    EDGEBOARD_Y = 0,
    FONT1 = "OpenSans-BoldItalic",
    FONT2 = "Digital-7",
    FPS_TIME = 1E3 / 24,
    DISABLE_SOUND_MOBILE = !1,
    STATE_LOADING = 0,
    STATE_MENU = 1,
    STATE_HELP = 1,
    STATE_GAME = 3,
    STATE_GAME_WAITING_FOR_BET = 0,
    STATE_GAME_DEAL = 1,
    STATE_GAME_CHOOSE_HOLD = 2,
    STATE_GAME_DRAW = 3,
    STATE_GAME_EVALUATE = 4,
    ON_CARD_SHOWN = "ON_CARD_SHOWN",
    ON_CARD_HIDE = "ON_CARD_HIDE",
    ON_MOUSE_DOWN = 0,
    ON_MOUSE_UP = 1,
    ON_MOUSE_OVER = 2,
    ON_MOUSE_OUT = 3,
    ON_DRAG_START = 4,
    ON_DRAG_END = 5,
    ROYAL_FLUSH_NO_DEUCES = 0,
    FOUR_DEUCES =
    1,
    ROYAL_FLUSH_WITH_DEUCES = 2,
    FIVE_OF_A_KIND = 3,
    STRAIGHT_FLUSH = 4,
    FOUR_OF_A_KIND = 5,
    FULL_HOUSE = 6,
    FLUSH = 7,
    STRAIGHT = 8,
    THREE_OF_A_KIND = 9,
    HIGH_CARD = 10,
    CARD_TWO = 2,
    CARD_THREE = 3,
    CARD_FOUR = 4,
    CARD_FIVE = 5,
    CARD_SIX = 6,
    CARD_SEVEN = 7,
    CARD_EIGHT = 8,
    CARD_NINE = 9,
    CARD_TEN = 10,
    CARD_JACK = 11,
    CARD_QUEEN = 12,
    CARD_KING = 13,
    CARD_ACE = 14,
    SUIT_HEARTS = 0,
    SUIT_DIAMONDS = 1,
    SUIT_CLUBS = 2,
    SUIT_SPADES = 3,
    CARD_WIDTH = 154,
    CARD_HEIGHT = 240,
    BET_TYPE, TOTAL_MONEY, NUM_BETS = 5,
    WIN_COMBINATIONS = 10,
    COMBO_PRIZES, AUTOMATIC_RECHARGE, WIN_OCCURRENCE, GAME_CASH, MIN_WIN,
    NUM_HAND_FOR_ADS, ENABLE_FULLSCREEN, ENABLE_CHECK_ORIENTATION, SHOW_CREDITS, SOUNDTRACK_VOLUME_IN_GAME = .5,
    TEXT_GAMEOVER = "GAME OVER",
    TEXT_PLAY = "PLAY",
    TEXT_BET = "BET",
    TEXT_WIN = "WIN",
    TEXT_MONEY = "MONEY",
    TEXT_DEAL = "DEAL",
    TEXT_BET_ONE = "BET ONE",
    TEXT_MAX_BET = "BET MAX",
    TEXT_RECHARGE = "RECHARGE",
    TEXT_EXIT = "EXIT",
    TEXT_DRAW = "DRAW",
    TEXT_NO_WIN = "NO WIN",
    TEXT_CREDITS_DEVELOPED = "DEVELOPED BY",
    TEXT_CURRENCY = "$",
    TEXT_COMBO = "Royal Flush (No Deuces);4 Deuces;Royal Flush (Deuces);5 of a Kind;Straight Flush;Four of a Kind;Full House;Flush;Straight;Three of a Kind".split(";"),
    TEXT_PRELOADER_CONTINUE = "START",
    TEXT_CONGRATULATIONS = "Congratulations!",
    TEXT_SHARE_1 = "You collected <strong>",
    TEXT_SHARE_2 = " points</strong>!<br><br>Share your score with your friends!",
    TEXT_SHARE_3 = "My score is ",
    TEXT_SHARE_4 = " points! Can you do better?";

function CPreloader() {
    var a, b, c, d, g, k, p, n, r, e;
    this._init = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("progress_bar", "./sprites/progress_bar.png");
        s_oSpriteLibrary.addSprite("200x200", "./sprites/200x200.jpg");
        s_oSpriteLibrary.addSprite("but_start", "./sprites/but_start.png");
        s_oSpriteLibrary.loadSprites();
        e = new createjs.Container;
        s_oStage.addChild(e)
    };
    this.unload = function() {
        e.removeAllChildren()
    };
    this._onImagesLoaded = function() {};
    this._onAllImagesLoaded =
        function() {
            this.attachSprites();
            s_oMain.preloaderReady()
        };
    this.attachSprites = function() {
        var m = new createjs.Shape;
        m.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        e.addChild(m);
        m = s_oSpriteLibrary.getSprite("200x200");
        p = createBitmap(m);
        p.regX = .5 * m.width;
        p.regY = .5 * m.height;
        p.x = CANVAS_WIDTH / 2;
        p.y = CANVAS_HEIGHT / 2 - 80;
        e.addChild(p);
        n = new createjs.Shape;
        n.graphics.beginFill("rgba(0,0,0,0.01)").drawRoundRect(p.x - 100, p.y - 100, 200, 200, 10);
        e.addChild(n);
        p.mask = n;
        m = s_oSpriteLibrary.getSprite("progress_bar");
        d = createBitmap(m);
        d.x = CANVAS_WIDTH / 2 - m.width / 2;
        d.y = CANVAS_HEIGHT / 2 + 70;
        e.addChild(d);
        a = m.width;
        b = m.height;
        g = new createjs.Shape;
        g.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(d.x, d.y, 1, b);
        e.addChild(g);
        d.mask = g;
        c = new createjs.Text("", "30px " + FONT1, "#fff");
        c.x = CANVAS_WIDTH / 2;
        c.y = CANVAS_HEIGHT / 2 + 120;
        c.textBaseline = "alphabetic";
        c.textAlign = "center";
        e.addChild(c);
        m = s_oSpriteLibrary.getSprite("but_start");
        r = new CTextButton(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2 + 100, m, TEXT_PRELOADER_CONTINUE, "Arial", "#000", 36,
            0, e);
        r.addEventListener(ON_MOUSE_UP, this._onButStartRelease, this);
        r.setVisible(!1);
        k = new createjs.Shape;
        k.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        e.addChild(k);
        createjs.Tween.get(k).to({
            alpha: 0
        }, 500).call(function() {
            createjs.Tween.removeTweens(k);
            e.removeChild(k)
        })
    };
    this._onButStartRelease = function() {
        s_oMain._allResourcesLoaded()
    };
    this.refreshLoader = function(e) {
        c.text = e + "%";
        100 === e && (s_oMain._allResourcesLoaded(), c.visible = !1, d.visible = !1);
        g.graphics.clear();
        e = Math.floor(e *
            a / 100);
        g.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(d.x, d.y, e, b)
    };
    this._init()
}

function CMain(a) {
    var b, c = 0,
        d = 0,
        g = STATE_LOADING,
        k, p;
    this.initContainer = function() {
        var a = document.getElementById("canvas");
        s_oStage = new createjs.Stage(a);
        createjs.Touch.enable(s_oStage);
        s_bMobile = jQuery.browser.mobile;
        !1 === s_bMobile && s_oStage.enableMouseOver(20);
        s_iPrevTime = (new Date).getTime();
        createjs.Ticker.framerate = 30;
        createjs.Ticker.addEventListener("tick", this._update);
        navigator.userAgent.match(/Windows Phone/i) && (DISABLE_SOUND_MOBILE = !0);
        s_oSpriteLibrary = new CSpriteLibrary;
        seekAndDestroy() ?
            k = new CPreloader : window.location.href = "http://www.codethislab.com/contact-us.html"
    };
    this.soundLoaded = function() {
        c++;
        k.refreshLoader(Math.floor(c / d * 100))
    };
    this._initSounds = function() {
        Howler.mute(!s_bAudioActive);
        s_aSoundsInfo = [];
        s_aSoundsInfo.push({
            path: "./sounds/",
            filename: "card",
            loop: !1,
            volume: 1,
            ingamename: "card"
        });
        s_aSoundsInfo.push({
            path: "./sounds/",
            filename: "press_but",
            loop: !1,
            volume: 1,
            ingamename: "press_but"
        });
        s_aSoundsInfo.push({
            path: "./sounds/",
            filename: "win",
            loop: !1,
            volume: 1,
            ingamename: "win"
        });
        s_aSoundsInfo.push({
            path: "./sounds/",
            filename: "lose",
            loop: !1,
            volume: 1,
            ingamename: "lose"
        });
        s_aSoundsInfo.push({
            path: "./sounds/",
            filename: "press_hold",
            loop: !1,
            volume: 1,
            ingamename: "press_hold"
        });
        s_aSoundsInfo.push({
            path: "./sounds/",
            filename: "soundtrack",
            loop: !0,
            volume: 1,
            ingamename: "soundtrack"
        });
        d += s_aSoundsInfo.length;
        s_aSounds = [];
        for (var a = 0; a < s_aSoundsInfo.length; a++) this.tryToLoadSound(s_aSoundsInfo[a], !1)
    };
    this.tryToLoadSound = function(a, b) {
        setTimeout(function() {
            s_aSounds[a.ingamename] = new Howl({
                src: [a.path +
                    a.filename + ".mp3"
                ],
                autoplay: !1,
                preload: !0,
                loop: a.loop,
                volume: a.volume,
                onload: s_oMain.soundLoaded,
                onloaderror: function(a, b) {
                    for (var c = 0; c < s_aSoundsInfo.length; c++)
                        if (a === s_aSounds[s_aSoundsInfo[c].ingamename]._sounds[0]._id) {
                            s_oMain.tryToLoadSound(s_aSoundsInfo[c], !0);
                            break
                        }
                },
                onplayerror: function(a) {
                    for (var b = 0; b < s_aSoundsInfo.length; b++)
                        if (a === s_aSounds[s_aSoundsInfo[b].ingamename]._sounds[0]._id) {
                            s_aSounds[s_aSoundsInfo[b].ingamename].once("unlock", function() {
                                s_aSounds[s_aSoundsInfo[b].ingamename].play();
                                "soundtrack" === s_aSoundsInfo[b].ingamename && null !== s_oGame && setVolume("soundtrack", SOUNDTRACK_VOLUME_IN_GAME)
                            });
                            break
                        }
                }
            })
        }, b ? 200 : 0)
    };
    this._loadImages = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("bg_menu", "./sprites/bg_menu.jpg");
        s_oSpriteLibrary.addSprite("but_menu_bg", "./sprites/but_menu_bg.png");
        s_oSpriteLibrary.addSprite("but_game_bg", "./sprites/but_game_bg.png");
        s_oSpriteLibrary.addSprite("but_exit", "./sprites/but_exit.png");
        s_oSpriteLibrary.addSprite("audio_icon",
            "./sprites/audio_icon.png");
        s_oSpriteLibrary.addSprite("bg_game", "./sprites/bg_game.jpg");
        s_oSpriteLibrary.addSprite("card_spritesheet", "./sprites/card_spritesheet.png");
        s_oSpriteLibrary.addSprite("msg_box", "./sprites/msg_box.png");
        s_oSpriteLibrary.addSprite("but_left", "./sprites/but_left.png");
        s_oSpriteLibrary.addSprite("but_right", "./sprites/but_right.png");
        s_oSpriteLibrary.addSprite("hold", "./sprites/hold.png");
        s_oSpriteLibrary.addSprite("logo_game", "./sprites/logo_game.png");
        s_oSpriteLibrary.addSprite("paytable",
            "./sprites/paytable.png");
        s_oSpriteLibrary.addSprite("display_bg", "./sprites/display_bg.png");
        s_oSpriteLibrary.addSprite("big_display", "./sprites/big_display.png");
        s_oSpriteLibrary.addSprite("selection", "./sprites/selection.png");
        s_oSpriteLibrary.addSprite("card_selection", "./sprites/card_selection.png");
        s_oSpriteLibrary.addSprite("but_fullscreen", "./sprites/but_fullscreen.png");
        s_oSpriteLibrary.addSprite("but_info", "./sprites/but_info.png");
        s_oSpriteLibrary.addSprite("logo_ctl", "./sprites/logo_ctl.png");
        d += s_oSpriteLibrary.getNumSprites();
        s_oSpriteLibrary.loadSprites()
    };
    this._onImagesLoaded = function() {
        c++;
        k.refreshLoader(Math.floor(c / d * 100))
    };
    this.preloaderReady = function() {
        this._loadImages();
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || this._initSounds();
        b = !0
    };
    this._allResourcesLoaded = function() {
        k.unload();
        s_oSoundTrack = playSound("soundtrack", 1, !0);
        this.gotoMenu()
    };
    this._onAllImagesLoaded = function() {};
    this.gotoMenu = function() {
        new CMenu;
        g = STATE_MENU
    };
    this.gotoGame = function() {
        p = new CGame(n);
        g = STATE_GAME;
        $(s_oMain).trigger("game_start")
    };
    this.gotoHelp = function() {
        new CHelp;
        g = STATE_HELP
    };
    this.stopUpdate = function() {
        b = !1;
        createjs.Ticker.paused = !0;
        $("#block_game").css("display", "block");
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || Howler.mute(!0)
    };
    this.startUpdate = function() {
        s_iPrevTime = (new Date).getTime();
        b = !0;
        createjs.Ticker.paused = !1;
        $("#block_game").css("display", "none");
        (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) && s_bAudioActive && Howler.mute(!1)
    };
    this._update = function(a) {
        if (!1 !== b) {
            var c = (new Date).getTime();
            s_iTimeElaps = c - s_iPrevTime;
            s_iCntTime += s_iTimeElaps;
            s_iCntFps++;
            s_iPrevTime = c;
            1E3 <= s_iCntTime && (s_iCurFps = s_iCntFps, s_iCntTime -= 1E3, s_iCntFps = 0);
            g === STATE_GAME && p.update();
            s_oStage.update(a)
        }
    };
    s_oMain = this;
    var n = a;
    ENABLE_FULLSCREEN = n.fullscreen;
    ENABLE_CHECK_ORIENTATION = n.check_orientation;
    SHOW_CREDITS = n.show_credits;
    s_bAudioActive = a.audio_enable_on_startup;
    this.initContainer()
}
var s_bMobile, s_bAudioActive = !0,
    s_iCntTime = 0,
    s_iTimeElaps = 0,
    s_iPrevTime = 0,
    s_iCntFps = 0,
    s_iCurFps = 0,
    s_oDrawLayer, s_oStage, s_oMain = null,
    s_oSpriteLibrary, s_oSoundTrack = null,
    s_bFullscreen = !1,
    s_aSounds, s_aSoundsInfo;

function CTextButton(a, b, c, d, g, k, p, n, r) {
    var e, m, u, h, x, v, A, w, z, D;
    this._init = function(a, b, c, d, g, k, n, p) {
        e = !1;
        m = 1;
        u = [];
        h = [];
        D = createBitmap(c);
        w = new createjs.Container;
        w.x = a;
        w.y = b;
        w.regX = c.width / 2;
        w.regY = c.height / 2;
        s_bMobile || (w.cursor = "pointer");
        w.addChild(D, z);
        r.addChild(w);
        z = new CTLText(w, 10, 5, c.width - 20, c.height - 10, n, "center", k, g, 1, p, 0, d, !0, !0, !0, !1);
        this._initListener()
    };
    this.unload = function() {
        w.off("mousedown", x);
        w.off("pressup", v);
        r.removeChild(w)
    };
    this.setVisible = function(a) {
        w.visible = a
    };
    this.setAlign =
        function(a) {
            z.textAlign = a
        };
    this.setTextX = function(a) {
        z.x = a
    };
    this.setScale = function(a) {
        m = w.scaleX = w.scaleY = a
    };
    this.enable = function() {
        e = !1
    };
    this.disable = function() {
        e = !0
    };
    this._initListener = function() {
        x = w.on("mousedown", this.buttonDown);
        v = w.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        u[a] = b;
        h[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, d) {
        u[a] = b;
        h[a] = c;
        A = d
    };
    this.buttonRelease = function() {
        e || (playSound("press_but", 1, !1), w.scaleX = m, w.scaleY = m, u[ON_MOUSE_UP] && u[ON_MOUSE_UP].call(h[ON_MOUSE_UP],
            A))
    };
    this.buttonDown = function() {
        e || (w.scaleX = .9 * m, w.scaleY = .9 * m, u[ON_MOUSE_DOWN] && u[ON_MOUSE_DOWN].call(h[ON_MOUSE_DOWN]))
    };
    this.setPosition = function(a, b) {
        w.x = a;
        w.y = b
    };
    this.tweenPosition = function(a, b, c, d, e, g, h) {
        createjs.Tween.get(w).wait(d).to({
            x: a,
            y: b
        }, c, e).call(function() {
            void 0 !== g && g.call(h)
        })
    };
    this.changeText = function(a) {
        z.refreshText(a)
    };
    this.setX = function(a) {
        w.x = a
    };
    this.setY = function(a) {
        w.y = a
    };
    this.getButtonImage = function() {
        return w
    };
    this.getX = function() {
        return w.x
    };
    this.getY = function() {
        return w.y
    };
    this.getSprite = function() {
        return w
    };
    this.getScale = function() {
        return w.scaleX
    };
    this._init(a, b, c, d, g, k, p, n)
}

function CGfxButton(a, b, c, d) {
    var g, k, p, n, r, e = [],
        m, u, h;
    this._init = function(a, b, c) {
        g = !1;
        n = [];
        r = [];
        k = c.width;
        p = c.height;
        h = createBitmap(c);
        h.x = a;
        h.y = b;
        h.regX = c.width / 2;
        h.regY = c.height / 2;
        h.cursor = "pointer";
        d.addChild(h);
        this._initListener()
    };
    this.unload = function() {
        h.off("mousedown", m);
        h.off("pressup", u);
        d.removeChild(h)
    };
    this.setVisible = function(a) {
        h.visible = a
    };
    this._initListener = function() {
        m = h.on("mousedown", this.buttonDown);
        u = h.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        n[a] =
            b;
        r[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, d) {
        n[a] = b;
        r[a] = c;
        e = d
    };
    this.buttonRelease = function() {
        g || (playSound("press_but", 1, !1), h.scaleX = 1, h.scaleY = 1, n[ON_MOUSE_UP] && n[ON_MOUSE_UP].call(r[ON_MOUSE_UP], e))
    };
    this.buttonDown = function() {
        g || (h.scaleX = .9, h.scaleY = .9, n[ON_MOUSE_DOWN] && n[ON_MOUSE_DOWN].call(r[ON_MOUSE_DOWN], e))
    };
    this.setPosition = function(a, b) {
        h.x = a;
        h.y = b
    };
    this.setX = function(a) {
        h.x = a
    };
    this.setY = function(a) {
        h.y = a
    };
    this.enable = function() {
        g = !1;
        h.filters = [];
        h.cache(0, 0, k, p)
    };
    this.disable =
        function() {
            g = !0;
            var a = (new createjs.ColorMatrix).adjustSaturation(-100).adjustBrightness(40);
            h.filters = [new createjs.ColorMatrixFilter(a)];
            h.cache(0, 0, k, p)
        };
    this.getButtonImage = function() {
        return h
    };
    this.getX = function() {
        return h.x
    };
    this.getY = function() {
        return h.y
    };
    this._init(a, b, c);
    return this
}

function CToggle(a, b, c, d) {
    var g, k, p, n, r, e;
    this._init = function(a, b, c, d) {
        k = [];
        p = [];
        var h = new createjs.SpriteSheet({
            images: [c],
            frames: {
                width: c.width / 2,
                height: c.height,
                regX: c.width / 2 / 2,
                regY: c.height / 2
            },
            animations: {
                state_true: [0],
                state_false: [1]
            }
        });
        g = d;
        e = createSprite(h, "state_" + g, c.width / 2 / 2, c.height / 2, c.width / 2, c.height);
        e.x = a;
        e.y = b;
        e.stop();
        e.cursor = "pointer";
        s_oStage.addChild(e);
        this._initListener()
    };
    this.unload = function() {
        e.off("mousedown", n);
        e.off("pressup", r);
        s_oStage.removeChild(e)
    };
    this._initListener =
        function() {
            n = e.on("mousedown", this.buttonDown);
            r = e.on("pressup", this.buttonRelease)
        };
    this.addEventListener = function(a, b, c) {
        k[a] = b;
        p[a] = c
    };
    this.setActive = function(a) {
        g = a;
        e.gotoAndStop("state_" + g)
    };
    this.buttonRelease = function() {
        e.scaleX = 1;
        e.scaleY = 1;
        playSound("press_but", 1, !1);
        g = !g;
        e.gotoAndStop("state_" + g);
        k[ON_MOUSE_UP] && k[ON_MOUSE_UP].call(p[ON_MOUSE_UP], g)
    };
    this.buttonDown = function() {
        e.scaleX = .9;
        e.scaleY = .9;
        k[ON_MOUSE_DOWN] && k[ON_MOUSE_DOWN].call(p[ON_MOUSE_DOWN])
    };
    this.setPosition = function(a, b) {
        e.x =
            a;
        e.y = b
    };
    this._init(a, b, c, d)
}

function CMenu() {
    var a, b, c, d, g, k, p, n, r, e, m, u = null,
        h = null,
        x;
    this._init = function() {
        p = createBitmap(s_oSpriteLibrary.getSprite("bg_menu"));
        s_oStage.addChild(p);
        var v = s_oSpriteLibrary.getSprite("but_menu_bg");
        n = new CTextButton(CANVAS_WIDTH / 2, CANVAS_HEIGHT - 164, v, TEXT_PLAY, FONT1, "#ffffff", 50, 0, s_oStage);
        n.addEventListener(ON_MOUSE_UP, this._onButPlayRelease, this);
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) v = s_oSpriteLibrary.getSprite("audio_icon"), g = CANVAS_WIDTH - v.width / 4 - 10, k = v.height / 2 + 10, e = new CToggle(CANVAS_WIDTH -
            v.width / 2 + 20, v.height / 2 + 20, v, s_bAudioActive), e.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this), setVolume("soundtrack", 1);
        SHOW_CREDITS ? (v = s_oSpriteLibrary.getSprite("but_info"), a = v.height / 2 + 10, b = v.height / 2 + 10, r = new CGfxButton(a, b, v, s_oStage), r.addEventListener(ON_MOUSE_UP, this._onButCreditsRelease, this), c = a + v.width + 10, d = b) : (c = v.height / 2 + 10, d = v.height / 2 + 10);
        v = window.document;
        var A = v.documentElement;
        u = A.requestFullscreen || A.mozRequestFullScreen || A.webkitRequestFullScreen || A.msRequestFullscreen;
        h = v.exitFullscreen || v.mozCancelFullScreen || v.webkitExitFullscreen || v.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (u = !1);
        u && screenfull.isEnabled && (v = s_oSpriteLibrary.getSprite("but_fullscreen"), m = new CToggle(c, d, v, s_bFullscreen, !0), m.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        x = new createjs.Shape;
        x.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(x);
        createjs.Tween.get(x).to({
            alpha: 0
        }, 500).call(function() {
            x.visible = !1
        });
        this.refreshButtonPos(s_iOffsetX,
            s_iOffsetY)
    };
    this.unload = function() {
        n.unload();
        n = null;
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) e.unload(), e = null;
        u && screenfull.isEnabled && m.unload();
        SHOW_CREDITS && r.unload();
        s_oStage.removeChild(p);
        p = null;
        s_oStage.removeChild(x);
        s_oMenu = x = null
    };
    this.refreshButtonPos = function(h, n) {
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || e.setPosition(g - h, n + k);
        u && screenfull.isEnabled && m.setPosition(c + h, d + n);
        SHOW_CREDITS && r.setPosition(a + h, b + n)
    };
    this._onButPlayRelease = function() {
        this.unload();
        $(s_oMain).trigger("start_session");
        s_oMain.gotoGame()
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this._onButCreditsRelease = function() {
        new CCreditsPanel
    };
    this.resetFullscreenBut = function() {
        u && screenfull.isEnabled && m.setActive(s_bFullscreen)
    };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? h.call(window.document) : u.call(window.document.documentElement);
        sizeHandler()
    };
    s_oMenu = this;
    this._init()
}
var s_oMenu = null;

function CGame(a) {
    var b, c, d, g, k, p, n, r, e, m, u, h = [],
        x, v, A, w, z, D, E, F;
    this._init = function() {
        s_oPayTableSettings = new CPayTableSettings;
        d = TOTAL_MONEY;
        g = GAME_CASH;
        w = createBitmap(s_oSpriteLibrary.getSprite("bg_game"));
        s_oStage.addChild(w);
        F = new createjs.Container;
        F.x = 600;
        F.y = 530;
        s_oStage.addChild(F);
        D = new CPayTable(550, 149);
        b = !1;
        u = p = r = n = 0;
        k = parseFloat(BET_TYPE[n] * (r + 1));
        D.setCreditColumn(r);
        m = STATE_GAME_WAITING_FOR_BET;
        z = new CInterface(d, BET_TYPE[n]);
        E = new CGameOver;
        v = new CGameSettings;
        A = new CHandEvaluator;
        e = 0;
        x = [];
        x = v.getShuffledCardDeck();
        MIN_WIN = COMBO_PRIZES[COMBO_PRIZES.length - 1] * BET_TYPE[n] * (r + 1);
        this.placeFakeCardForStarting();
        setVolume("soundtrack", SOUNDTRACK_VOLUME_IN_GAME)
    };
    this.unload = function() {
        z.unload();
        E.unload();
        s_oStage.removeAllChildren()
    };
    this.resetHand = function() {
        e = p = 0;
        x = [];
        x = v.getShuffledCardDeck();
        for (var a = 0; a < h.length; a++) h[a].reset();
        z.resetHand();
        D.resetHand();
        this.checkMoney();
        b = !1;
        m = STATE_GAME_WAITING_FOR_BET
    };
    this.checkMoney = function() {
        d < k && (r = n = 0, k = parseFloat(BET_TYPE[n] *
            (r + 1)), d < k ? this._gameOver() : (z.refreshMoney(d, k), z.refreshBet(BET_TYPE[n])))
    };
    this.changeState = function(a) {};
    this.placeFakeCardForStarting = function() {
        for (var a = {
                images: [s_oSpriteLibrary.getSprite("card_spritesheet")],
                frames: {
                    width: CARD_WIDTH,
                    height: CARD_HEIGHT,
                    regX: CARD_WIDTH / 2,
                    regY: CARD_HEIGHT / 2
                },
                animations: {
                    card_1_1: [0],
                    card_1_2: [1],
                    card_1_3: [2],
                    card_1_4: [3],
                    card_1_5: [4],
                    card_1_6: [5],
                    card_1_7: [6],
                    card_1_8: [7],
                    card_1_9: [8],
                    card_1_10: [9],
                    card_1_J: [10],
                    card_1_Q: [11],
                    card_1_K: [12],
                    card_2_1: [13],
                    card_2_2: [14],
                    card_2_3: [15],
                    card_2_4: [16],
                    card_2_5: [17],
                    card_2_6: [18],
                    card_2_7: [19],
                    card_2_8: [20],
                    card_2_9: [21],
                    card_2_10: [22],
                    card_2_J: [23],
                    card_2_Q: [24],
                    card_2_K: [25],
                    card_3_1: [26],
                    card_3_2: [27],
                    card_3_3: [28],
                    card_3_4: [29],
                    card_3_5: [30],
                    card_3_6: [31],
                    card_3_7: [32],
                    card_3_8: [33],
                    card_3_9: [34],
                    card_3_10: [35],
                    card_3_J: [36],
                    card_3_Q: [37],
                    card_3_K: [38],
                    card_4_1: [39],
                    card_4_2: [40],
                    card_4_3: [41],
                    card_4_4: [42],
                    card_4_5: [43],
                    card_4_6: [44],
                    card_4_7: [45],
                    card_4_8: [46],
                    card_4_9: [47],
                    card_4_10: [48],
                    card_4_J: [49],
                    card_4_Q: [50],
                    card_4_K: [51],
                    back: [52]
                }
            }, b = 0, c = 0; 5 > c; c++) {
            var d = new createjs.SpriteSheet(a);
            d = createSprite(d, "back", CARD_WIDTH / 2, CARD_HEIGHT / 2, CARD_WIDTH, CARD_HEIGHT);
            d.x = b;
            d.y = 0;
            d.shadow = new createjs.Shadow("#000000", 5, 5, 5);
            F.addChild(d);
            b += 180
        }
    };
    this.dealCards = function() {
        if (!(b || 0 >= d)) {
            b = !0;
            F.removeAllChildren();
            if ((g < MIN_WIN ? WIN_OCCURRENCE + 1 : Math.floor(101 * Math.random())) > WIN_OCCURRENCE) {
                do this._createCard(); while (A.evaluate(h) < HIGH_CARD);
                c = !1
            } else {
                var a = 0;
                do {
                    this._createCard();
                    var e = A.evaluate(h),
                        p = 0;
                    e < HIGH_CARD &&
                        (p = s_oPayTableSettings.getWin(r, e) * BET_TYPE[n]);
                    a++
                } while (g < p && 5E3 > a);
                if (5E3 <= a) {
                    do this._createCard(); while (A.evaluate(h) < HIGH_CARD);
                    c = !1
                } else c = !0
            }
            d -= k;
            d = parseFloat(d.toFixed(2));
            g += k;
            g = parseFloat(g.toFixed(2));
            z.refreshMoney(d, k);
            playSound("card", 1, !1);
            $(s_oMain).trigger("bet_placed", k);
            m = STATE_GAME_DEAL
        }
    };
    this._createCard = function() {
        for (var a = 0; a < h.length; a++) h[a].unload();
        a = 0;
        h = [];
        for (var b = 0; 5 > b; b++) {
            var c = new CCard(a, 0, F, x[e].fotogram, x[e].rank, x[e].suit);
            c.addEventListener(ON_CARD_SHOWN, this._onCardShown);
            c.addEventListener(ON_CARD_HIDE, this._onCardHide);
            h.push(c);
            e++;
            this._checkDeckLength();
            a += 180;
            c.showCard()
        }
    };
    this.drawCards = function() {
        if (!b) {
            b = !0;
            playSound("card", 1, !1);
            for (var a = h.length, c = 0; c < h.length; c++) !1 === h[c].isHold() && (h[c].hideCard(), a--);
            a === h.length && (m = STATE_GAME_DRAW, this._onCardShown())
        }
    };
    this._checkDeckLength = function() {
        e >= x.length && (x = v.getShuffledCardDeck(), e = 0)
    };
    this.assignWin = function(a) {
        playSound("win", 1, !1);
        for (var b = A.getSortedHand(), c = 0; c < h.length; c++)
            for (var e = 0; e < b.length; e++)
                if (b[e].rank ===
                    h[c].getRank() && b[e].suit === h[c].getSuit()) {
                    h[c].highlight();
                    break
                }
        D.showWinAnim(r, a);
        p = s_oPayTableSettings.getWin(r, a) * BET_TYPE[n];
        d += p;
        d = parseFloat(d.toFixed(2));
        g -= p;
        z.refreshWin(p);
        z.refreshMoney(d, k)
    };
    this.recharge = function() {
        d = TOTAL_MONEY;
        D.setCreditColumn(r);
        this.checkMoney();
        z.refreshMoney(d, k);
        z.refreshBet(BET_TYPE[n]);
        E.hide()
    };
    this._gameOver = function() {
        E.show()
    };
    this.setMoney = function(a) {
        d = a;
        z.refreshMoney(d, k);
        E.hide()
    };
    this.onCardSelected = function(a) {
        m === STATE_GAME_CHOOSE_HOLD && a.toggleHold()
    };
    this._onCardShown = function() {
        if (m !== STATE_GAME_CHOOSE_HOLD) {
            switch (m) {
                case STATE_GAME_DEAL:
                    m = STATE_GAME_CHOOSE_HOLD;
                    z.setState(m);
                    break;
                case STATE_GAME_DRAW:
                    var a = A.evaluate(h);
                    z.setState(m);
                    a !== HIGH_CARD ? s_oGame.assignWin(a) : (playSound("lose", 1, !1), z.showLosePanel());
                    $(s_oMain).trigger("save_score", [d]);
                    u++;
                    u === NUM_HAND_FOR_ADS ? (u = 0, $(s_oMain).trigger("show_interlevel_ad")) : u === NUM_HAND_FOR_ADS - 1 && $(s_oMain).trigger("share_event", [d]);
                    m = STATE_GAME_EVALUATE;
                    break;
                case STATE_GAME_EVALUATE:
                    z.setState(m)
            }
            b = !1
        }
    };
    this._onCardHide = function() {
        if (m !== STATE_GAME_DRAW) {
            m = STATE_GAME_DRAW;
            if (c) {
                var a = 0;
                do {
                    s_oGame._changeCardValue();
                    var b = A.evaluate(h);
                    var d = b === HIGH_CARD ? 0 : s_oPayTableSettings.getWin(r, b) * BET_TYPE[n];
                    a++
                } while ((b === HIGH_CARD || g < d) && 1E3 > a);
                if (1E3 <= a) {
                    do s_oGame._changeCardValue(), b = A.evaluate(h); while (b < HIGH_CARD);
                    c = !1
                }
            } else {
                do s_oGame._changeCardValue(), b = A.evaluate(h); while (b < HIGH_CARD)
            }
            for (a = 0; 5 > a; a++) h[a].setHold(!1)
        }
    };
    this._changeCardValue = function() {
        for (var a = 0; 5 > a; a++) !1 === h[a].isHold() &&
            (h[a].changeInfo(x[e].fotogram, x[e].rank, x[e].suit), h[a].showCard(), e++, this._checkDeckLength())
    };
    this._onButDealRelease = function() {
        switch (m) {
            case STATE_GAME_WAITING_FOR_BET:
                this.dealCards();
                break;
            case STATE_GAME_CHOOSE_HOLD:
                this.drawCards();
                break;
            case STATE_GAME_EVALUATE:
                this.resetHand(), this.dealCards()
        }
    };
    this._onButLeftRelease = function() {
        if (!(0 === n || b || m !== STATE_GAME_WAITING_FOR_BET && m !== STATE_GAME_EVALUATE)) {
            n--;
            var a = parseFloat(BET_TYPE[n] * (r + 1));
            d < a ? n++ : (k = a, z.refreshMoney(d, k), z.refreshBet(BET_TYPE[n]),
                MIN_WIN = COMBO_PRIZES[COMBO_PRIZES.length - 1] * BET_TYPE[n] * (r + 1))
        }
    };
    this._onButRightRelease = function() {
        if (!(n === BET_TYPE.length - 1 || b || m !== STATE_GAME_WAITING_FOR_BET && m !== STATE_GAME_EVALUATE)) {
            n++;
            var a = parseFloat(BET_TYPE[n] * (r + 1));
            d < a ? n-- : (k = a, z.refreshMoney(d, k), z.refreshBet(BET_TYPE[n]), MIN_WIN = COMBO_PRIZES[COMBO_PRIZES.length - 1] * BET_TYPE[n] * (r + 1))
        }
    };
    this._onButBetOneRelease = function() {
        if (!(b || m !== STATE_GAME_WAITING_FOR_BET && m !== STATE_GAME_EVALUATE)) {
            r++;
            r === NUM_BETS && (r = 0);
            var a = parseFloat(BET_TYPE[n] *
                (r + 1));
            d < a ? 0 === r ? r = NUM_BETS - 1 : r-- : (k = a, z.refreshMoney(d, k), D.setCreditColumn(r), MIN_WIN = COMBO_PRIZES[COMBO_PRIZES.length - 1] * k * (r + 1))
        }
    };
    this._onButBetMaxRelease = function() {
        if (!(b || m !== STATE_GAME_WAITING_FOR_BET && m !== STATE_GAME_EVALUATE)) {
            b = !0;
            r = NUM_BETS - 1;
            var a = parseFloat(BET_TYPE[n] * (r + 1));
            d < a ? this._gameOver() : (k = a, z.refreshMoney(d, k), D.setCreditColumn(r), MIN_WIN = COMBO_PRIZES[COMBO_PRIZES.length - 1] * BET_TYPE[n] * (r + 1), this.resetHand(), this.dealCards())
        }
    };
    this.onExit = function() {
        this.unload();
        s_oMain.gotoMenu();
        $(s_oMain).trigger("end_session")
    };
    this.update = function() {};
    s_oGame = this;
    WIN_OCCURRENCE = a.win_occurrence;
    GAME_CASH = a.game_cash;
    BET_TYPE = a.bets;
    COMBO_PRIZES = a.combo_prizes;
    TOTAL_MONEY = a.money;
    AUTOMATIC_RECHARGE = a.recharge;
    NUM_HAND_FOR_ADS = a.num_hand_before_ads;
    this._init()
}
var s_oGame, s_oPayTableSettings;

function CInterface(a, b) {
    var c, d, g, k, p, n, r, e, m, u, h, x, v, A, w, z, D, E, F, y = null,
        O = null;
    this._init = function(a, b) {
        var l = s_oSpriteLibrary.getSprite("but_exit");
        c = CANVAS_WIDTH - l.width / 2 - 10;
        d = l.height / 2 + 10;
        r = new CGfxButton(c, d, l, s_oStage);
        r.addEventListener(ON_MOUSE_UP, this._onExit, this);
        !1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile ? (l = s_oSpriteLibrary.getSprite("audio_icon"), p = c - l.width / 2 - 10, n = d, v = new CToggle(p, n, l, s_bAudioActive), v.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this), g = p - l.width / 2 - 10, k = n) : (g =
            c - l.width - 10, k = d);
        l = window.document;
        var H = l.documentElement;
        y = H.requestFullscreen || H.mozRequestFullScreen || H.webkitRequestFullScreen || H.msRequestFullscreen;
        O = l.exitFullscreen || l.mozCancelFullScreen || l.webkitExitFullscreen || l.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (y = !1);
        y && screenfull.isEnabled && (l = s_oSpriteLibrary.getSprite("but_fullscreen"), F = new CToggle(g, k, l, s_bFullscreen, !0), F.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        l = createBitmap(s_oSpriteLibrary.getSprite("display_bg"));
        l.x = 480;
        l.y = 25;
        s_oStage.addChild(l);
        new CTLText(s_oStage, 470, 20, 100, 22, 22, "left", "#fff", FONT1, 1, 0, 0, TEXT_WIN, !0, !0, !1, !1);
        l = createBitmap(s_oSpriteLibrary.getSprite("display_bg"));
        l.x = 480;
        l.y = 93;
        s_oStage.addChild(l);
        new CTLText(s_oStage, 470, 90, 100, 22, 22, "left", "#fff", FONT1, 1, 0, 0, TEXT_BET, !0, !0, !1, !1);
        l = createBitmap(s_oSpriteLibrary.getSprite("display_bg"));
        l.x = 470;
        l.y = 687;
        s_oStage.addChild(l);
        new CTLText(s_oStage, 460, 685, 100, 22, 22, "left", "#fff", FONT1, 1, 0, 0, TEXT_MONEY, !0, !0, !1, !1);
        A = new CTLText(s_oStage,
            480, CANVAS_HEIGHT - 66, 210, 30, 30, "center", "#ffde00", FONT2, 1, 0, 0, a.toFixed(2) + TEXT_CURRENCY, !0, !0, !1, !1);
        z = new CTLText(s_oStage, 490, 110, 210, 30, 30, "center", "#ffde00", FONT2, 1, 0, 0, b.toFixed(2) + TEXT_CURRENCY, !0, !0, !1, !1);
        w = new CTLText(s_oStage, 490, 40, 210, 30, 30, "center", "#ffde00", FONT2, 1, 0, 0, "0" + TEXT_CURRENCY, !0, !0, !1, !1);
        l = createBitmap(s_oSpriteLibrary.getSprite("big_display"));
        l.x = 770;
        l.y = 686;
        s_oStage.addChild(l);
        D = new CTLText(s_oStage, 780, 700, 108, 40, 40, "center", "#ffde00", FONT2, 1, 0, 0, b.toFixed(2) + TEXT_CURRENCY, !0, !0, !1, !1);
        l = s_oSpriteLibrary.getSprite("logo_game");
        H = createBitmap(l);
        H.x = CANVAS_WIDTH / 2;
        H.y = 17;
        H.regX = l.width / 2;
        s_oStage.addChild(H);
        l = s_oSpriteLibrary.getSprite("but_left");
        e = new CGfxButton(744, 722, l, s_oStage);
        e.addEventListener(ON_MOUSE_UP, this._onButLeftRelease, this);
        l = s_oSpriteLibrary.getSprite("but_right");
        m = new CGfxButton(930, 722, l, s_oStage);
        m.addEventListener(ON_MOUSE_UP, this._onButRightRelease, this);
        l = s_oSpriteLibrary.getSprite("but_game_bg");
        u = new CTextButton(1040, 716, l, TEXT_BET_ONE,
            FONT1, "#ffffff", 23, 0, s_oStage);
        u.addEventListener(ON_MOUSE_UP, this._onButBetOneRelease, this);
        h = new CTextButton(1190, 716, l, TEXT_MAX_BET, FONT1, "#ffffff", 23, 0, s_oStage);
        h.addEventListener(ON_MOUSE_UP, this._onButBetMaxRelease, this);
        x = new CTextButton(1340, 716, l, TEXT_DEAL, FONT1, "#ffffff", 30, 0, s_oStage);
        x.addEventListener(ON_MOUSE_UP, this._onButDealRelease, this);
        E = new createjs.Container;
        E.visible = !1;
        E.x = 710;
        E.y = 500;
        s_oStage.addChild(E);
        l = new createjs.Shape;
        l.graphics.beginFill("rgba(0,0,0,0.7)").drawRect(0,
            0, 500, 100);
        E.addChild(l);
        new CTLText(E, 0, 0, 500, 100, 50, "center", "#fff", FONT1, 1, 10, 5, TEXT_NO_WIN, !0, !0, !1, !1);
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.unload = function() {
        r.unload();
        e.unload();
        m.unload();
        u.unload();
        h.unload();
        x.unload();
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) v.unload(), v = null;
        y && screenfull.isEnabled && F.unload();
        s_oInterface = null
    };
    this.refreshButtonPos = function(a, b) {
        r.setPosition(c - a, b + d);
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || v.setPosition(p - a, b + n);
        y && screenfull.isEnabled &&
            F.setPosition(g - a, k + b)
    };
    this.setState = function(a) {
        switch (a) {
            case STATE_GAME_CHOOSE_HOLD:
                x.changeText(TEXT_DRAW);
                break;
            case STATE_GAME_EVALUATE:
                x.changeText(TEXT_DEAL)
        }
    };
    this.resetHand = function() {
        this.refreshWin(0);
        E.visible = !1
    };
    this.refreshMoney = function(a, b) {
        A.refreshText(a.toFixed(2) + TEXT_CURRENCY);
        z.refreshText(b.toFixed(2) + TEXT_CURRENCY)
    };
    this.refreshWin = function(a) {
        w.refreshText(a.toFixed(2) + TEXT_CURRENCY)
    };
    this.refreshBet = function(a) {
        D.refreshText(a.toFixed(2) + TEXT_CURRENCY)
    };
    this.showLosePanel =
        function() {
            E.visible = !0
        };
    this._onButLeftRelease = function() {
        s_oGame._onButLeftRelease()
    };
    this._onButRightRelease = function() {
        s_oGame._onButRightRelease()
    };
    this._onButBetOneRelease = function() {
        s_oGame._onButBetOneRelease()
    };
    this._onButBetMaxRelease = function() {
        s_oGame._onButBetMaxRelease()
    };
    this._onButDealRelease = function() {
        s_oGame._onButDealRelease()
    };
    this._onExit = function() {
        s_oGame.onExit()
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this.resetFullscreenBut =
        function() {
            y && screenfull.isEnabled && F.setActive(s_bFullscreen)
        };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? O.call(window.document) : y.call(window.document.documentElement);
        sizeHandler()
    };
    s_oInterface = this;
    this._init(a, b);
    return this
}
var s_oInterface = null;

function CGameSettings() {
    var a, b;
    this._init = function() {
        var b = -1;
        a = [];
        for (var d = 0; 52 > d; d++) {
            var g = (d + 1) % 13;
            1 === g ? (g = 14, b++) : 0 === g && (g = 13);
            a.push({
                fotogram: d,
                rank: g,
                suit: b
            })
        }
    };
    this.timeToString = function(a) {
        a = Math.round(a / 1E3);
        var b = Math.floor(a / 60);
        a -= 60 * b;
        var c = "";
        c = 10 > b ? c + ("0" + b + ":") : c + (b + ":");
        return 10 > a ? c + ("0" + a) : c + a
    };
    this.getShuffledCardDeck = function() {
        for (var c = [], d = 0; d < a.length; d++) c[d] = a[d];
        for (b = []; 0 < c.length;) b.push(c.splice(Math.round(Math.random() * (c.length - 1)), 1)[0]);
        return b
    };
    this.getCardValue =
        function(a) {
            return (void 0)[a]
        };
    this._init()
}

function CCard(a, b, c, d, g, k) {
    var p, n, r, e, m, u, h, x, v, A, w;
    this._init = function(a, b, c, d, g, k) {
        p = !1;
        w = c;
        n = d;
        r = g;
        e = k;
        c = s_oSpriteLibrary.getSprite("card_spritesheet");
        c = new createjs.SpriteSheet({
            images: [c],
            frames: {
                width: CARD_WIDTH,
                height: CARD_HEIGHT,
                regX: CARD_WIDTH / 2,
                regY: CARD_HEIGHT / 2
            },
            animations: {
                card_1_1: [0],
                card_1_2: [1],
                card_1_3: [2],
                card_1_4: [3],
                card_1_5: [4],
                card_1_6: [5],
                card_1_7: [6],
                card_1_8: [7],
                card_1_9: [8],
                card_1_10: [9],
                card_1_J: [10],
                card_1_Q: [11],
                card_1_K: [12],
                card_2_1: [13],
                card_2_2: [14],
                card_2_3: [15],
                card_2_4: [16],
                card_2_5: [17],
                card_2_6: [18],
                card_2_7: [19],
                card_2_8: [20],
                card_2_9: [21],
                card_2_10: [22],
                card_2_J: [23],
                card_2_Q: [24],
                card_2_K: [25],
                card_3_1: [26],
                card_3_2: [27],
                card_3_3: [28],
                card_3_4: [29],
                card_3_5: [30],
                card_3_6: [31],
                card_3_7: [32],
                card_3_8: [33],
                card_3_9: [34],
                card_3_10: [35],
                card_3_J: [36],
                card_3_Q: [37],
                card_3_K: [38],
                card_4_1: [39],
                card_4_2: [40],
                card_4_3: [41],
                card_4_4: [42],
                card_4_5: [43],
                card_4_6: [44],
                card_4_7: [45],
                card_4_8: [46],
                card_4_9: [47],
                card_4_10: [48],
                card_4_J: [49],
                card_4_Q: [50],
                card_4_K: [51],
                back: [52]
            }
        });
        h = createSprite(c, "back", CARD_WIDTH / 2, CARD_HEIGHT / 2, CARD_WIDTH, CARD_HEIGHT);
        h.x = a;
        h.y = b;
        h.stop();
        h.shadow = new createjs.Shadow("#000000", 5, 5, 5);
        w.addChild(h);
        c = s_oSpriteLibrary.getSprite("card_selection");
        A = createBitmap(c);
        A.x = a;
        A.y = b;
        A.regX = c.width / 2;
        A.regY = c.height / 2;
        A.visible = !1;
        w.addChild(A);
        c = s_oSpriteLibrary.getSprite("hold");
        x = createBitmap(c);
        x.regX = c.width / 2;
        x.x = a;
        x.y = b + 76;
        x.visible = !1;
        w.addChild(x);
        v = new createjs.Shape;
        v.graphics.beginFill("rgba(255,255,255,0.01)").drawRect(a -
            CARD_WIDTH / 2, b - CARD_HEIGHT / 2, CARD_WIDTH, CARD_HEIGHT);
        v.on("click", this._onSelected);
        v.cursor = "pointer";
        w.addChild(v);
        m = [];
        u = []
    };
    this.unload = function() {
        v.off("click", this._onSelected);
        w.removeChild(h)
    };
    this.reset = function() {
        p = !1;
        A.visible = !1;
        h.shadow = new createjs.Shadow("#000000", 5, 5, 5)
    };
    this.addEventListener = function(a, b, c) {
        m[a] = b;
        u[a] = c
    };
    this.changeInfo = function(a, b, c) {
        n = a;
        r = b;
        e = c
    };
    this.setValue = function() {
        h.gotoAndStop(n);
        var a = this;
        createjs.Tween.get(h).to({
            scaleX: 1
        }, 200).call(function() {
            a.cardShown()
        })
    };
    this.setHold = function(a) {
        p = a;
        x.visible = p
    };
    this.toggleHold = function() {
        p = !p;
        x.visible = p;
        playSound("press_hold", 1, !1)
    };
    this.showCard = function() {
        var a = this;
        createjs.Tween.get(h).to({
            scaleX: .1
        }, 200).call(function() {
            a.setValue()
        })
    };
    this.hideCard = function() {
        var a = this;
        createjs.Tween.get(h).to({
            scaleX: .1
        }, 200).call(function() {
            a.setBack()
        })
    };
    this.setBack = function() {
        h.gotoAndStop("back");
        var a = this;
        createjs.Tween.get(h).to({
            scaleX: 1
        }, 200).call(function() {
            a.cardHidden()
        })
    };
    this.cardShown = function() {
        m[ON_CARD_SHOWN] &&
            m[ON_CARD_SHOWN].call(u[ON_CARD_SHOWN])
    };
    this.cardHidden = function() {
        m[ON_CARD_HIDE] && m[ON_CARD_HIDE].call(u[ON_CARD_HIDE], this)
    };
    this.highlight = function() {
        h.shadow = new createjs.Shadow("#fff000", 0, 0, 15);
        A.visible = !0
    };
    this._onSelected = function() {
        s_oGame.onCardSelected(z)
    };
    this.getRank = function() {
        return r
    };
    this.getSuit = function() {
        return e
    };
    this.getFotogram = function() {
        return n
    };
    this.isHold = function() {
        return p
    };
    var z = this;
    this._init(a, b, c, d, g, k)
}

function CGameOver() {
    var a, b, c;
    this._init = function() {
        c = new createjs.Container;
        s_oStage.addChild(c);
        var d = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        c.addChild(d);
        new CTLText(c, CANVAS_WIDTH / 2 - 198, CANVAS_HEIGHT / 2 - 98, 400, 50, 50, "center", "#000", FONT1, 1, 0, 0, TEXT_GAMEOVER, !0, !0, !1, !1);
        new CTLText(c, CANVAS_WIDTH / 2 - 200, CANVAS_HEIGHT / 2 - 100, 400, 50, 50, "center", "#fff", FONT1, 1, 0, 0, TEXT_GAMEOVER, !0, !0, !1, !1);
        a = new CTextButton(CANVAS_WIDTH / 2 - 100, 450, s_oSpriteLibrary.getSprite("but_game_bg"), TEXT_RECHARGE,
            FONT1, "#fff", 14, 0, c);
        a.addEventListener(ON_MOUSE_UP, this._onRecharge, this);
        b = new CTextButton(CANVAS_WIDTH / 2 + 100, 450, s_oSpriteLibrary.getSprite("but_game_bg"), TEXT_EXIT, FONT1, "#fff", 14, 0, c);
        b.addEventListener(ON_MOUSE_UP, this._onExit, this);
        this.hide()
    };
    this.unload = function() {
        a.unload();
        b.unload()
    };
    this.show = function() {
        c.visible = !0
    };
    this.hide = function() {
        c.visible = !1
    };
    this._onRecharge = function() {
        AUTOMATIC_RECHARGE ? s_oGame.recharge() : $(s_oMain).trigger("recharge")
    };
    this._onExit = function() {
        $(s_oMain).trigger("end_session");
        s_oGame.onExit()
    };
    this._init()
}

function CPayTable(a, b) {
    var c, d, g, k;
    this._init = function(a, b) {
        k = new createjs.Container;
        k.x = a;
        k.y = b;
        s_oStage.addChild(k);
        var n = createBitmap(s_oSpriteLibrary.getSprite("paytable"));
        k.addChild(n);
        n = 278;
        var e = 4;
        c = [];
        for (var m = 0; m < NUM_BETS; m++) {
            var p = createBitmap(s_oSpriteLibrary.getSprite("selection"));
            p.visible = !1;
            p.x = n;
            p.y = e;
            k.addChild(p);
            c.push(p);
            n += 100
        }
        n = 25;
        e = 15;
        g = [];
        for (m = 0; m < WIN_COMBINATIONS; m++) p = new CTLText(k, n, e, 250, 19, 19, "right", "#fff000", FONT1, 1, 0, 0, TEXT_COMBO[m], !0, !0, !1, !1), e += 20, g[m] = p;
        n = 375;
        d = [];
        for (m = 0; m < NUM_BETS; m++) {
            e = 27;
            d[m] = [];
            for (p = 0; p < WIN_COMBINATIONS; p++) {
                var h = new createjs.Text(s_oPayTableSettings.getWin(m, p), "19px " + FONT1, "#fff000");
                h.x = n;
                h.y = e;
                h.textAlign = "right";
                h.textBaseline = "middle";
                k.addChild(h);
                e += 20;
                d[m][p] = h
            }
            n += 100
        }
    };
    this.resetHand = function() {
        createjs.Tween.removeAllTweens();
        for (var a = 0; a < NUM_BETS; a++)
            for (var b = 0; b < WIN_COMBINATIONS; b++) d[a][b].alpha = 1;
        for (a = 0; a < WIN_COMBINATIONS; a++) g[a].alpha = 1
    };
    this.setCreditColumn = function(a) {
        for (var b = 0; b < NUM_BETS; b++) c[b].visible = !1;
        c[a].visible = !0
    };
    this.showWinAnim = function(a, b) {
        createjs.Tween.get(d[a][b], {
            loop: -1
        }).to({
            alpha: 0
        }, 200).to({
            alpha: 1
        }, 200);
        createjs.Tween.get(g[b], {
            loop: -1
        }).to({
            alpha: 0
        }, 200).to({
            alpha: 1
        }, 200)
    };
    this._init(a, b)
}

function CPayTableSettings() {
    var a;
    this._init = function() {
        a = [];
        for (var b = 0; b < NUM_BETS; b++) {
            a[b] = [];
            for (var c = 0; c < WIN_COMBINATIONS; c++) a[b][c] = COMBO_PRIZES[c] * (b + 1)
        }
    };
    this.getWin = function(b, c) {
        return a[b][c]
    };
    this._init()
}

function CHandEvaluator() {
    var a;
    this.evaluate = function(b) {
        a = [];
        for (var c = 0; c < b.length; c++) a[c] = {
            rank: b[c].getRank(),
            suit: b[c].getSuit()
        };
        a.sort(this.compareRank);
        return this.rankHand()
    };
    this.rankHand = function() {
        if (this._checkForRoyalFlushNoDeuces()) return ROYAL_FLUSH_NO_DEUCES;
        if (this._checkForFourDeuces()) return FOUR_DEUCES;
        if (this._checkForRoyalFlushWithDeuces()) return ROYAL_FLUSH_WITH_DEUCES;
        if (this._checkForFiveOfAKind()) return FIVE_OF_A_KIND;
        if (this._checkForStraightFlush()) return STRAIGHT_FLUSH;
        if (this._checkForFourOfAKind()) return FOUR_OF_A_KIND;
        if (this._checkForFullHouse()) return FULL_HOUSE;
        if (this._checkForFlush()) return FLUSH;
        if (this._checkForStraight()) return STRAIGHT;
        if (this._checkForThreeOfAKind()) return THREE_OF_A_KIND;
        this._identifyHighCard();
        return HIGH_CARD
    };
    this._checkForRoyalFlushNoDeuces = function() {
        if (this._isRoyalStraight() && this._isFlush()) {
            for (var b = 0; b < a.length; b++)
                if (a[b].rank === CARD_TWO) return !1;
            return !0
        }
        return !1
    };
    this._checkForFourDeuces = function() {
        var b = this.getDeucesNum();
        return 4 === b.cont ? (a.splice(b.indexes[0], 1), !0) : !1
    };
    this._checkForRoyalFlushWithDeuces = function() {
        if (this._isRoyalStraight() && this._isFlush())
            for (var b = 0; b < a.length; b++)
                if (a[b].rank === CARD_TWO) return !0;
        return !1
    };
    this._checkForFiveOfAKind = function() {
        for (var b = a[a.length - 1].rank, c = this.getDeucesNum().cont, d = c; d < a.length; d++) a[d].rank === b && c++;
        return 5 === c ? !0 : !1
    };
    this._checkForStraightFlush = function() {
        return this._isStraight() && this._isFlush() ? !0 : !1
    };
    this._checkForFourOfAKind = function() {
        var b = this.getDeucesNum().cont;
        return a[b].rank === a[3].rank ? (a.splice(4, 1), !0) : a[b + 1].rank === a[4].rank ? (a.splice(b, 1), !0) : !1
    };
    this._checkForFullHouse = function() {
        return (a[0].rank === a[1].rank || a[0].rank === CARD_TWO) && a[2].rank === a[4].rank || (a[0].rank === a[2].rank || a[0].rank === CARD_TWO && a[1].rank === a[2].rank) && a[3].rank === a[4].rank || a[0].rank === CARD_TWO && a[0].rank === a[1].rank && a[3].rank === a[4].rank ? !0 : !1
    };
    this._checkForFlush = function() {
        return this._isFlush() ? !0 : !1
    };
    this._checkForStraight = function() {
        return this._isStraight() ? !0 : !1
    };
    this._checkForThreeOfAKind = function() {
        var b = this.getDeucesNum().cont;
        if (2 === b) return a.splice(2, 1), a.splice(2, 1), !0;
        if (1 === b) {
            if (a[1].rank === a[2].rank) return a.splice(3, 1), a.splice(3, 1), !0;
            if (a[1].rank === a[3].rank) return a.splice(2, 1), a.splice(3, 1), !0;
            if (a[2].rank === a[3].rank) return a.splice(1, 1), a.splice(3, 1), !0;
            if (a[3].rank === a[4].rank) return a.splice(1, 1), a.splice(1, 1), !0
        } else {
            if (a[0].rank === a[1].rank && a[0].rank === a[2].rank) return a.splice(3, 1), a.splice(3, 1), !0;
            if (a[1].rank === a[2].rank && a[1].rank ===
                a[3].rank) return a.splice(0, 1), a.splice(3, 1), !0;
            if (a[2].rank === a[3].rank && a[2].rank === a[4].rank) return a.splice(0, 1), a.splice(0, 1), !0
        }
        return !1
    };
    this._checkForTwoPair = function() {
        return a[0].rank === a[1].rank && a[2].rank === a[3].rank ? (a.splice(4, 1), !0) : a[1].rank === a[2].rank && a[3].rank === a[4].rank ? (a.splice(0, 1), !0) : a[0].rank === a[1].rank && a[3].rank === a[4].rank ? (a.splice(2, 1), !0) : !1
    };
    this._checkForOnePair = function() {
        for (var b = 0; 4 > b; b++)
            if (a[b].rank === a[b + 1].rank && a[b].rank > CARD_TEN) {
                var c = a[b];
                b = a[b + 1];
                a = [];
                a.push(c);
                a.push(b);
                return !0
            }
        return !1
    };
    this._identifyHighCard = function() {
        for (var b = 0; 4 > b; b++) a.splice(0, 1)
    };
    this._isFlush = function() {
        return a[4].suit !== a[0].suit && a[0].rank !== CARD_TWO || a[4].suit !== a[1].suit && a[1].rank !== CARD_TWO || a[4].suit !== a[2].suit && a[2].rank !== CARD_TWO || a[4].suit !== a[3].suit && a[3].rank !== CARD_TWO ? !1 : !0
    };
    this._isRoyalStraight = function() {
        return a[0].rank !== CARD_TEN && a[0].rank !== CARD_TWO || a[1].rank !== CARD_JACK && a[1].rank !== CARD_TWO || a[2].rank !== CARD_QUEEN && a[2].rank !== CARD_TWO ||
            a[3].rank !== CARD_KING && a[3].rank !== CARD_TWO || a[4].rank !== CARD_ACE && a[4].rank !== CARD_TWO ? !1 : !0
    };
    this._isStraight = function() {
        for (var b = this.getDeucesNum().cont, c = 0, d = b; d < a.length - 1; d++) {
            var g = a[d + 1].rank - (a[d].rank + 1);
            if (0 < g)
                if (a[d + 1].rank === CARD_ACE && 1 === a[b].rank - b - 1) break;
                else {
                    if (c += g, c > b) return !1
                }
            else if (0 > g) return !1
        }
        return !0
    };
    this.getDeucesNum = function() {
        for (var b = [], c = 0; c < a.length; c++) a[c].rank !== CARD_TWO && b.push(c);
        return {
            cont: a.length - b.length,
            indexes: b
        }
    };
    this.compareRank = function(a, c) {
        return a.rank <
            c.rank ? -1 : a.rank > c.rank ? 1 : 0
    };
    this.getSortedHand = function() {
        return a
    }
}

function CCreditsPanel() {
    var a, b, c, d, g, k, p, n, r, e, m;
    this._init = function() {
        m = new createjs.Container;
        m.alpha = 0;
        s_oStage.addChild(m);
        c = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        m.addChild(c);
        n = new createjs.Shape;
        n.graphics.beginFill("#0f0f0f").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        n.alpha = .01;
        b = n.on("click", this._onLogoButRelease);
        m.addChild(n);
        var u = s_oSpriteLibrary.getSprite("but_exit");
        a = CANVAS_WIDTH / 2 + 240;
        g = new CGfxButton(a, 270, u, m);
        g.addEventListener(ON_MOUSE_UP, this.unload, this);
        p =
            new createjs.Text(TEXT_CREDITS_DEVELOPED, "34px " + FONT1, "#000");
        p.textAlign = "center";
        p.textBaseline = "alphabetic";
        p.x = CANVAS_WIDTH / 2;
        p.y = 340;
        p.outline = 2;
        m.addChild(p);
        k = new createjs.Text(TEXT_CREDITS_DEVELOPED, "34px " + FONT1, "#fff");
        k.textAlign = "center";
        k.textBaseline = "alphabetic";
        k.x = CANVAS_WIDTH / 2;
        k.y = 340;
        m.addChild(k);
        u = s_oSpriteLibrary.getSprite("logo_ctl");
        d = createBitmap(u);
        d.regX = u.width / 2;
        d.regY = u.height / 2;
        d.x = CANVAS_WIDTH / 2;
        d.y = CANVAS_HEIGHT / 2;
        m.addChild(d);
        e = new createjs.Text("www.codethislab.com",
            "30px " + FONT1, "#000");
        e.textAlign = "center";
        e.textBaseline = "alphabetic";
        e.x = CANVAS_WIDTH / 2;
        e.y = 450;
        e.outline = 2;
        m.addChild(e);
        r = new createjs.Text("www.codethislab.com", "30px " + FONT1, "#fff");
        r.textAlign = "center";
        r.textBaseline = "alphabetic";
        r.x = CANVAS_WIDTH / 2;
        r.y = 450;
        m.addChild(r);
        createjs.Tween.get(m).to({
            alpha: 1
        }, 600, createjs.Ease.cubicOut);
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.refreshButtonPos = function(a, b) {};
    this.unload = function() {
        n.off("click", b);
        g.unload();
        g = null;
        s_oStage.removeChild(m)
    };
    this._onLogoButRelease = function() {
        window.open("http://www.codethislab.com/index.php?&l=en", "_blank")
    };
    this._init()
}
CTLText.prototype = {
    constructor: CTLText,
    __autofit: function() {
        if (this._bFitText) {
            for (var a = this._iFontSize;
                (this._oText.getBounds().height > this._iHeight - 2 * this._iPaddingV || this._oText.getBounds().width > this._iWidth - 2 * this._iPaddingH) && !(a--, this._oText.font = a + "px " + this._szFont, this._oText.lineHeight = Math.round(a * this._fLineHeightFactor), this.__updateY(), this.__verticalAlign(), 8 > a););
            this._iFontSize = a
        }
    },
    __verticalAlign: function() {
        if (this._bVerticalAlign) {
            var a = this._oText.getBounds().height;
            this._oText.y -=
                (a - this._iHeight) / 2 + this._iPaddingV
        }
    },
    __updateY: function() {
        this._oText.y = this._y + this._iPaddingV;
        switch (this._oText.textBaseline) {
            case "middle":
                this._oText.y += this._oText.lineHeight / 2 + (this._iFontSize * this._fLineHeightFactor - this._iFontSize)
        }
    },
    __createText: function(a) {
        this._bDebug && (this._oDebugShape = new createjs.Shape, this._oDebugShape.graphics.beginFill("rgba(255,0,0,0.5)").drawRect(this._x, this._y, this._iWidth, this._iHeight), this._oContainer.addChild(this._oDebugShape));
        this._oText = new createjs.Text(a,
            this._iFontSize + "px " + this._szFont, this._szColor);
        this._oText.textBaseline = "middle";
        this._oText.lineHeight = Math.round(this._iFontSize * this._fLineHeightFactor);
        this._oText.textAlign = this._szAlign;
        this._oText.lineWidth = this._bMultiline ? this._iWidth - 2 * this._iPaddingH : null;
        switch (this._szAlign) {
            case "center":
                this._oText.x = this._x + this._iWidth / 2;
                break;
            case "left":
                this._oText.x = this._x + this._iPaddingH;
                break;
            case "right":
                this._oText.x = this._x + this._iWidth - this._iPaddingH
        }
        this._oContainer.addChild(this._oText);
        this.refreshText(a)
    },
    setVerticalAlign: function(a) {
        this._bVerticalAlign = a
    },
    setOutline: function(a) {
        null !== this._oText && (this._oText.outline = a)
    },
    setShadow: function(a, b, c, d) {
        null !== this._oText && (this._oText.shadow = new createjs.Shadow(a, b, c, d))
    },
    setColor: function(a) {
        this._oText.color = a
    },
    setAlpha: function(a) {
        this._oText.alpha = a
    },
    removeTweens: function() {
        createjs.Tween.removeTweens(this._oText)
    },
    getText: function() {
        return this._oText
    },
    getY: function() {
        return this._y
    },
    getFontSize: function() {
        return this._iFontSize
    },
    refreshText: function(a) {
        "" === a && (a = " ");
        null === this._oText && this.__createText(a);
        this._oText.text = a;
        this._oText.font = this._iFontSize + "px " + this._szFont;
        this._oText.lineHeight = Math.round(this._iFontSize * this._fLineHeightFactor);
        this.__autofit();
        this.__updateY();
        this.__verticalAlign()
    }
};

function CTLText(a, b, c, d, g, k, p, n, r, e, m, u, h, x, v, A, w) {
    this._oContainer = a;
    this._x = b;
    this._y = c;
    this._iWidth = d;
    this._iHeight = g;
    this._bMultiline = A;
    this._iFontSize = k;
    this._szAlign = p;
    this._szColor = n;
    this._szFont = r;
    this._iPaddingH = m;
    this._iPaddingV = u;
    this._bVerticalAlign = v;
    this._bFitText = x;
    this._bDebug = w;
    this._oDebugShape = null;
    this._fLineHeightFactor = e;
    this._oText = null;
    h && this.__createText(h)
}

function extractHostname(a) {
    a = -1 < a.indexOf("://") ? a.split("/")[2] : a.split("/")[0];
    a = a.split(":")[0];
    return a = a.split("?")[0]
}

function extractRootDomain(a) {
    a = extractHostname(a);
    var b = a.split("."),
        c = b.length;
    2 < c && (a = b[c - 2] + "." + b[c - 1]);
    return a
}
var getClosestTop = function() {
        var a = window,
            b = !1;
        try {
            for (; a.parent.document !== a.document;)
                if (a.parent.document) a = a.parent;
                else {
                    b = !0;
                    break
                }
        } catch (c) {
            b = !0
        }
        return {
            topFrame: a,
            err: b
        }
    },
    getBestPageUrl = function(a) {
        var b = a.topFrame,
            c = "";
        if (a.err) try {
            try {
                c = window.top.location.href
            } catch (g) {
                var d = window.location.ancestorOrigins;
                c = d[d.length - 1]
            }
        } catch (g) {
            c = b.document.referrer
        } else c = b.location.href;
        return c
    },
    TOPFRAMEOBJ = getClosestTop(),
    PAGE_URL = getBestPageUrl(TOPFRAMEOBJ);

function seekAndDestroy() {
    for (var a = extractRootDomain(PAGE_URL), b = [String.fromCharCode(99, 111, 100, 101, 116, 104, 105, 115, 108, 97, 98, 46, 99, 111, 109), String.fromCharCode(101, 110, 118, 97, 116, 111, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 110, 101, 116)], c = 0; c < b.length; c++)
        if (b[c] === a) return !0;
    return !1
};