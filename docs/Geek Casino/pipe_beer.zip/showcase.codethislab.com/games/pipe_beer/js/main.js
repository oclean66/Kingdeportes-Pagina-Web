(function() {
    var b = "undefined" !== typeof window && "undefined" !== typeof window.document ? window.document : {},
        f = "undefined" !== typeof module && module.exports,
        a = "undefined" !== typeof Element && "ALLOW_KEYBOARD_INPUT" in Element,
        c = function() {
            for (var a, g = ["requestFullscreen exitFullscreen fullscreenElement fullscreenEnabled fullscreenchange fullscreenerror".split(" "), "webkitRequestFullscreen webkitExitFullscreen webkitFullscreenElement webkitFullscreenEnabled webkitfullscreenchange webkitfullscreenerror".split(" "),
                    "webkitRequestFullScreen webkitCancelFullScreen webkitCurrentFullScreenElement webkitCancelFullScreen webkitfullscreenchange webkitfullscreenerror".split(" "), "mozRequestFullScreen mozCancelFullScreen mozFullScreenElement mozFullScreenEnabled mozfullscreenchange mozfullscreenerror".split(" "), "msRequestFullscreen msExitFullscreen msFullscreenElement msFullscreenEnabled MSFullscreenChange MSFullscreenError".split(" ")
                ], c = 0, e = g.length, f = {}; c < e; c++)
                if ((a = g[c]) && a[1] in b) {
                    for (c = 0; c < a.length; c++) f[g[0][c]] =
                        a[c];
                    return f
                }
            return !1
        }(),
        e = {
            change: c.fullscreenchange,
            error: c.fullscreenerror
        },
        h = {
            request: function(d) {
                var g = c.requestFullscreen;
                d = d || b.documentElement;
                if (/5\.1[.\d]* Safari/.test(navigator.userAgent)) d[g]();
                else d[g](a && Element.ALLOW_KEYBOARD_INPUT)
            },
            exit: function() {
                b[c.exitFullscreen]()
            },
            toggle: function(b) {
                this.isFullscreen ? this.exit() : this.request(b)
            },
            onchange: function(b) {
                this.on("change", b)
            },
            onerror: function(b) {
                this.on("error", b)
            },
            on: function(a, g) {
                var d = e[a];
                d && b.addEventListener(d, g, !1)
            },
            off: function(a,
                g) {
                var d = e[a];
                d && b.removeEventListener(d, g, !1)
            },
            raw: c
        };
    c ? (Object.defineProperties(h, {
        isFullscreen: {
            get: function() {
                return !!b[c.fullscreenElement]
            }
        },
        element: {
            enumerable: !0,
            get: function() {
                return b[c.fullscreenElement]
            }
        },
        enabled: {
            enumerable: !0,
            get: function() {
                return !!b[c.fullscreenEnabled]
            }
        }
    }), f ? module.exports = h : window.screenfull = h) : f ? module.exports = !1 : window.screenfull = !1
})();
var s_iScaleFactor = 1,
    s_bIsIphone = !1,
    s_iOffsetX, s_iOffsetY;
(function(b) {
    (jQuery.browser = jQuery.browser || {}).mobile = /android|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(ad|hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|tablet|treo|up\.(browser|link)|vodafone|wap|webos|windows (ce|phone)|xda|xiino/i.test(b) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(b.substr(0,
        4))
})(navigator.userAgent || navigator.vendor || window.opera);
$(window).resize(function() {
    sizeHandler()
});

function NotImplementedError(b) {
    this.name = "NotImplementedError";
    this.message = b || ""
}
NotImplementedError.prototype = Error.prototype;

function error(b) {
    throw {
        name: "NotImplementedError",
        message: b
    };
}

function trace(b) {
    console.log(b)
}
window.addEventListener("orientationchange", onOrientationChange);

function onOrientationChange() {
    sizeHandler()
}

function ifArrayContainsValue(b, f) {
    for (var a = 0; a < b.length; a++)
        if (b[a] === f) return !0;
    return !1
}

function getSize(b) {
    var f = b.toLowerCase(),
        a = window.document,
        c = a.documentElement;
    if (void 0 === window["inner" + b]) b = c["client" + b];
    else if (window["inner" + b] != c["client" + b]) {
        var e = a.createElement("body");
        e.id = "vpw-test-b";
        e.style.cssText = "overflow:scroll";
        var h = a.createElement("div");
        h.id = "vpw-test-d";
        h.style.cssText = "position:absolute;top:-1000px";
        h.innerHTML = "<style>@media(" + f + ":" + c["client" + b] + "px){body#vpw-test-b div#vpw-test-d{" + f + ":7px!important}}</style>";
        e.appendChild(h);
        c.insertBefore(e, a.head);
        b = 7 == h["offset" + b] ? c["client" + b] : window["inner" + b];
        c.removeChild(e)
    } else b = window["inner" + b];
    return b
}

function sizeHandler() {
    window.scrollTo(0, 1);
    if ($("#canvas")) {
        var b = navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? getIOSWindowHeight() : getSize("Height");
        var f = getSize("Width");
        _checkOrientation(f, b);
        var a = Math.min(b / CANVAS_HEIGHT, f / CANVAS_WIDTH),
            c = CANVAS_WIDTH * a;
        a *= CANVAS_HEIGHT;
        if (a < b) {
            var e = b - a;
            a += e;
            c += CANVAS_WIDTH / CANVAS_HEIGHT * e
        } else c < f && (e = f - c, c += e, a += CANVAS_HEIGHT / CANVAS_WIDTH * e);
        e = b / 2 - a / 2;
        var h = f / 2 - c / 2,
            d = CANVAS_WIDTH / c;
        if (h * d < -EDGEBOARD_X || e * d < -EDGEBOARD_Y) a = Math.min(b / (CANVAS_HEIGHT - 2 *
            EDGEBOARD_Y), f / (CANVAS_WIDTH - 2 * EDGEBOARD_X)), c = CANVAS_WIDTH * a, a *= CANVAS_HEIGHT, e = (b - a) / 2, h = (f - c) / 2, d = CANVAS_WIDTH / c;
        s_iOffsetX = -1 * h * d;
        s_iOffsetY = -1 * e * d;
        0 <= e && (s_iOffsetY = 0);
        0 <= h && (s_iOffsetX = 0);
        null !== s_oInterface && s_oInterface.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        null !== s_oMenu && s_oMenu.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        null !== s_oLevelChoose && s_oLevelChoose.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        s_bIsIphone ? (canvas = document.getElementById("canvas"), s_oStage.canvas.width = 2 * c, s_oStage.canvas.height =
            2 * a, canvas.style.width = c + "px", canvas.style.height = a + "px", s_oStage.scaleX = s_oStage.scaleY = 2 * Math.min(c / CANVAS_WIDTH, a / CANVAS_HEIGHT)) : s_bMobile ? ($("#canvas").css("width", c + "px"), $("#canvas").css("height", a + "px")) : (s_oStage.canvas.width = c, s_oStage.canvas.height = a, s_iScaleFactor = Math.min(c / CANVAS_WIDTH, a / CANVAS_HEIGHT), s_oStage.scaleX = s_oStage.scaleY = s_iScaleFactor);
        0 > e ? $("#canvas").css("top", e + "px") : $("#canvas").css("top", "0px");
        $("#canvas").css("left", h + "px");
        fullscreenHandler()
    }
}

function _checkOrientation(b, f) {
    s_bMobile && ENABLE_CHECK_ORIENTATION && (b > f ? "landscape" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"), s_oMain.stopUpdate()) : "portrait" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"),
        s_oMain.stopUpdate()))
}

function isChrome() {
    return /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor)
}

function isIOS() {
    var b = "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";");
    for (-1 !== navigator.userAgent.toLowerCase().indexOf("iphone") && (s_bIsIphone = !0); b.length;)
        if (navigator.platform === b.pop()) return !0;
    return s_bIsIphone = !1
}

function getIOSWindowHeight() {
    return document.documentElement.clientWidth / window.innerWidth * window.innerHeight
}

function getHeightOfIOSToolbars() {
    var b = (0 === window.orientation ? screen.height : screen.width) - getIOSWindowHeight();
    return 1 < b ? b : 0
}

function getMobileOperatingSystem() {
    var b = navigator.userAgent || navigator.vendor || window.opera;
    return b.match(/iPad/i) || b.match(/iPhone/i) || b.match(/iPod/i) ? "ios" : b.match(/Android/i) ? "android" : "unknown"
}

function inIframe() {
    try {
        return window.self !== window.top
    } catch (b) {
        return !0
    }
}

function stopSound(b) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[b].stop()
}

function playSound(b, f, a) {
    return !1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile ? (s_aSounds[b].play(), s_aSounds[b].volume(f), s_aSounds[b].loop(a), s_aSounds[b]) : null
}

function setVolume(b, f) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[b].volume(f)
}

function setMute(b, f) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[f].mute(b)
}

function createBitmap(b, f, a) {
    var c = new createjs.Bitmap(b),
        e = new createjs.Shape;
    f && a ? e.graphics.beginFill("#fff").drawRect(0, 0, f, a) : e.graphics.beginFill("#ff0").drawRect(0, 0, b.width, b.height);
    c.hitArea = e;
    return c
}

function createSprite(b, f, a, c, e, h) {
    b = null !== f ? new createjs.Sprite(b, f) : new createjs.Sprite(b);
    f = new createjs.Shape;
    f.graphics.beginFill("#000000").drawRect(-a, -c, e, h);
    b.hitArea = f;
    return b
}

function randomFloatBetween(b, f, a) {
    "undefined" === typeof a && (a = 2);
    return parseFloat(Math.min(b + Math.random() * (f - b), f).toFixed(a))
}

function shuffle(b) {
    for (var f = b.length, a, c; 0 !== f;) c = Math.floor(Math.random() * f), --f, a = b[f], b[f] = b[c], b[c] = a;
    return b
}

function easeLinear(b, f, a, c) {
    return a * b / c + f
}

function easeInQuad(b, f, a, c) {
    return a * (b /= c) * b + f
}

function easeInSine(b, f, a, c) {
    return -a * Math.cos(b / c * (Math.PI / 2)) + a + f
}

function easeInCubic(b, f, a, c) {
    return a * (b /= c) * b * b + f
}

function getTrajectoryPoint(b, f) {
    var a = new createjs.Point,
        c = (1 - b) * (1 - b),
        e = b * b;
    a.x = c * f.start.x + 2 * (1 - b) * b * f.traj.x + e * f.end.x;
    a.y = c * f.start.y + 2 * (1 - b) * b * f.traj.y + e * f.end.y;
    return a
}

function formatTime(b) {
    b /= 1E3;
    var f = Math.floor(b / 60);
    b = parseFloat(b - 60 * f).toFixed(0);
    var a = "";
    a = 10 > f ? a + ("0" + f + ":") : a + (f + ":");
    return 10 > b ? a + ("0" + b) : a + b
}

function degreesToRadians(b) {
    return b * Math.PI / 180
}

function checkRectCollision(b, f) {
    var a = getBounds(b, .9);
    var c = getBounds(f, .98);
    return calculateIntersection(a, c)
}

function calculateIntersection(b, f) {
    var a, c, e, h;
    var d = b.x + (a = b.width / 2);
    var g = b.y + (c = b.height / 2);
    var k = f.x + (e = f.width / 2);
    var n = f.y + (h = f.height / 2);
    d = Math.abs(d - k) - (a + e);
    g = Math.abs(g - n) - (c + h);
    return 0 > d && 0 > g ? (d = Math.min(Math.min(b.width, f.width), -d), g = Math.min(Math.min(b.height, f.height), -g), {
        x: Math.max(b.x, f.x),
        y: Math.max(b.y, f.y),
        width: d,
        height: g,
        rect1: b,
        rect2: f
    }) : null
}

function getBounds(b, f) {
    var a = {
        x: Infinity,
        y: Infinity,
        width: 0,
        height: 0
    };
    if (b instanceof createjs.Container) {
        a.x2 = -Infinity;
        a.y2 = -Infinity;
        var c = b.children,
            e = c.length,
            h;
        for (h = 0; h < e; h++) {
            var d = getBounds(c[h], 1);
            d.x < a.x && (a.x = d.x);
            d.y < a.y && (a.y = d.y);
            d.x + d.width > a.x2 && (a.x2 = d.x + d.width);
            d.y + d.height > a.y2 && (a.y2 = d.y + d.height)
        }
        Infinity == a.x && (a.x = 0);
        Infinity == a.y && (a.y = 0);
        Infinity == a.x2 && (a.x2 = 0);
        Infinity == a.y2 && (a.y2 = 0);
        a.width = a.x2 - a.x;
        a.height = a.y2 - a.y;
        delete a.x2;
        delete a.y2
    } else {
        if (b instanceof createjs.Bitmap) {
            e =
                b.sourceRect || b.image;
            h = e.width * f;
            var g = e.height * f
        } else if (b instanceof createjs.Sprite)
            if (b.spriteSheet._frames && b.spriteSheet._frames[b.currentFrame] && b.spriteSheet._frames[b.currentFrame].image) {
                e = b.spriteSheet.getFrame(b.currentFrame);
                h = e.rect.width;
                g = e.rect.height;
                c = e.regX;
                var k = e.regY
            } else a.x = b.x || 0, a.y = b.y || 0;
        else a.x = b.x || 0, a.y = b.y || 0;
        c = c || 0;
        h = h || 0;
        k = k || 0;
        g = g || 0;
        a.regX = c;
        a.regY = k;
        e = b.localToGlobal(0 - c, 0 - k);
        d = b.localToGlobal(h - c, g - k);
        h = b.localToGlobal(h - c, 0 - k);
        c = b.localToGlobal(0 - c, g - k);
        a.x =
            Math.min(Math.min(Math.min(e.x, d.x), h.x), c.x);
        a.y = Math.min(Math.min(Math.min(e.y, d.y), h.y), c.y);
        a.width = Math.max(Math.max(Math.max(e.x, d.x), h.x), c.x) - a.x;
        a.height = Math.max(Math.max(Math.max(e.y, d.y), h.y), c.y) - a.y
    }
    return a
}

function NoClickDelay(b) {
    this.element = b;
    window.Touch && this.element.addEventListener("touchstart", this, !1)
}
NoClickDelay.prototype = {
    handleEvent: function(b) {
        switch (b.type) {
            case "touchstart":
                this.onTouchStart(b);
                break;
            case "touchmove":
                this.onTouchMove(b);
                break;
            case "touchend":
                this.onTouchEnd(b)
        }
    },
    onTouchStart: function(b) {
        b.preventDefault();
        this.moved = !1;
        this.element.addEventListener("touchmove", this, !1);
        this.element.addEventListener("touchend", this, !1)
    },
    onTouchMove: function(b) {
        this.moved = !0
    },
    onTouchEnd: function(b) {
        this.element.removeEventListener("touchmove", this, !1);
        this.element.removeEventListener("touchend",
            this, !1);
        if (!this.moved) {
            b = document.elementFromPoint(b.changedTouches[0].clientX, b.changedTouches[0].clientY);
            3 == b.nodeType && (b = b.parentNode);
            var f = document.createEvent("MouseEvents");
            f.initEvent("click", !0, !0);
            b.dispatchEvent(f)
        }
    }
};
(function() {
    function b(b) {
        var a = {
            focus: "visible",
            focusin: "visible",
            pageshow: "visible",
            blur: "hidden",
            focusout: "hidden",
            pagehide: "hidden"
        };
        b = b || window.event;
        b.type in a ? document.body.className = a[b.type] : (document.body.className = this[f] ? "hidden" : "visible", "hidden" === document.body.className ? s_oMain.stopUpdate() : s_oMain.startUpdate())
    }
    var f = "hidden";
    f in document ? document.addEventListener("visibilitychange", b) : (f = "mozHidden") in document ? document.addEventListener("mozvisibilitychange", b) : (f = "webkitHidden") in
        document ? document.addEventListener("webkitvisibilitychange", b) : (f = "msHidden") in document ? document.addEventListener("msvisibilitychange", b) : "onfocusin" in document ? document.onfocusin = document.onfocusout = b : window.onpageshow = window.onpagehide = window.onfocus = window.onblur = b
})();

function ctlArcadeResume() {
    null !== s_oMain && s_oMain.startUpdate()
}

function ctlArcadePause() {
    null !== s_oMain && s_oMain.stopUpdate()
}

function getParamValue(b) {
    for (var f = window.location.search.substring(1).split("&"), a = 0; a < f.length; a++) {
        var c = f[a].split("=");
        if (c[0] == b) return c[1]
    }
}

function saveItem(b, f) {
    s_bStorageAvailable && localStorage.setItem(b, f)
}

function getItem(b) {
    return s_bStorageAvailable ? localStorage.getItem(b) : null
}

function fullscreenHandler() {
    ENABLE_FULLSCREEN && screenfull.enabled && (s_bFullscreen = screen.height < window.innerHeight + 3 && screen.height > window.innerHeight - 3 ? !0 : !1, null !== s_oInterface && s_oInterface.resetFullscreenBut(), null !== s_oMenu && s_oMenu.resetFullscreenBut(), null !== s_oLevelChoose && s_oLevelChoose.resetFullscreenBut())
}
if (screenfull.enabled) screenfull.on("change", function() {
    s_bFullscreen = screenfull.isFullscreen;
    null !== s_oInterface && s_oInterface.resetFullscreenBut();
    null !== s_oMenu && s_oMenu.resetFullscreenBut();
    null !== s_oLevelChoose && s_oLevelChoose.resetFullscreenBut()
});

function extractHostname(b) {
    b = -1 < b.indexOf("://") ? b.split("/")[2] : b.split("/")[0];
    b = b.split(":")[0];
    return b = b.split("?")[0]
}

function extractRootDomain(b) {
    b = extractHostname(b);
    var f = b.split("."),
        a = f.length;
    2 < a && (b = f[a - 2] + "." + f[a - 1]);
    return b
}
var getClosestTop = function() {
        var b = window,
            f = !1;
        try {
            for (; b.parent.document !== b.document;)
                if (b.parent.document) b = b.parent;
                else {
                    f = !0;
                    break
                }
        } catch (a) {
            f = !0
        }
        return {
            topFrame: b,
            err: f
        }
    },
    getBestPageUrl = function(b) {
        var f = b.topFrame,
            a = "";
        if (b.err) try {
            try {
                a = window.top.location.href
            } catch (e) {
                var c = window.location.ancestorOrigins;
                a = c[c.length - 1]
            }
        } catch (e) {
            a = f.document.referrer
        } else a = f.location.href;
        return a
    },
    TOPFRAMEOBJ = getClosestTop(),
    PAGE_URL = getBestPageUrl(TOPFRAMEOBJ);

function seekAndDestroy() {
    for (var b = extractRootDomain(PAGE_URL), f = [String.fromCharCode(99, 111, 100, 101, 116, 104, 105, 115, 108, 97, 98, 46, 99, 111, 109), String.fromCharCode(101, 110, 118, 97, 116, 111, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 110, 101, 116)], a = 0; a < f.length; a++)
        if (f[a] === b) return !0;
    return !1
}

function CSpriteLibrary() {
    var b, f, a, c, e, h;
    this.init = function(d, g, k) {
        a = f = 0;
        c = d;
        e = g;
        h = k;
        b = {}
    };
    this.addSprite = function(a, g) {
        b.hasOwnProperty(a) || (b[a] = {
            szPath: g,
            oSprite: new Image
        }, f++)
    };
    this.getSprite = function(a) {
        return b.hasOwnProperty(a) ? b[a].oSprite : null
    };
    this._onSpritesLoaded = function() {
        e.call(h)
    };
    this._onSpriteLoaded = function() {
        c.call(h);
        ++a == f && this._onSpritesLoaded()
    };
    this.loadSprites = function() {
        for (var a in b) b[a].oSprite.oSpriteLibrary = this, b[a].oSprite.onload = function() {
                this.oSpriteLibrary._onSpriteLoaded()
            },
            b[a].oSprite.src = b[a].szPath
    };
    this.getNumSprites = function() {
        return f
    }
}
var CANVAS_WIDTH = 1360,
    CANVAS_HEIGHT = 640,
    CANVAS_WIDTH_HALF = .5 * CANVAS_WIDTH,
    CANVAS_HEIGHT_HALF = .5 * CANVAS_HEIGHT,
    EDGEBOARD_X = 200,
    EDGEBOARD_Y = 10,
    FPS = 30,
    FPS_TIME = 1E3 / FPS,
    DISABLE_SOUND_MOBILE = !1,
    PRIMARY_FONT = "bd_cartoon_shoutregular",
    PRIMARY_FONT_COLOR = "#ffffff",
    SECONDARY_FONT_COLOR = "#000000",
    STATE_LOADING = 0,
    STATE_MENU = 1,
    STATE_HELP = 1,
    STATE_LEVEL = 2,
    STATE_GAME = 3,
    ON_MOUSE_DOWN = 0,
    ON_MOUSE_UP = 1,
    ENABLE_FULLSCREEN, ENABLE_CHECK_ORIENTATION, BOARD_SQUARES = 70,
    PROVENIENCE_TOP = 0,
    PROVENIENCE_RIGHT = 1,
    PROVENIENCE_BOTTOM =
    2,
    PROVENIENCE_LEFT = 3,
    START_POSITION_COLUMN, START_POSITION_ROW, USED_PIPE_UNDER_GOAL, USED_PIPE_ABOVE_GOAL, UNUSED_PIPE_MALUS, CHANGED_PIPE_MALUS, CHECK_LEVEL_DELAY = 3E3,
    START_TIME = [3E4, 2E4, 15E3, 15E3, 12E3, 12E3, 1E4, 1E4, 7E3, 5E3],
    LEVEL_GOAL = [5, 7, 10, 10, 12, 12, 15, 15, 20, 25],
    LEVEL_WATER_SPEED = [8, 10, 12, 15, 20, 22, 25, 30, 35, 40],
    COLUMNS_COORDS = [376, 442, 507, 573, 639, 705, 771, 837, 903, 969],
    ROWS_COORDS = [132, 198, 264, 330, 396, 462, 528],
    NEXT_COLUMN_Y = 1085,
    NEXT_COLUMN_OFFSET_Y = 24,
    BOARD_COORDS;
BOARD_COORDS = [
    [COLUMNS_COORDS[0], ROWS_COORDS[0]],
    [COLUMNS_COORDS[1], ROWS_COORDS[0]],
    [COLUMNS_COORDS[2], ROWS_COORDS[0]],
    [COLUMNS_COORDS[3], ROWS_COORDS[0]],
    [COLUMNS_COORDS[4], ROWS_COORDS[0]],
    [COLUMNS_COORDS[5], ROWS_COORDS[0]],
    [COLUMNS_COORDS[6], ROWS_COORDS[0]],
    [COLUMNS_COORDS[7], ROWS_COORDS[0]],
    [COLUMNS_COORDS[8], ROWS_COORDS[0]],
    [COLUMNS_COORDS[9], ROWS_COORDS[0]],
    [COLUMNS_COORDS[0], ROWS_COORDS[1]],
    [COLUMNS_COORDS[1], ROWS_COORDS[1]],
    [COLUMNS_COORDS[2], ROWS_COORDS[1]],
    [COLUMNS_COORDS[3], ROWS_COORDS[1]],
    [COLUMNS_COORDS[4], ROWS_COORDS[1]],
    [COLUMNS_COORDS[5], ROWS_COORDS[1]],
    [COLUMNS_COORDS[6], ROWS_COORDS[1]],
    [COLUMNS_COORDS[7], ROWS_COORDS[1]],
    [COLUMNS_COORDS[8], ROWS_COORDS[1]],
    [COLUMNS_COORDS[9], ROWS_COORDS[1]],
    [COLUMNS_COORDS[0], ROWS_COORDS[2]],
    [COLUMNS_COORDS[1], ROWS_COORDS[2]],
    [COLUMNS_COORDS[2], ROWS_COORDS[2]],
    [COLUMNS_COORDS[3], ROWS_COORDS[2]],
    [COLUMNS_COORDS[4], ROWS_COORDS[2]],
    [COLUMNS_COORDS[5], ROWS_COORDS[2]],
    [COLUMNS_COORDS[6], ROWS_COORDS[2]],
    [COLUMNS_COORDS[7], ROWS_COORDS[2]],
    [COLUMNS_COORDS[8],
        ROWS_COORDS[2]
    ],
    [COLUMNS_COORDS[9], ROWS_COORDS[2]],
    [COLUMNS_COORDS[0], ROWS_COORDS[3]],
    [COLUMNS_COORDS[1], ROWS_COORDS[3]],
    [COLUMNS_COORDS[2], ROWS_COORDS[3]],
    [COLUMNS_COORDS[3], ROWS_COORDS[3]],
    [COLUMNS_COORDS[4], ROWS_COORDS[3]],
    [COLUMNS_COORDS[5], ROWS_COORDS[3]],
    [COLUMNS_COORDS[6], ROWS_COORDS[3]],
    [COLUMNS_COORDS[7], ROWS_COORDS[3]],
    [COLUMNS_COORDS[8], ROWS_COORDS[3]],
    [COLUMNS_COORDS[9], ROWS_COORDS[3]],
    [COLUMNS_COORDS[0], ROWS_COORDS[4]],
    [COLUMNS_COORDS[1], ROWS_COORDS[4]],
    [COLUMNS_COORDS[2], ROWS_COORDS[4]],
    [COLUMNS_COORDS[3], ROWS_COORDS[4]],
    [COLUMNS_COORDS[4], ROWS_COORDS[4]],
    [COLUMNS_COORDS[5], ROWS_COORDS[4]],
    [COLUMNS_COORDS[6], ROWS_COORDS[4]],
    [COLUMNS_COORDS[7], ROWS_COORDS[4]],
    [COLUMNS_COORDS[8], ROWS_COORDS[4]],
    [COLUMNS_COORDS[9], ROWS_COORDS[4]],
    [COLUMNS_COORDS[0], ROWS_COORDS[5]],
    [COLUMNS_COORDS[1], ROWS_COORDS[5]],
    [COLUMNS_COORDS[2], ROWS_COORDS[5]],
    [COLUMNS_COORDS[3], ROWS_COORDS[5]],
    [COLUMNS_COORDS[4], ROWS_COORDS[5]],
    [COLUMNS_COORDS[5], ROWS_COORDS[5]],
    [COLUMNS_COORDS[6], ROWS_COORDS[5]],
    [COLUMNS_COORDS[7],
        ROWS_COORDS[5]
    ],
    [COLUMNS_COORDS[8], ROWS_COORDS[5]],
    [COLUMNS_COORDS[9], ROWS_COORDS[5]],
    [COLUMNS_COORDS[0], ROWS_COORDS[6]],
    [COLUMNS_COORDS[1], ROWS_COORDS[6]],
    [COLUMNS_COORDS[2], ROWS_COORDS[6]],
    [COLUMNS_COORDS[3], ROWS_COORDS[6]],
    [COLUMNS_COORDS[4], ROWS_COORDS[6]],
    [COLUMNS_COORDS[5], ROWS_COORDS[6]],
    [COLUMNS_COORDS[6], ROWS_COORDS[6]],
    [COLUMNS_COORDS[7], ROWS_COORDS[6]],
    [COLUMNS_COORDS[8], ROWS_COORDS[6]],
    [COLUMNS_COORDS[9], ROWS_COORDS[6]],
    [NEXT_COLUMN_Y, ROWS_COORDS[4] + NEXT_COLUMN_OFFSET_Y],
    [NEXT_COLUMN_Y,
        ROWS_COORDS[3] + NEXT_COLUMN_OFFSET_Y
    ],
    [NEXT_COLUMN_Y, ROWS_COORDS[2] + NEXT_COLUMN_OFFSET_Y],
    [NEXT_COLUMN_Y, ROWS_COORDS[1] + NEXT_COLUMN_OFFSET_Y],
    [NEXT_COLUMN_Y, ROWS_COORDS[0] + NEXT_COLUMN_OFFSET_Y]
];
var PIPE_EMPTY = [0, 0, !1, !1, !1, !1],
    PIPE_HORIZONTAL1 = [1, 90, !0, !1, !0, !1],
    PIPE_HORIZONTAL2 = [1, 0, !1, !0, !1, !0],
    PIPE_ANGLE1 = [2, 90, !0, !0, !1, !1],
    PIPE_ANGLE2 = [2, 180, !1, !0, !0, !1],
    PIPE_ANGLE3 = [2, 270, !1, !1, !0, !0],
    PIPE_ANGLE4 = [2, 0, !0, !1, !1, !0],
    PIPE_CROSS = [3, 0, !0, !0, !0, !0],
    PIPE_START1 = [4, 90, !1, !0, !1, !1],
    PIPE_START2 = [4, 270, !1, !1, !1, !0],
    PIPE_START3 = [4, 0, !0, !1, !1, !1],
    PIPE_START4 = [4, 180, !1, !1, !0, !1],
    PIPE_BARRIER = [11, 0, !1, !1, !1, !1],
    TEXT_HELP1 = "CLICK ON THE CELL WHERE YOU WANT TO PLACE (OR RE-PLACE) THE PIECES AVAILABLE, AND BUILD THE LONGEST BEER PIPE-LINE.",
    TEXT_HELP2 = "YOUR GOAL IS TO REACH THE MINIMUM REQUIRED LENGTH. THE LONGER THE BETTER!",
    TEXT_HELP3 = "BEWARE! WHEN TIME RUNS OUT, THE BEER WILL START TO FLOW!",
    TEXT_SELECT_LEVEL = "SELECT LEVEL",
    TEXT_WIN = "YOU WON!",
    TEXT_LOSE = "YOU LOSE! TRY AGAIN?",
    TEXT_PAUSE = "PAUSE",
    TEXT_ARE_SURE = "ARE YOU SURE?",
    TEXT_SCORE = "SCORE: ",
    TEXT_TOTAL_SCORE = "TOTAL SCORE: ",
    TEXT_LEVEL = "LEVEL",
    TEXT_PTS = "PTS",
    TEXT_RECORD_LENGTH_1 = "CIRCUIT RECORD:",
    TEXT_RECORD_LENGTH_2 = "PIPES",
    TEXT_PRELOADER_CONTINUE = "START",
    TEXT_CREDITS_DEVELOPED =
    "Developed by",
    TEXT_LINK = "www.codethislab.com",
    TEXT_ERR_LS = "YOUR WEB BROWSER DOES NOT SUPPORT LOCAL STORAGE. IF YOU'RE USING SAFARI, IT MAY BE RELATED TO PRIVATE BROWSING. AS A RESULT, SOME INFO MAY NOT BE SAVED OR SOME FEATURES MAY NOT BE AVAILABLE.",
    TEXT_SHARE_IMAGE = "200x200.jpg",
    TEXT_SHARE_TITLE = "Congratulations!",
    TEXT_SHARE_MSG1 = "You collected <strong>",
    TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!",
    TEXT_SHARE_SHARE1 = "My score is ",
    TEXT_SHARE_SHARE2 = " points! Can you do better?";

function CPreloader() {
    var b, f, a, c, e, h, d, g, k, n;
    this._init = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("progress_bar", "./sprites/progress_bar.png");
        s_oSpriteLibrary.addSprite("200x200", "./sprites/200x200.jpg");
        s_oSpriteLibrary.addSprite("but_start", "./sprites/but_start.png");
        s_oSpriteLibrary.loadSprites();
        n = new createjs.Container;
        s_oStage.addChild(n)
    };
    this.unload = function() {
        n.removeAllChildren()
    };
    this._onImagesLoaded = function() {};
    this._onAllImagesLoaded =
        function() {
            this.attachSprites();
            s_oMain.preloaderReady()
        };
    this.attachSprites = function() {
        var m = new createjs.Shape;
        m.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        n.addChild(m);
        m = s_oSpriteLibrary.getSprite("200x200");
        d = createBitmap(m);
        d.regX = .5 * m.width;
        d.regY = .5 * m.height;
        d.x = CANVAS_WIDTH_HALF;
        d.y = CANVAS_HEIGHT_HALF - 180;
        n.addChild(d);
        g = new createjs.Shape;
        g.graphics.beginFill("rgba(0,0,0,0.01)").drawRoundRect(d.x - 100, d.y - 100, 200, 200, 10);
        n.addChild(g);
        d.mask = g;
        m = s_oSpriteLibrary.getSprite("progress_bar");
        c = createBitmap(m);
        c.x = CANVAS_WIDTH_HALF - m.width / 2;
        c.y = CANVAS_HEIGHT_HALF + 50;
        n.addChild(c);
        b = m.width;
        f = m.height;
        e = new createjs.Shape;
        e.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(c.x, c.y, 1, f);
        n.addChild(e);
        c.mask = e;
        a = new createjs.Text("", "30px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        a.x = CANVAS_WIDTH_HALF;
        a.y = CANVAS_HEIGHT_HALF + 100;
        a.textBaseline = "alphabetic";
        a.textAlign = "center";
        n.addChild(a);
        m = s_oSpriteLibrary.getSprite("but_start");
        k = CTextButton(CANVAS_WIDTH_HALF, CANVAS_HEIGHT_HALF, m, TEXT_PRELOADER_CONTINUE,
            "Arial", "#000", "bold 50", n);
        k.addEventListener(ON_MOUSE_UP, this._onButStartRelease, this);
        k.setVisible(!1);
        h = new createjs.Shape;
        h.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        n.addChild(h);
        createjs.Tween.get(h).to({
            alpha: 0
        }, 500).call(function() {
            createjs.Tween.removeTweens(h);
            n.removeChild(h)
        })
    };
    this._onButStartRelease = function() {
        s_oMain._onRemovePreloader()
    };
    this.refreshLoader = function(d) {
        a.text = d + "%";
        100 === d && (k.setVisible(!0), a.visible = !1, c.visible = !1);
        e.graphics.clear();
        d = Math.floor(d * b / 100);
        e.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(c.x, c.y, d, f)
    };
    this._init()
}

function CMain(b) {
    var f, a = 0,
        c = 0,
        e = STATE_LOADING,
        h, d;
    this.initContainer = function() {
        var a = document.getElementById("canvas");
        s_oStage = new createjs.Stage(a);
        createjs.Touch.enable(s_oStage);
        s_oStage.preventSelection = !1;
        a.opacity = .5;
        s_bMobile = jQuery.browser.mobile;
        !1 === s_bMobile && (s_oStage.enableMouseOver(20), $("body").on("contextmenu", "#canvas", function(a) {
            return !1
        }));
        s_iPrevTime = (new Date).getTime();
        createjs.Ticker.addEventListener("tick", this._update);
        createjs.Ticker.framerate = FPS;
        navigator.userAgent.match(/Windows Phone/i) &&
            (DISABLE_SOUND_MOBILE = !0);
        s_oSpriteLibrary = new CSpriteLibrary;
        seekAndDestroy() ? h = new CPreloader : window.location.href = "http://www.codethislab.com/contact-us.html";
        f = !0
    };
    this.soundLoaded = function() {
        a++;
        h.refreshLoader(Math.floor(a / c * 100))
    };
    this._initSounds = function() {
        var a = [];
        a.push({
            path: "./sounds/",
            filename: "soundtrack",
            loop: !0,
            volume: 1,
            ingamename: "soundtrack"
        });
        a.push({
            path: "./sounds/",
            filename: "character_laugh",
            loop: !1,
            volume: 1,
            ingamename: "character_laugh"
        });
        a.push({
            path: "./sounds/",
            filename: "click",
            loop: !1,
            volume: 1,
            ingamename: "click"
        });
        a.push({
            path: "./sounds/",
            filename: "game_win",
            loop: !1,
            volume: 1,
            ingamename: "game_win"
        });
        a.push({
            path: "./sounds/",
            filename: "game_over",
            loop: !1,
            volume: 1,
            ingamename: "game_over"
        });
        a.push({
            path: "./sounds/",
            filename: "gulp",
            loop: !1,
            volume: 1,
            ingamename: "gulp"
        });
        a.push({
            path: "./sounds/",
            filename: "cry",
            loop: !1,
            volume: 1,
            ingamename: "cry"
        });
        a.push({
            path: "./sounds/",
            filename: "explosion",
            loop: !1,
            volume: 1,
            ingamename: "explosion"
        });
        a.push({
            path: "./sounds/",
            filename: "place_pipe",
            loop: !1,
            volume: 1,
            ingamename: "place_pipe"
        });
        a.push({
            path: "./sounds/",
            filename: "bonus",
            loop: !1,
            volume: 1,
            ingamename: "bonus"
        });
        a.push({
            path: "./sounds/",
            filename: "water_open",
            loop: !1,
            volume: 1,
            ingamename: "water_open"
        });
        a.push({
            path: "./sounds/",
            filename: "water_movement",
            loop: !1,
            volume: 1,
            ingamename: "water_movement"
        });
        c += a.length;
        s_aSounds = [];
        for (var b = 0; b < a.length; b++) s_aSounds[a[b].ingamename] = new Howl({
            src: [a[b].path + a[b].filename + ".mp3", a[b].path + a[b].filename + ".ogg"],
            autoplay: !1,
            preload: !0,
            loop: a[b].loop,
            volume: a[b].volume,
            onload: s_oMain.soundLoaded()
        })
    };
    this._loadImages = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        for (var a = 1; 10 > a; a++) s_oSpriteLibrary.addSprite("mascotte_0" + a, "./sprites/character_animations/character_000" + a + ".png");
        for (a = 10; 100 > a; a++) s_oSpriteLibrary.addSprite("mascotte_" + a, "./sprites/character_animations/character_00" + a + ".png");
        for (a = 100; 124 > a; a++) s_oSpriteLibrary.addSprite("mascotte_" + a, "./sprites/character_animations/character_0" + a + ".png");
        s_oSpriteLibrary.addSprite("but_play", "./sprites/but_play.png");
        s_oSpriteLibrary.addSprite("but_exit", "./sprites/but_exit.png");
        s_oSpriteLibrary.addSprite("but_settings", "./sprites/but_settings.png");
        s_oSpriteLibrary.addSprite("but_help", "./sprites/but_help.png");
        s_oSpriteLibrary.addSprite("but_info", "./sprites/but_info.png");
        s_oSpriteLibrary.addSprite("but_continue", "./sprites/but_continue.png");
        s_oSpriteLibrary.addSprite("but_fullscreen", "./sprites/but_fullscreen.png");
        s_oSpriteLibrary.addSprite("but_yes",
            "./sprites/but_yes.png");
        s_oSpriteLibrary.addSprite("but_no", "./sprites/but_no.png");
        s_oSpriteLibrary.addSprite("bg_menu", "./sprites/bg_menu.jpg");
        s_oSpriteLibrary.addSprite("bg_level_select", "./sprites/bg_level_select.jpg");
        s_oSpriteLibrary.addSprite("bg_game", "./sprites/bg_game.jpg");
        s_oSpriteLibrary.addSprite("msg_box", "./sprites/msg_box.png");
        s_oSpriteLibrary.addSprite("bg_help", "./sprites/bg_help.png");
        s_oSpriteLibrary.addSprite("audio_icon", "./sprites/audio_icon.png");
        s_oSpriteLibrary.addSprite("but_home",
            "./sprites/but_home.png");
        s_oSpriteLibrary.addSprite("but_restart", "./sprites/but_restart.png");
        s_oSpriteLibrary.addSprite("logo_ctl", "./sprites/logo_ctl.png");
        s_oSpriteLibrary.addSprite("level_sprite", "./sprites/level_sprite.png");
        s_oSpriteLibrary.addSprite("time", "./sprites/time.png");
        s_oSpriteLibrary.addSprite("next_pipe", "./sprites/next_pipe.png");
        s_oSpriteLibrary.addSprite("explosion", "./sprites/explosion.png");
        s_oSpriteLibrary.addSprite("pipe0", "./sprites/pipe0.png");
        s_oSpriteLibrary.addSprite("pipe1a",
            "./sprites/pipe1a.png");
        s_oSpriteLibrary.addSprite("pipe1b", "./sprites/pipe1b.png");
        s_oSpriteLibrary.addSprite("pipe2a", "./sprites/pipe2a.png");
        s_oSpriteLibrary.addSprite("pipe2b", "./sprites/pipe2b.png");
        s_oSpriteLibrary.addSprite("pipe3a1", "./sprites/pipe3a1.png");
        s_oSpriteLibrary.addSprite("pipe3a2", "./sprites/pipe3a2.png");
        s_oSpriteLibrary.addSprite("pipe3b1", "./sprites/pipe3b1.png");
        s_oSpriteLibrary.addSprite("pipe3b2", "./sprites/pipe3b2.png");
        s_oSpriteLibrary.addSprite("pipe3c1", "./sprites/pipe3c1.png");
        s_oSpriteLibrary.addSprite("pipe3c2", "./sprites/pipe3c2.png");
        s_oSpriteLibrary.addSprite("pipe3d1", "./sprites/pipe3d1.png");
        s_oSpriteLibrary.addSprite("pipe3d2", "./sprites/pipe3d2.png");
        s_oSpriteLibrary.addSprite("pipe4", "./sprites/pipe4.png");
        s_oSpriteLibrary.addSprite("pipe11", "./sprites/pipe11.png");
        s_oSpriteLibrary.addSprite("lamp", "./sprites/lamp.png");
        s_oSpriteLibrary.addSprite("arrow", "./sprites/arrow.png");
        s_oSpriteLibrary.addSprite("next_panel", "./sprites/next_panel.png");
        s_oSpriteLibrary.addSprite("splash",
            "./sprites/splash.png");
        s_oSpriteLibrary.addSprite("goal_icon", "./sprites/goal_icon.png");
        c += s_oSpriteLibrary.getNumSprites();
        s_oSpriteLibrary.loadSprites()
    };
    this._onImagesLoaded = function() {
        a++;
        h.refreshLoader(Math.floor(a / c * 100))
    };
    this._onAllImagesLoaded = function() {};
    this.onAllPreloaderImagesLoaded = function() {
        this._loadImages()
    };
    this.preloaderReady = function() {
        this._loadImages();
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || this._initSounds();
        f = !0
    };
    this._onRemovePreloader = function() {
        try {
            saveItem("ls_available",
                "ok")
        } catch (g) {
            s_bStorageAvailable = !1
        }
        h.unload();
        isIOS() || (s_oSoundTrack = playSound("soundtrack", 1, !0));
        this.gotoMenu()
    };
    this.gotoMenu = function() {
        new CMenu;
        e = STATE_MENU
    };
    this.gotoLevelChoose = function() {
        new CLevelChoose;
        e = STATE_LEVEL
    };
    this.gotoGame = function(a) {
        d = new CGame(a);
        e = STATE_GAME;
        $(s_oMain).trigger("game_start")
    };
    this.gotoHelp = function() {
        new CHelpPanel;
        e = STATE_HELP
    };
    this.stopUpdate = function() {
        f = !1;
        createjs.Ticker.paused = !0;
        $("#block_game").css("display", "block");
        s_bAudioActive && Howler.mute(!0)
    };
    this.startUpdate = function() {
        s_iPrevTime = (new Date).getTime();
        f = !0;
        createjs.Ticker.paused = !1;
        $("#block_game").css("display", "none");
        s_bAudioActive && Howler.mute(!1)
    };
    this._update = function(a) {
        if (!1 !== f) {
            var b = (new Date).getTime();
            s_iTimeElaps = b - s_iPrevTime;
            s_iCntTime += s_iTimeElaps;
            s_iCntFps++;
            s_iPrevTime = b;
            1E3 <= s_iCntTime && (s_iCurFps = s_iCntFps, s_iCntTime -= 1E3, s_iCntFps = 0);
            e === STATE_GAME && d.update();
            s_oStage.update(a)
        }
    };
    s_oMain = this;
    ENABLE_FULLSCREEN = b.fullscreen;
    ENABLE_CHECK_ORIENTATION = b.check_orientation;
    USED_PIPE_UNDER_GOAL = b.used_pipe_under_goal;
    USED_PIPE_ABOVE_GOAL = b.used_pipe_above_goal;
    UNUSED_PIPE_MALUS = b.unused_pipe_malus;
    CHANGED_PIPE_MALUS = b.changed_pipe_malus;
    this.initContainer()
}
var s_bMobile, s_bAudioActive = !0,
    s_iCntTime = 0,
    s_bFullscreen = !1,
    s_iTimeElaps = 0,
    s_iPrevTime = 0,
    s_iCntFps = 0,
    s_iCurFps = 0,
    s_oPhysicsController, s_oAdsLevel = 1,
    s_oStage, s_oMain, s_oSpriteLibrary, s_oSoundTrack, s_bStorageAvailable = !0,
    s_iLevel, s_iLastLevel, s_bFirstTime, s_iTotalScore, s_iLongestCircuit;

function CToggle(b, f, a, c) {
    var e, h, d, g = [],
        k, n = 1;
    this._init = function(a, b, c, f) {
        h = [];
        d = [];
        var g = new createjs.SpriteSheet({
            images: [c],
            frames: {
                width: c.width / 2,
                height: c.height,
                regX: c.width / 2 / 2,
                regY: c.height / 2
            },
            animations: {
                state_true: [0],
                state_false: [1]
            }
        });
        e = f;
        k = createSprite(g, "state_" + e, c.width / 2 / 2, c.height / 2, c.width / 2, c.height);
        k.x = a;
        k.y = b;
        k.stop();
        s_bMobile || (k.cursor = "pointer");
        s_oStage.addChild(k);
        this._initListener()
    };
    this.setRotation = function(a) {
        k.rotation = a
    };
    this.unload = function() {
        k.off("mousedown",
            this.buttonDown);
        k.off("pressup", this.buttonRelease);
        s_oStage.removeChild(k)
    };
    this._initListener = function() {
        k.on("mousedown", this.buttonDown);
        k.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        h[a] = b;
        d[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, e) {
        h[a] = b;
        d[a] = c;
        g = e
    };
    this.setActive = function(a) {
        e = a;
        k.gotoAndStop("state_" + e)
    };
    this.setScale = function(a) {
        n = a;
        k.scaleX = n;
        k.scaleY = n
    };
    this.buttonRelease = function() {
        k.scaleX = n;
        k.scaleY = n;
        playSound("click", 1, !1);
        e = !e;
        k.gotoAndStop("state_" +
            e);
        h[ON_MOUSE_UP] && h[ON_MOUSE_UP].call(d[ON_MOUSE_UP], g)
    };
    this.buttonDown = function() {
        k.scaleX = n - .1;
        k.scaleY = n - .1;
        h[ON_MOUSE_DOWN] && h[ON_MOUSE_DOWN].call(d[ON_MOUSE_DOWN], g)
    };
    this.getButtonImage = function() {
        return k
    };
    this.setPosition = function(a, b) {
        k.x = a;
        k.y = b
    };
    this.setVisible = function(a) {
        k.visible = a
    };
    this._init(b, f, a, c)
}

function CGfxButton(b, f, a, c) {
    var e, h, d, g, k, n, m = !1;
    this._init = function(a, b, c) {
        e = [];
        h = [];
        g = [];
        d = createBitmap(c);
        d.x = a;
        d.y = b;
        n = k = 1;
        d.regX = c.width / 2;
        d.regY = c.height / 2;
        s_bMobile || (d.cursor = "pointer");
        l.addChild(d);
        this._initListener()
    };
    this.unload = function() {
        d.off("mousedown", this.buttonDown);
        d.off("pressup", this.buttonRelease);
        l.removeChild(d)
    };
    this.setVisible = function(a) {
        d.visible = a
    };
    this.setCursorType = function(a) {
        d.cursor = a
    };
    this._initListener = function() {
        d.on("mousedown", this.buttonDown);
        d.on("pressup",
            this.buttonRelease)
    };
    this.addEventListener = function(a, b, d) {
        e[a] = b;
        h[a] = d
    };
    this.addEventListenerWithParams = function(a, b, d, c) {
        e[a] = b;
        h[a] = d;
        g[a] = c
    };
    this.buttonRelease = function() {
        m || (d.scaleX = 0 < k ? 1 : -1, d.scaleY = 1, playSound("click", 1, !1), e[ON_MOUSE_UP] && e[ON_MOUSE_UP].call(h[ON_MOUSE_UP], g[ON_MOUSE_UP]))
    };
    this.buttonDown = function() {
        m || (d.scaleX = 0 < k ? .9 : -.9, d.scaleY = .9, e[ON_MOUSE_DOWN] && e[ON_MOUSE_DOWN].call(h[ON_MOUSE_DOWN], g[ON_MOUSE_DOWN]))
    };
    this.rotation = function(a) {
        d.rotation = a
    };
    this.getButton = function() {
        return d
    };
    this.setPosition = function(a, b) {
        d.x = a;
        d.y = b
    };
    this.setX = function(a) {
        d.x = a
    };
    this.setY = function(a) {
        d.y = a
    };
    this.getButtonImage = function() {
        return d
    };
    this.block = function(a) {
        m = a;
        d.scaleX = k;
        d.scaleY = n
    };
    this.setScaleX = function(a) {
        k = d.scaleX = a
    };
    this.getX = function() {
        return d.x
    };
    this.getY = function() {
        return d.y
    };
    this.pulseAnimation = function() {
        createjs.Tween.get(d).to({
            scaleX: .9 * k,
            scaleY: .9 * n
        }, 850, createjs.Ease.quadOut).to({
            scaleX: k,
            scaleY: n
        }, 650, createjs.Ease.quadIn).call(function() {
            q.pulseAnimation()
        })
    };
    this.trebleAnimation =
        function() {
            createjs.Tween.get(d).to({
                rotation: 5
            }, 75, createjs.Ease.quadOut).to({
                rotation: -5
            }, 140, createjs.Ease.quadIn).to({
                rotation: 0
            }, 75, createjs.Ease.quadIn).wait(750).call(function() {
                q.trebleAnimation()
            })
        };
    this.removeAllTweens = function() {
        createjs.Tween.removeTweens(d)
    };
    var l = c;
    this._init(b, f, a);
    var q = this;
    return this
}

function CTextButton(b, f, a, c, e, h, d, g) {
    var k, n, m, l, q, r;
    this._init = function(a, b, d, c, e, f, h) {
        k = [];
        n = [];
        m = [];
        e = createBitmap(d);
        var p = Math.ceil(h / 20);
        r = new createjs.Text(c, " " + h + "px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        r.textAlign = "center";
        r.textBaseline = "alphabetic";
        var v = r.getBounds();
        r.x = d.width / 2 + p;
        r.y = Math.floor(d.height / 2) + v.height / 3 + p;
        q = new createjs.Text(c, " " + h + "px " + PRIMARY_FONT, f);
        q.textAlign = "center";
        q.textBaseline = "alphabetic";
        v = q.getBounds();
        q.x = d.width / 2;
        q.y = Math.floor(d.height / 2) + v.height /
            3;
        l = new createjs.Container;
        l.x = a;
        l.y = b;
        l.regX = d.width / 2;
        l.regY = d.height / 2;
        l.addChild(e, r, q);
        g.addChild(l);
        s_bMobile || (l.cursor = "pointer");
        this._initListener()
    };
    this.unload = function() {
        l.off("mousedown");
        l.off("pressup");
        g.removeChild(l)
    };
    this.setVisible = function(a) {
        l.visible = a
    };
    this._initListener = function() {
        oParent = this;
        l.on("mousedown", this.buttonDown);
        l.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, d) {
        k[a] = b;
        n[a] = d
    };
    this.addEventListenerWithParams = function(a, b, d, c) {
        k[a] = b;
        n[a] = d;
        m[a] = c
    };
    this.buttonRelease = function() {
        l.scaleX = 1;
        l.scaleY = 1;
        playSound("click", 1, !1);
        k[ON_MOUSE_UP] && k[ON_MOUSE_UP].call(n[ON_MOUSE_UP], m[ON_MOUSE_UP])
    };
    this.buttonDown = function() {
        l.scaleX = .9;
        l.scaleY = .9;
        k[ON_MOUSE_DOWN] && k[ON_MOUSE_DOWN].call(n[ON_MOUSE_DOWN])
    };
    this.setTextPosition = function(a) {
        q.y = a;
        r.y = a + 2
    };
    this.setPosition = function(a, b) {
        l.x = a;
        l.y = b
    };
    this.setX = function(a) {
        l.x = a
    };
    this.setY = function(a) {
        l.y = a
    };
    this.getButtonImage = function() {
        return l
    };
    this.getX = function() {
        return l.x
    };
    this.getY =
        function() {
            return l.y
        };
    this._init(b, f, a, c, e, h, d);
    return this
}

function CMenu() {
    var b, f, a, c, e, h, d, g, k, n, m, l, q, r, p = null,
        v = null;
    this._init = function() {
        k = createBitmap(s_oSpriteLibrary.getSprite("bg_menu"));
        k.cache(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(k);
        var t = s_oSpriteLibrary.getSprite("but_play");
        e = CANVAS_WIDTH_HALF;
        h = CANVAS_HEIGHT - 120;
        n = new CGfxButton(e, h, t, s_oStage);
        n.addEventListener(ON_MOUSE_UP, this._onButPlayRelease, this);
        n.pulseAnimation();
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) t = s_oSpriteLibrary.getSprite("audio_icon"), d = CANVAS_WIDTH - t.height /
            2 - 20, g = t.height / 2 + 20, q = new CToggle(d, g, t, s_bAudioActive, s_oStage), q.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this);
        var w = s_oSpriteLibrary.getSprite("but_info");
        a = t.height / 2 + 20;
        c = t.height / 2 + 20;
        m = new CGfxButton(a, c, w, s_oStage);
        m.addEventListener(ON_MOUSE_UP, this._onButInfoRelease, this);
        t = window.document;
        w = t.documentElement;
        p = w.requestFullscreen || w.mozRequestFullScreen || w.webkitRequestFullScreen || w.msRequestFullscreen;
        v = t.exitFullscreen || t.mozCancelFullScreen || t.webkitExitFullscreen || t.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (p = !1);
        p && screenfull.enabled && (t = s_oSpriteLibrary.getSprite("but_fullscreen"), b = a + t.width / 2 + 10, f = c, r = new CToggle(b, f, t, s_bFullscreen, s_oStage), r.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        l = new createjs.Shape;
        l.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(l);
        createjs.Tween.get(l).to({
            alpha: 0
        }, 1E3).call(function() {
            l.visible = !1
        });
        s_bFirstTime = !0;
        s_iLastLevel = 1;
        s_iLongestCircuit = s_iTotalScore = 0;
        s_bStorageAvailable ? (t =
            getItem("pipebeer_lastlevel"), null !== t && (s_iLastLevel = Number(t), s_bFirstTime = !1), t = getItem("pipebeer_totalscore"), null !== t && (s_iTotalScore = Number(t)), t = getItem("pipebeer_longestcircuit"), null !== t && (s_iLongestCircuit = Number(t))) : new CMsgBox(TEXT_ERR_LS, s_oStage);
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.refreshButtonPos = function(k, l) {
        n.setPosition(e, h - l);
        m.setPosition(a + k, c);
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || q.setPosition(d - k, g);
        p && screenfull.enabled && r.setPosition(b + k, f)
    };
    this.unload =
        function() {
            n.unload();
            n = null;
            if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) q.unload(), q = null;
            p && screenfull.enabled && r.unload();
            s_oStage.removeAllChildren();
            createjs.Tween.removeAllTweens();
            s_oMenu = null
        };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this._onButInfoRelease = function() {
        new CCreditsPanel
    };
    this._onButPlayRelease = function() {
        this.unload();
        s_oMain.gotoLevelChoose()
    };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? v.call(window.document) : p.call(window.document.documentElement);
        sizeHandler()
    };
    this.resetFullscreenBut = function() {
        p && screenfull.enabled && r.setActive(s_bFullscreen)
    };
    s_oMenu = this;
    this._init()
}
var s_oMenu = null;

function CLevelBut(b, f, a, c, e) {
    var h, d, g, k = [],
        n = [],
        m, l, q;
    this._init = function(a, b, c, f) {
        d = [];
        g = [];
        var p = new createjs.SpriteSheet({
            images: [c],
            frames: {
                width: c.width / 2,
                height: c.height,
                regX: c.width / 2 / 2,
                regY: c.height / 2
            },
            animations: {
                state_true: [0],
                state_false: [1]
            }
        });
        h = f;
        m = createSprite(p, "state_" + h, c.width / 2 / 2, c.height / 2, c.width / 2, c.height);
        m.mouseEnabled = f;
        m.x = a;
        m.y = b;
        m.stop();
        s_bMobile || (m.cursor = "pointer");
        s_oStage.addChild(m);
        k.push(m);
        l = new createjs.Text(e, " 40px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        l.x =
            a + 5;
        l.y = b + 10;
        l.textAlign = "center";
        l.textBaseline = "alphabetic";
        l.lineWidth = 200;
        l.outline = 4;
        s_oStage.addChild(l);
        q = new createjs.Text(e, " 40px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        q.x = l.x;
        q.y = l.y;
        q.textAlign = l.textAlign;
        q.textBaseline = l.textBaseline;
        q.lineWidth = l.lineWidth;
        s_oStage.addChild(q);
        this._initListener()
    };
    this.unload = function() {
        m.off("mousedown", this.buttonDown);
        m.off("pressup", this.buttonRelease);
        s_oStage.removeChild(m)
    };
    this._initListener = function() {
        m.on("mousedown", this.buttonDown);
        m.on("pressup",
            this.buttonRelease)
    };
    this.viewBut = function(a) {
        s_oStage.addChild(a)
    };
    this.addEventListener = function(a, b, c) {
        d[a] = b;
        g[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, e) {
        d[a] = b;
        g[a] = c;
        n = e
    };
    this.ifClickable = function() {
        return !0 === m.mouseEnabled ? 1 : 0
    };
    this.setActive = function(a, b) {
        h = b;
        k[a].gotoAndStop("state_" + h);
        k[a].mouseEnabled = !0
    };
    this.buttonRelease = function() {
        m.scaleX = 1;
        m.scaleY = 1;
        l.scaleX = 1;
        l.scaleY = 1;
        q.scaleX = 1;
        q.scaleY = 1;
        playSound("click", 1, !1);
        h = !h;
        m.gotoAndStop("state_" + h);
        d[ON_MOUSE_UP] && d[ON_MOUSE_UP].call(g[ON_MOUSE_UP],
            n)
    };
    this.buttonDown = function() {
        m.scaleX = .9;
        m.scaleY = .9;
        l.scaleX = .9;
        l.scaleY = .9;
        q.scaleX = .9;
        q.scaleY = .9;
        d[ON_MOUSE_DOWN] && d[ON_MOUSE_DOWN].call(g[ON_MOUSE_DOWN], n)
    };
    this.setPosition = function(a, b) {
        m.x = a;
        m.y = b
    };
    this.setVisible = function(a) {
        m.visible = a
    };
    this._init(b, f, a, c)
}

function CLevelSettings() {
    var b, f, a;
    this._init = function() {
        b = START_TIME;
        f = LEVEL_GOAL;
        a = [];
        a.length = b.length
    };
    this.getLevelGoal = function(a) {
        return f[a]
    };
    this.getStartTime = function(a) {
        return b[a]
    };
    this.getNumLevels = function() {
        return a.length
    };
    this._init();
    s_oLevelSettings = this
}
var s_oLevelSettings;

function CLevelChoose() {
    var b, f, a, c, e, h, d = [],
        g, k, n, m, l, q, r, p, v, t = null,
        w = null;
    this._init = function() {
        l = createBitmap(s_oSpriteLibrary.getSprite("bg_level_select"));
        s_oStage.addChild(l);
        m = new CLevelSettings;
        g = m.getNumLevels();
        var u = s_oSpriteLibrary.getSprite("bg_help");
        l = createBitmap(u);
        l.regX = u.width / 2 + 20;
        l.regY = u.height / 2;
        l.x = CANVAS_WIDTH_HALF;
        l.y = CANVAS_HEIGHT_HALF;
        s_oStage.addChild(l);
        l.cache(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        k = new createjs.Text(TEXT_SELECT_LEVEL, " 40px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        k.x = CANVAS_WIDTH_HALF - 20;
        k.y = 260;
        k.textAlign = "center";
        k.textBaseline = "alphabetic";
        k.lineWidth = 1E3;
        k.outline = 4;
        s_oStage.addChild(k);
        n = new createjs.Text(TEXT_SELECT_LEVEL, " 40px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        n.x = k.x;
        n.y = k.y;
        n.textAlign = "center";
        n.textBaseline = "alphabetic";
        n.lineWidth = 1E3;
        s_oStage.addChild(n);
        u = CANVAS_WIDTH_HALF - 20;
        for (var x = 0, z = 50, y = 0; y < g; y++, x += 100) 400 < x && (x = 0, z += 100), y < s_iLastLevel ? d.push(new CLevelBut(u - 200 + x, 270 + z, s_oSpriteLibrary.getSprite("level_sprite"), !0, y + 1)) : d.push(new CLevelBut(u -
            200 + x, 270 + z, s_oSpriteLibrary.getSprite("level_sprite"), !1, y + 1)), d[y].addEventListenerWithParams(ON_MOUSE_UP, this._onClick, this, y), s_bFirstTime = !0;
        u = s_oSpriteLibrary.getSprite("but_exit");
        e = CANVAS_WIDTH - u.height / 2 - 20;
        h = u.height / 2 + 20;
        r = new CGfxButton(e, h, u, s_oStage);
        r.addEventListener(ON_MOUSE_UP, this._onExit, this);
        a = CANVAS_WIDTH - u.width - 65;
        c = u.height / 2 + 20;
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) u = s_oSpriteLibrary.getSprite("audio_icon"), p = new CToggle(a, c, u, s_bAudioActive), p.setRotation(7), p.addEventListener(ON_MOUSE_UP,
            this._onAudioToggle, this);
        u = window.document;
        x = u.documentElement;
        t = x.requestFullscreen || x.mozRequestFullScreen || x.webkitRequestFullScreen || x.msRequestFullscreen;
        w = u.exitFullscreen || u.mozCancelFullScreen || u.webkitExitFullscreen || u.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (t = !1);
        t && screenfull.enabled && (u = s_oSpriteLibrary.getSprite("but_fullscreen"), b = a - u.width / 4 - 50, f = c, v = new CToggle(b, f, u, s_bFullscreen, s_oStage), v.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        this.refreshButtonPos(s_iOffsetX,
            s_iOffsetY);
        q = new createjs.Shape;
        q.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(q);
        createjs.Tween.get(q).to({
            alpha: 0
        }, 1E3).call(function() {
            q.visible = !1
        })
    };
    this.unload = function() {
        for (var a = 0; a < g; a++) d[a].unload();
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) p.unload(), p = null;
        t && screenfull.enabled && v.unload();
        s_oLevelChoose = null;
        s_oStage.removeAllChildren()
    };
    this.refreshButtonPos = function(d, g) {
        r.setPosition(e - d, g + h);
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile ||
            p.setPosition(a - d, g + c);
        t && screenfull.enabled && v.setPosition(b - d, g + f)
    };
    this._onNumModeToggle = function(a) {
        a === NUM_ACTIVE ? ((void 0).setActive(!1), (void 0).setActive(!0)) : ((void 0).setActive(!0), (void 0).setActive(!1))
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this._onClick = function(a) {
        playSound("click", 1, !1);
        d[a].ifClickable() && (s_oLevelChoose.unload(), s_oMain.gotoGame(a))
    };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? w.call(window.document) : t.call(window.document.documentElement);
        sizeHandler()
    };
    this.resetFullscreenBut = function() {
        t && screenfull.enabled && v.setActive(s_bFullscreen)
    };
    this._onExit = function() {
        s_oLevelChoose.unload();
        playSound("click", 1, !1);
        s_oMain.gotoMenu();
        $(s_oMain).trigger("end_level");
        $(s_oMain).trigger("show_interlevel_ad");
        $(s_oMain).trigger("end_session")
    };
    s_oLevelChoose = this;
    this._init()
}
var s_oLevelChoose = null;

function CGame(b) {
    var f, a, c, e, h, d, g, k, n, m, l, q, r, p, v, t, w, u, x, z, y, K, B, A;
    this._init = function() {
        this.resetVariables();
        $(s_oMain).trigger("start_level", a + 1);
        var b = s_oSpriteLibrary.getSprite("bg_game");
        K = createBitmap(b);
        K.cache(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(K);
        this.initLamps();
        this.initNextPanel();
        u = new CMascotte;
        r = new createjs.Container;
        s_oStage.addChild(t, r, w);
        p = new CBoard(r);
        x = new CInterface(a + 1);
        this.initStartPipe();
        this.resetLevelInformation();
        v = new createjs.Container;
        s_oStage.addChild(v);
        0 === a ? CHelpPanel() : this._onExitHelp();
        setVolume("soundtrack", .5)
    };
    this.initNextPanel = function() {
        var a = s_oSpriteLibrary.getSprite("next_panel");
        t = createBitmap(a);
        t.x = NEXT_COLUMN_Y - 62;
        t.y = 0;
        a = s_oSpriteLibrary.getSprite("next_pipe");
        w = createBitmap(a);
        w.regX = a.width / 2;
        w.regY = a.height / 2;
        w.x = NEXT_COLUMN_Y + 2;
        w.y = ROWS_COORDS[4] + NEXT_COLUMN_OFFSET_Y;
        (new createjs.Tween.get(w, {
            loop: !0
        })).to({
            scaleX: 1.2,
            scaleY: 1.2
        }, 850, createjs.Ease.quadOut).to({
            scaleX: 1,
            scaleY: 1
        }, 650, createjs.Ease.quadIn)
    };
    this.initLamps = function() {
        var a = {
            images: [s_oSpriteLibrary.getSprite("lamp")],
            frames: {
                width: 409,
                height: 388
            },
            animations: {
                idle: [0, 24, "idle"]
            },
            framerate: 30
        };
        a = new createjs.SpriteSheet(a);
        B = createSprite(a, "idle", 0, 0, 409, 388);
        B.regX = 182;
        B.regY = 89;
        B.x = 170;
        B.y = 70;
        A = createSprite(a, "idle", 0, 0, 409, 388);
        A.regX = 182;
        A.regY = 89;
        A.x = 1185;
        A.y = B.y;
        A.scaleX = -1;
        s_oStage.addChild(B, A);
        (new createjs.Tween.get(B, {
            loop: !0
        })).to({
            rotation: -3
        }, 1500, createjs.Ease.quadOut).to({
            rotation: 0
        }, 1500, createjs.Ease.quadIn).to({
            rotation: 3
        }, 1500, createjs.Ease.quadOut).to({
                rotation: 0
            },
            1500, createjs.Ease.quadIn);
        (new createjs.Tween.get(A, {
            loop: !0
        })).to({
            rotation: 3
        }, 1600, createjs.Ease.quadOut).to({
            rotation: 0
        }, 1600, createjs.Ease.quadIn).to({
            rotation: -3
        }, 1600, createjs.Ease.quadOut).to({
            rotation: 0
        }, 1600, createjs.Ease.quadIn)
    };
    this.resetStage = function() {
        u.animationIdle();
        p.unload();
        p = new CBoard(r);
        this.initStartPipe()
    };
    this.resetVariables = function() {
        a = b;
        f = s_iTotalScore;
        k = h = 0;
        y = z = null;
        q = l = m = n = !1
    };
    this.resetLevelInformation = function() {
        c = s_oLevelSettings.getStartTime(a);
        e = s_oLevelSettings.getLevelGoal(a);
        x.updateLevelGoal(0);
        x.activateButSkip(!1);
        x.refreshScore(h)
    };
    this.initStartPipe = function() {
        var a = Math.floor(4 * Math.random()),
            b = [PIPE_START1, PIPE_START2, PIPE_START3, PIPE_START4][a];
        d = [PROVENIENCE_LEFT, PROVENIENCE_RIGHT, PROVENIENCE_BOTTOM, PROVENIENCE_TOP][a];
        p.updateSquare(START_POSITION_COLUMN, START_POSITION_ROW, b);
        a = p.findSquarePosition(START_POSITION_COLUMN, START_POSITION_ROW);
        p.getSquare(a).setStartArrow()
    };
    this._unload = function() {
        n = !1;
        p.unload();
        null !== z && z.unload();
        null !== y && y.unload();
        x.unload();
        s_oStage.removeAllChildren();
        createjs.Tween.removeAllTweens();
        !1 === s_bMobile && (document.onkeydown = null, document.onkeyup = null)
    };
    this.onExit = function() {
        this._unload();
        $(s_oMain).trigger("show_interlevel_ad");
        $(s_oMain).trigger("end_session");
        setVolume("soundtrack", 1);
        s_oMain.gotoMenu()
    };
    this._onExitHelp = function() {
        n = !0
    };
    this.pause = function(a) {
        n = !a;
        q = a;
        void 0 !== g && p.getSquare(g).setPaused(a)
    };
    this.gameWin = function() {
        stopSound("soundtrack");
        n = !1;
        playSound("character_laugh", 1, !1);
        playSound("game_win",
            1, !1);
        s_iLastLevel = a + 1;
        saveItem("pipebeer_lastlevel", s_iLastLevel);
        s_iTotalScore = f += h;
        saveItem("pipebeer_totalscore", s_iTotalScore);
        k > s_iLongestCircuit && (s_iLongestCircuit = k, saveItem("pipebeer_longestcircuit", s_iLongestCircuit));
        if (null === z) {
            u.animationWin();
            z = CWinPanel(v);
            z.show(u);
            var b = z.getContainer();
            u.changeContainer(b)
        }
        setTimeout(function() {
            playSound("soundtrack", .5, !0)
        }, 3E3)
    };
    this.gameOver = function() {
        stopSound("soundtrack");
        if (null === y) {
            playSound("game_over", 1, !1);
            playSound("cry", 1, !1);
            u.animationLose();
            y = CLosePanel(v);
            y.show(u);
            var a = y.getContainer();
            u.changeContainer(a)
        }
        setTimeout(function() {
            playSound("soundtrack", .5, !0)
        }, 3E3)
    };
    this.restartGame = function() {
        $(s_oMain).trigger("restart_level", a);
        this.resetVariables();
        this.resetStage();
        this.resetLevelInformation();
        this._onExitHelp()
    };
    this.onNextLevel = function() {
        this._unload();
        $(s_oMain).trigger("end_level", a);
        s_oMain.gotoGame(a + 1);
        $(s_oMain).trigger("show_interlevel_ad")
    };
    this.getLevel = function() {
        return a
    };
    this.endLevel = function() {
        x.refreshScore(h);
        $(s_oMain).trigger("end_level", a);
        0 < e ? this.gameOver() : this.gameWin()
    };
    this.checkLevel = function() {
        n = !1;
        for (var a = p.getArray(), b = 0; b < a.length; b++) {
            var d = a[b],
                c = d.getInfoArray();
            !1 === d.isWatered() && 0 < c[0] && 4 > c[0] && (d.startExplode(UNUSED_PIPE_MALUS), s_oGame.subtractPoints(UNUSED_PIPE_MALUS))
        }
        this.endLevel()
    };
    this.setClickBlocked = function(a) {
        l = a
    };
    this.getClickBlocked = function() {
        return l
    };
    this.subtractLevelGoal = function() {
        e--;
        x.updateLevelGoal(LEVEL_GOAL[a] - e)
    };
    this.subtractPoints = function(a) {
        h -= a;
        0 > h &&
            (h = 0);
        x.refreshScore(h)
    };
    this.addPipePoints = function() {
        n && (h = 0 < e ? h + USED_PIPE_UNDER_GOAL : h + USED_PIPE_ABOVE_GOAL, k++, playSound("bonus", 1, !1), x.refreshScore(h))
    };
    this.skipToLevelEnd = function() {
        if (m)
            for (var a = p.getArray(), b = 0; b < a.length; b++) a[b].setMaxSpeed()
    };
    this.startWater = function(a, b, d) {
        m || (m = !0);
        a = p.findSquarePosition(a, b);
        b = p.getSquare(a);
        g = a;
        void 0 === b ? this.checkLevel() : (playSound("water_movement", 1, !1), b.setWatered(d))
    };
    this.isStartGame = function() {
        return n
    };
    this.checkNextSquare = function(a, b,
        d, c) {
        switch (a[0]) {
            case 2:
                switch (b) {
                    case PROVENIENCE_TOP:
                        !0 === a[3] ? this.moveRight(d, c) : !0 === a[5] && this.moveLeft(d, c);
                        break;
                    case PROVENIENCE_BOTTOM:
                        !0 === a[3] ? this.moveRight(d, c) : !0 === a[5] && this.moveLeft(d, c);
                        break;
                    case PROVENIENCE_LEFT:
                        !0 === a[2] ? this.moveUp(d, c) : !0 === a[4] && this.moveDown(d, c);
                        break;
                    case PROVENIENCE_RIGHT:
                        !0 === a[2] ? this.moveUp(d, c) : !0 === a[4] && this.moveDown(d, c)
                }
                break;
            default:
                switch (b) {
                    case PROVENIENCE_TOP:
                        this.moveDown(d, c);
                        break;
                    case PROVENIENCE_BOTTOM:
                        this.moveUp(d, c);
                        break;
                    case PROVENIENCE_LEFT:
                        this.moveRight(d,
                            c);
                        break;
                    case PROVENIENCE_RIGHT:
                        this.moveLeft(d, c)
                }
        }
    };
    this.moveUp = function(a, b) {
        var d = b - 1,
            c = s_oBoard.findSquarePosition(a, d);
        if (void 0 === c) this.checkLevel();
        else {
            c = s_oBoard.getSquare(c).getInfoArray();
            var e = PROVENIENCE_BOTTOM;
            switch (c[0]) {
                default: p.startSplash(a, d, 0);
                break;
                case 1:
                        !0 === c[2] ? this.startWater(a, d, e) : p.startSplash(a, d, 0);
                    break;
                case 2:
                        !1 === c[4] ? p.startSplash(a, d, 0) : this.startWater(a, d, e);
                    break;
                case 3:
                        this.startWater(a, d, e)
            }
        }
    };
    this.moveDown = function(a, b) {
        var d = b + 1,
            c = s_oBoard.findSquarePosition(a,
                d);
        if (void 0 === c) this.checkLevel();
        else {
            c = s_oBoard.getSquare(c).getInfoArray();
            var e = PROVENIENCE_TOP;
            switch (c[0]) {
                default: p.startSplash(a, d, 180);
                break;
                case 1:
                        !0 === c[4] ? this.startWater(a, d, e) : p.startSplash(a, d, 180);
                    break;
                case 2:
                        !1 === c[2] ? p.startSplash(a, d, 180) : this.startWater(a, d, e);
                    break;
                case 3:
                        this.startWater(a, d, e)
            }
        }
    };
    this.moveRight = function(a, b) {
        var d = a + 1,
            c = s_oBoard.findSquarePosition(d, b);
        if (void 0 === c) this.checkLevel();
        else {
            c = s_oBoard.getSquare(c).getInfoArray();
            var e = PROVENIENCE_LEFT;
            switch (c[0]) {
                default: p.startSplash(d,
                    b, 90);
                break;
                case 1:
                        !0 === c[3] ? this.startWater(d, b, e) : p.startSplash(d, b, 90);
                    break;
                case 2:
                        !1 === c[5] ? p.startSplash(d, b, 90) : this.startWater(d, b, e);
                    break;
                case 3:
                        this.startWater(d, b, e)
            }
        }
    };
    this.moveLeft = function(a, b) {
        var d = a - 1,
            c = s_oBoard.findSquarePosition(d, b);
        if (void 0 === c) this.checkLevel();
        else {
            c = s_oBoard.getSquare(c).getInfoArray();
            var e = PROVENIENCE_RIGHT;
            switch (c[0]) {
                default: p.startSplash(d, b, 270);
                break;
                case 1:
                        !0 === c[5] ? this.startWater(d, b, e) : p.startSplash(d, b, 270);
                    break;
                case 2:
                        !1 === c[3] ? p.startSplash(d,
                        b, 270) : this.startWater(d, b, e);
                    break;
                case 3:
                        this.startWater(d, b, e)
            }
        }
    };
    this.update = function() {
        !0 !== n || m || (q || (c -= s_iTimeElaps), 0 < c ? x.refreshTime(formatTime(c)) : (c = 0, playSound("water_open", 1, !1), this.startWater(START_POSITION_COLUMN, START_POSITION_ROW, d)))
    };
    s_oGame = this;
    this._init()
}
var s_oGame;

function CBoard(b) {
    var f, a, c, e = [],
        h = [];
    this._init = function() {
        c = s_oGame.getLevel();
        f = b;
        this.initSplash();
        3 > c ? (START_POSITION_COLUMN = Math.floor(2 * Math.random() + 4), START_POSITION_ROW = Math.floor(2 * Math.random() + 2)) : (START_POSITION_COLUMN = Math.floor(5 * Math.random() + 3), START_POSITION_ROW = Math.floor(4 * Math.random() + 1));
        for (var a = 0; a < ROWS_COORDS.length; a++)
            for (var g = 0; g < COLUMNS_COORDS.length; g++) {
                var k = new CPipe(PIPE_EMPTY, g, a, c);
                e.push(k)
            }
        1 < c && this.generateSpecialSquare();
        for (a = 0; 5 > a; a++) this.generateNextSquare(BOARD_COORDS[BOARD_SQUARES +
            a][0], BOARD_COORDS[BOARD_SQUARES + a][1]), h[a].setX(BOARD_SQUARES + a), h[a].setY(BOARD_SQUARES + a)
    };
    this.startSplash = function(b, c, e) {
        a.visible = !0;
        a.x = COLUMNS_COORDS[b];
        a.y = ROWS_COORDS[c];
        a.rotation = e;
        a.gotoAndPlay("idle");
        a.addEventListener("animationend", function() {
            s_oGame.checkLevel();
            (new createjs.Tween.get(a)).to({
                alpha: 0
            }, 1E3, createjs.Ease.cubicOut)
        })
    };
    this.initSplash = function() {
        var b = {
            images: [s_oSpriteLibrary.getSprite("splash")],
            frames: {
                width: 102,
                height: 82
            },
            animations: {
                idle: [0, 13, !1]
            },
            framerate: 20
        };
        b = new createjs.SpriteSheet(b);
        a = createSprite(b, "idle", 0, 0, 102, 82);
        a.regX = 51;
        a.regY = 35;
        a.visible = !1;
        f.addChild(a)
    };
    this.generateSpecialSquare = function() {
        var a = Math.floor(9 * Math.random()),
            b = Math.floor(7 * Math.random());
        a === START_POSITION_COLUMN && b === START_POSITION_ROW && (a = Math.floor(9 * Math.random()), b = Math.floor(7 * Math.random()));
        this.updateSquare(a, b, PIPE_BARRIER)
    };
    this.generateNextSquare = function(a, b) {
        var d = [0, 0, 1, 1, 1, 1, 2, 2, 2, 2];
        switch (d[Math.floor(Math.random() * d.length)]) {
            case 0:
                var e = [PIPE_CROSS];
                break;
            case 1:
                e = [PIPE_ANGLE1, PIPE_ANGLE2, PIPE_ANGLE3, PIPE_ANGLE4];
                break;
            case 2:
                e = [PIPE_HORIZONTAL1, PIPE_HORIZONTAL2]
        }
        d = new CPipe(e[Math.floor(Math.random() * e.length)], a, b, c);
        h.push(d)
    };
    this.updateNextSquares = function() {
        h.splice(0, 1);
        s_oBoard.generateNextSquare(BOARD_COORDS[BOARD_SQUARES + 4][0], BOARD_COORDS[BOARD_SQUARES + 4][1]);
        for (var a = 0; 5 > a; a++) h[a].setX(BOARD_SQUARES + a), h[a].setY(BOARD_SQUARES + a);
        s_oGame.setClickBlocked(!1)
    };
    this.updateSquare = function(a, b, c) {
        a = s_oBoard.findSquarePosition(a, b);
        e[a].setInfoArray(c)
    };
    this.getNextSquare = function() {
        return h[0]
    };
    this.getContainer = function() {
        return f
    };
    this.getSquare = function(a) {
        return e[a]
    };
    this.getArray = function() {
        return e
    };
    this.findSquarePosition = function(a, b) {
        for (var c = 0; c < BOARD_COORDS.length; c++)
            if (BOARD_COORDS[c][0] === COLUMNS_COORDS[a] && BOARD_COORDS[c][1] === ROWS_COORDS[b]) return c
    };
    this.unload = function() {
        s_oBoard = null;
        f.removeAllChildren()
    };
    s_oBoard = this;
    this._init()
}
var s_oBoard;

function CPipe(b, f, a, c) {
    var e = [],
        h, d, g, k, n, m = f,
        l = a,
        q;
    this._init = function() {
        e.length = 0;
        e = b;
        q = !1;
        n = s_oBoard.findSquarePosition(m, l);
        d = s_oBoard.getContainer();
        var a = {
            images: [s_oSpriteLibrary.getSprite("pipe0"), s_oSpriteLibrary.getSprite("pipe1a"), s_oSpriteLibrary.getSprite("pipe1b"), s_oSpriteLibrary.getSprite("pipe2a"), s_oSpriteLibrary.getSprite("pipe2b"), s_oSpriteLibrary.getSprite("pipe3a1"), s_oSpriteLibrary.getSprite("pipe3a2"), s_oSpriteLibrary.getSprite("pipe3b1"), s_oSpriteLibrary.getSprite("pipe3b2"),
                s_oSpriteLibrary.getSprite("pipe3c1"), s_oSpriteLibrary.getSprite("pipe3c2"), s_oSpriteLibrary.getSprite("pipe3d1"), s_oSpriteLibrary.getSprite("pipe3d2"), s_oSpriteLibrary.getSprite("pipe4"), s_oSpriteLibrary.getSprite("pipe11")
            ],
            frames: {
                width: 66,
                height: 66
            },
            animations: {
                EMPTY_PIPE: [0, 0],
                PIPE_HORIZONTAL: [1, 1],
                PIPE_HORIZONTAL_WATER_1: [2, 60, !1],
                PIPE_HORIZONTAL_WATER_2: [62, 120, !1],
                PIPE_ANGLE: [121, 121],
                PIPE_ANGLE_WATER_1: [122, 180, !1],
                PIPE_ANGLE_WATER_2: [182, 240, !1],
                PIPE_CROSS: [241, 241],
                PIPE_CROSS_WATER_H1: [242,
                    300, !1
                ],
                PIPE_CROSS_WATER_H2: [302, 360, !1],
                PIPE_CROSS_WATER_V1: [362, 420, !1],
                PIPE_CROSS_WATER_V2: [422, 480, !1],
                PIPE_CROSS_WATER_FULL_H1: [482, 540, !1],
                PIPE_CROSS_WATER_FULL_H2: [542, 600, !1],
                PIPE_CROSS_WATER_FULL_V1: [602, 660, !1],
                PIPE_CROSS_WATER_FULL_V2: [662, 720, !1],
                PIPE_START: [721, 721],
                PIPE_START_WATER: [722, 762, !1, 30 / LEVEL_WATER_SPEED[c]],
                PIPE_BARRIER: [763, 763]
            },
            framerate: LEVEL_WATER_SPEED[c]
        };
        a = new createjs.SpriteSheet(a);
        switch (e[0]) {
            case 0:
                var f = "EMPTY_PIPE";
                break;
            case 1:
                f = "PIPE_HORIZONTAL";
                break;
            case 2:
                f =
                    "PIPE_ANGLE";
                break;
            case 3:
                f = "PIPE_CROSS";
                break;
            case 4:
                f = "PIPE_START";
                break;
            case 11:
                f = "PIPE_BARRIER"
        }
        g = createSprite(a, f, 0, 0, 66, 66);
        g.regX = g.regY = 33;
        g.x = COLUMNS_COORDS[m];
        g.y = ROWS_COORDS[l];
        g.rotation = e[1];
        g.gotoAndPlay(f);
        d.addChild(g);
        this.initExplosion();
        n < BOARD_SQUARES && (g.on("pressup", this.onClickedSquare), s_bMobile || (g.cursor = "pointer"))
    };
    this.setPaused = function(a) {
        g.paused = a
    };
    this.setStartArrow = function() {
        h = createBitmap(s_oSpriteLibrary.getSprite("arrow"));
        h.regX = 9;
        h.regY = 13;
        h.x = COLUMNS_COORDS[m];
        h.y = ROWS_COORDS[l];
        h.rotation = e[1];
        d.addChild(h);
        (new createjs.Tween.get(h, {
            loop: !0
        })).to({
            scaleX: 1.5,
            scaleY: 1.5
        }, 1E3, createjs.Ease.cubicIn).to({
            scaleX: 1,
            scaleY: 1
        }, 1E3, createjs.Ease.cubicIn)
    };
    this.initExplosion = function() {
        var a = {
            images: [s_oSpriteLibrary.getSprite("explosion")],
            frames: {
                width: 104,
                height: 104
            },
            animations: {
                idle: [4, 20, !1]
            },
            framerate: 20
        };
        a = new createjs.SpriteSheet(a);
        k = createSprite(a, "idle", 52, 52, 104, 104);
        k.regX = k.regY = 52;
        k.x = COLUMNS_COORDS[m];
        k.y = ROWS_COORDS[l];
        k.scaleX = k.scaleY = 1.2;
        k.visible = !1;
        k.addEventListener("animationend", function() {
            k.visible = !1
        });
        d.addChild(k)
    };
    this.setMaxSpeed = function() {
        g.framerate = 120
    };
    this.getInfoArray = function() {
        return e
    };
    this.setInfoArray = function(a) {
        e = a;
        g.rotation = e[1];
        r.updateStaticImage()
    };
    this.startExplode = function(a) {
        var b = 0;
        !1 === s_oGame.isStartGame() && (b = Math.floor(Math.random() * CHECK_LEVEL_DELAY));
        (new createjs.Tween.get(k)).wait(b).to({
            rotation: 0
        }, 100).call(function() {
            r.initMalus(a);
            playSound("explosion", 1, !1);
            k.visible = !0;
            k.gotoAndPlay("idle");
            !1 ===
                s_oGame.isStartGame() && (g.visible = !1)
        })
    };
    this.initMalus = function(a) {
        new CMalus(COLUMNS_COORDS[m], ROWS_COORDS[l], a)
    };
    this.onClickedSquare = function() {
        if (!(3 < e[0] || !s_oGame.isStartGame() || s_oGame.getClickBlocked() || !0 === q)) {
            s_oGame.setClickBlocked(!0);
            0 !== e[0] && (s_oGame.subtractPoints(CHANGED_PIPE_MALUS), r.startExplode(CHANGED_PIPE_MALUS));
            var a = s_oBoard.getNextSquare(),
                b = a.getInfoArray();
            a = a.getImage();
            (new createjs.Tween.get(a)).to({
                alpha: 0
            }, 800, createjs.Ease.cubicIn);
            (new createjs.Tween.get(a)).to({
                x: g.x,
                y: g.y
            }, 500, createjs.Ease.cubicIn).call(function() {
                r.setInfoArray(b);
                s_oBoard.updateNextSquares()
            });
            playSound("place_pipe", 1, !1)
        }
    };
    this.setNewGridPosition = function(a, b) {
        m = a;
        l = b
    };
    this.setX = function(a) {
        a = BOARD_COORDS[a][0];
        (new createjs.Tween.get(g)).to({
            x: a
        }, 150, createjs.Ease.cubicIn)
    };
    this.setY = function(a) {
        a = BOARD_COORDS[a][1];
        (new createjs.Tween.get(g)).to({
            y: a
        }, 150, createjs.Ease.cubicIn)
    };
    this.getImage = function() {
        return g
    };
    this.updateStaticImage = function() {
        q = !1;
        switch (e[0]) {
            case 1:
                g.gotoAndPlay("PIPE_HORIZONTAL");
                break;
            case 2:
                g.gotoAndPlay("PIPE_ANGLE");
                break;
            case 3:
                g.gotoAndPlay("PIPE_CROSS");
                break;
            case 4:
                g.gotoAndPlay("PIPE_START");
                break;
            case 11:
                g.gotoAndPlay("PIPE_BARRIER")
        }
    };
    this.updateImageHorizontal = function(a) {
        var b = "PIPE_HORIZONTAL_WATER_1";
        if (0 === e[1] && 1 === a || 0 !== e[1] && 2 === a) b = "PIPE_HORIZONTAL_WATER_2";
        r.setAnimation(b, a)
    };
    this.updateImageAngle = function(a) {
        var b = "PIPE_ANGLE_WATER_1";
        if (0 === e[1] && 0 === a || 90 === e[1] && 1 === a || 180 === e[1] && 2 === a || 270 === e[1] && 3 === a) b = "PIPE_ANGLE_WATER_2";
        r.setAnimation(b,
            a)
    };
    this.updateImageStart = function(a) {
        r.setAnimation("PIPE_START_WATER", a)
    };
    this.setAnimation = function(a, b) {
        g.gotoAndPlay(a);
        g.removeAllEventListeners();
        if (g.currentAnimation === a) g.on("animationend", function() {
            s_oGame.checkNextSquare(e, b, m, l)
        })
    };
    this.setAnimationCross = function(a, b) {
        var c = 1 === a ? ["PIPE_CROSS_WATER_V2", "PIPE_CROSS_WATER_H2", "PIPE_CROSS_WATER_V1", "PIPE_CROSS_WATER_H1"] : ["PIPE_CROSS_WATER_FULL_H2", "PIPE_CROSS_WATER_FULL_V2", "PIPE_CROSS_WATER_FULL_H1", "PIPE_CROSS_WATER_FULL_V1"];
        g.gotoAndPlay(c[b]);
        g.removeAllEventListeners();
        if (g.currentAnimation === c[b]) g.on("animationend", function() {
            s_oGame.checkNextSquare(e, b, m, l)
        })
    };
    this.setPaused = function(a) {
        g.paused = a
    };
    this.setWatered = function(a) {
        if (0 === e[0]) s_oGame.checkLevel();
        else {
            4 !== e[0] && (s_oGame.subtractLevelGoal(), s_oGame.addPipePoints(), (new createjs.Tween.get(g)).to({
                scaleX: 1.1,
                scaleY: 1.1
            }, 250, createjs.Ease.cubicIn).to({
                scaleX: 1,
                scaleY: 1
            }, 250, createjs.Ease.cubicOut));
            switch (e[0]) {
                case 1:
                    !0 === q ? s_oGame.checkLevel() : r.updateImageHorizontal(a);
                    break;
                case 2:
                    !0 === q ? s_oGame.checkLevel() : r.updateImageAngle(a);
                    break;
                case 3:
                    !1 === q ? r.setAnimationCross(1, a) : r.setAnimationCross(2, a);
                    break;
                case 4:
                    !0 === q ? s_oGame.checkLevel() : r.updateImageStart(a)
            }
            q = !0
        }
    };
    this.isWatered = function() {
        return q
    };
    this.getColumn = function() {
        return m
    };
    this.getRow = function() {
        return l
    };
    this.unload = function() {
        k = g = h = r = null
    };
    var r = this;
    this._init()
}

function CInterface(b) {
    var f, a, c, e, h, d, g, k, n, m, l, q, r = null,
        p, v, t, w, u, x, z, y, K = CANVAS_WIDTH_HALF - 310,
        B, A, M = CANVAS_WIDTH_HALF - 275,
        E, T = CANVAS_WIDTH_HALF + 230,
        N = CANVAS_WIDTH_HALF + 285,
        F, C, G, D, O = CANVAS_WIDTH_HALF + 150,
        P = CANVAS_HEIGHT - 20,
        J, H, Q = CANVAS_WIDTH_HALF - 250,
        R = CANVAS_HEIGHT - 20,
        L, I = null,
        S = null;
    this._init = function() {
        l = new createjs.Container;
        s_oStage.addChild(l);
        var p = s_oSpriteLibrary.getSprite("goal_icon");
        E = createBitmap(p);
        E.regX = p.width / 2;
        E.regY = p.height / 2;
        E.x = T;
        E.y = 40;
        l.addChild(E);
        C = new createjs.Text("0",
            " 24px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        C.x = N;
        C.y = 55;
        C.textAlign = "center";
        C.textBaseline = "alphabetic";
        C.outline = 4;
        l.addChild(C);
        F = new createjs.Text("0/" + LEVEL_GOAL[b], " 24px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        F.x = N;
        F.y = 55;
        F.textAlign = "center";
        F.textBaseline = "alphabetic";
        l.addChild(F);
        D = new createjs.Text(TEXT_SCORE + "0", " 24px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        D.x = O;
        D.y = P;
        D.textAlign = "center";
        D.textBaseline = "alphabetic";
        D.outline = 4;
        l.addChild(D);
        G = new createjs.Text(TEXT_SCORE + "0", " 24px " + PRIMARY_FONT,
            PRIMARY_FONT_COLOR);
        G.x = O;
        G.y = P;
        G.textAlign = "center";
        G.textBaseline = "alphabetic";
        l.addChild(G);
        A = new createjs.Text("00:00", " 24px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        A.x = M;
        A.y = 55;
        A.textAlign = "left";
        A.textBaseline = "alphabetic";
        A.outline = 4;
        l.addChild(A);
        B = new createjs.Text("00:00", " 24px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        B.x = M;
        B.y = 55;
        B.textAlign = "left";
        B.textBaseline = "alphabetic";
        l.addChild(B);
        p = s_oSpriteLibrary.getSprite("time");
        y = createBitmap(p);
        y.regX = p.width / 2;
        y.regY = p.height / 2;
        y.x = K;
        y.y = 40;
        l.addChild(y);
        H = new createjs.Text(TEXT_LEVEL + " " + b, " 24px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        H.x = Q;
        H.y = R;
        H.textAlign = "left";
        H.textBaseline = "alphabetic";
        H.outline = 4;
        l.addChild(H);
        J = new createjs.Text(TEXT_LEVEL + " " + b, " 24px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        J.x = Q;
        J.y = R;
        J.textAlign = "left";
        J.textBaseline = "alphabetic";
        l.addChild(J);
        q = new createjs.Container;
        l.addChild(q);
        p = s_oSpriteLibrary.getSprite("but_settings");
        f = CANVAS_WIDTH - p.width / 2 - 10;
        a = p.height / 2 + 10;
        p = s_oSpriteLibrary.getSprite("but_exit");
        n = f;
        m = a + p.height +
            10;
        w = new CGfxButton(n, m, p, l);
        w.addEventListener(ON_MOUSE_UP, this._onExit, this);
        w.setVisible(!1);
        p = s_oSpriteLibrary.getSprite("but_help");
        c = f;
        e = m + p.height + 10;
        z = new CGfxButton(c, e, p, l);
        z.addEventListener(ON_MOUSE_UP, function() {
            new CHelpPanel
        }, this);
        z.setVisible(!1);
        p = s_oSpriteLibrary.getSprite("but_continue");
        x = new CGfxButton(1090, 560, p, l);
        x.setVisible(!1);
        g = c;
        k = e + p.height / 2 + 20;
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) p = s_oSpriteLibrary.getSprite("audio_icon"), v = new CToggle(g, k, p, s_bAudioActive,
            l), v.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this), v.setVisible(!1);
        p = window.document;
        var r = p.documentElement;
        I = r.requestFullscreen || r.mozRequestFullScreen || r.webkitRequestFullScreen || r.msRequestFullscreen;
        S = p.exitFullscreen || p.mozCancelFullScreen || p.webkitExitFullscreen || p.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (I = !1);
        I && screenfull.enabled && (p = s_oSpriteLibrary.getSprite("but_fullscreen"), v ? (h = g, d = k + p.height + 10) : (h = g, d = k), u = new CToggle(h, d, p, s_bFullscreen, l), u.addEventListener(ON_MOUSE_UP,
            this._onFullscreenRelease, this), u.setVisible(!1));
        p = s_oSpriteLibrary.getSprite("but_settings");
        t = new CGfxButton(f, a, p, l);
        t.addEventListener(ON_MOUSE_UP, this.onSettings);
        L = !1;
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.onSettings = function() {
        L ? s_oInterface.closePanel() : (p = new CPause(q), L = !0, w.setX(t.getX()), w.setY(t.getY()), w.setVisible(!0), z.setX(t.getX()), z.setY(t.getY()), z.setVisible(!0), v && (v.setPosition(t.getX(), t.getY()), v.setVisible(!0), (new createjs.Tween.get(v.getButtonImage())).to({
            x: g -
                s_iOffsetX,
            y: k
        }, 300, createjs.Ease.cubicOut)), u && (u.setPosition(t.getX(), t.getY()), u.setVisible(!0), (new createjs.Tween.get(u.getButtonImage())).to({
            x: h - s_iOffsetX,
            y: d
        }, 300, createjs.Ease.cubicOut)), (new createjs.Tween.get(w.getButtonImage())).to({
            x: n - s_iOffsetX,
            y: m
        }, 300, createjs.Ease.cubicOut), (new createjs.Tween.get(z.getButtonImage())).to({
            x: c - s_iOffsetX,
            y: e
        }, 300, createjs.Ease.cubicOut))
    };
    this.updateLevelGoal = function(a) {
        C.text = a + "/" + LEVEL_GOAL[b - 1];
        F.text = a + "/" + LEVEL_GOAL[b - 1];
        a === LEVEL_GOAL[b -
            1] && (new createjs.Tween.get(E)).to({
            scaleX: 1.5,
            scaleY: 1.5
        }, 500, createjs.Ease.cubicOut).to({
            scaleX: 1,
            scaleY: 1
        }, 500, createjs.Ease.cubicIn)
    };
    this.refreshTime = function(a) {
        A.text = a;
        B.text = a;
        "00:00" === a && ((new createjs.Tween.get(y)).to({
            scaleX: 1.5,
            scaleY: 1.5
        }, 500, createjs.Ease.cubicOut).to({
            scaleX: 1,
            scaleY: 1
        }, 500, createjs.Ease.cubicIn), this.activateButSkip())
    };
    this.activateButSkip = function(a) {
        !1 === a ? x.setVisible(!1) : (x.setVisible(!0), x.addEventListener(ON_MOUSE_UP, this._onSkip, this))
    };
    this.refreshScore =
        function(a) {
            D.text = TEXT_SCORE + a;
            G.text = TEXT_SCORE + a
        };
    this.closePanel = function() {
        p.onExit();
        L = !1;
        (new createjs.Tween.get(w.getButtonImage())).to({
            x: t.getX(),
            y: t.getY()
        }, 300, createjs.Ease.cubicIn).call(function() {
            w.setVisible(!1);
            z.setVisible(!1);
            v && v.setVisible(!1);
            u && u.setVisible(!1)
        });
        (new createjs.Tween.get(z.getButtonImage())).to({
            x: t.getX(),
            y: t.getY()
        }, 300, createjs.Ease.cubicIn);
        v && (new createjs.Tween.get(v.getButtonImage())).to({
            x: t.getX(),
            y: t.getY()
        }, 300, createjs.Ease.cubicIn);
        u && (new createjs.Tween.get(u.getButtonImage())).to({
            x: t.getX(),
            y: t.getY()
        }, 300, createjs.Ease.cubicIn)
    };
    this.unloadPause = function() {};
    this.unload = function() {
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) v.unload(), v = null;
        w.unload();
        s_oStage.removeChild(l);
        I && screenfull.enabled && u.unload();
        s_oInterface = null
    };
    this.refreshButtonPos = function(b, l) {
        t.setPosition(f - b, l + a);
        w.setPosition(n - b, l + m);
        z.setPosition(c - b, l + e);
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || v.setPosition(g - b, k);
        I && screenfull.enabled && u.setPosition(h - b, d)
    };
    this._onButHelpRelease = function() {
        r = new CHelpPanel
    };
    this._onButRestartRelease = function() {
        s_oGame.restartGame();
        $(s_oMain).trigger("restart_level", 1)
    };
    this.onExitFromHelp = function() {
        r.unload()
    };
    this._onExit = function() {
        new CAreYouSurePanel(s_oGame.onExit)
    };
    this._onSkip = function() {
        s_oGame.skipToLevelEnd()
    };
    this.gameOver = function(a) {
        new CEndPanel(a)
    };
    this.showWin = function() {
        new CWinPanel
    };
    this.isAreYouSurePanel = function() {
        return null === _oAreYouSurePanel ? !1 : !0
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this._onFullscreenRelease =
        function() {
            s_bFullscreen ? S.call(window.document) : I.call(window.document.documentElement);
            sizeHandler()
        };
    this.resetFullscreenBut = function() {
        I && screenfull.enabled && u.setActive(s_bFullscreen)
    };
    this._onRestart = function() {
        s_oGame.onRestart()
    };
    s_oInterface = this;
    this._init();
    return this
}
var s_oInterface = null;

function CHelpPanel() {
    var b, f, a, c, e, h, d, g, k, n, m, l;
    this._init = function() {
        var q = CANVAS_HEIGHT_HALF - 80,
            r = CANVAS_HEIGHT_HALF + 5,
            p = CANVAS_HEIGHT_HALF + 70,
            v = s_oSpriteLibrary.getSprite("bg_help");
        n = createBitmap(v);
        n.x = CANVAS_WIDTH_HALF;
        n.y = CANVAS_HEIGHT_HALF;
        n.regX = .5 * v.width + 20;
        n.regY = .5 * v.height;
        k = new createjs.Shape;
        k.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        k.alpha = .7;
        k.on("mousedown", function() {});
        m = new createjs.Container;
        m.addChild(k, n);
        s_oStage.addChild(m);
        a = new createjs.Text(TEXT_HELP1,
            " 16px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        a.x = CANVAS_WIDTH_HALF - 20;
        a.y = q;
        a.textAlign = "center";
        a.textBaseline = "alphabetic";
        a.lineWidth = 500;
        a.lineHeight = 25;
        a.outline = 3;
        h = new createjs.Text(TEXT_HELP1, " 16px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        h.x = a.x;
        h.y = a.y;
        h.textAlign = "center";
        h.textBaseline = "alphabetic";
        h.lineHeight = 25;
        h.lineWidth = 500;
        c = new createjs.Text(TEXT_HELP2, " 16px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        c.x = CANVAS_WIDTH_HALF - 20;
        c.y = r;
        c.textAlign = "center";
        c.textBaseline = "alphabetic";
        c.lineWidth =
            500;
        c.lineHeight = 25;
        c.outline = 3;
        d = new createjs.Text(TEXT_HELP2, " 16px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        d.x = c.x;
        d.y = c.y;
        d.textAlign = c.textAlign;
        d.textBaseline = c.textBaseline;
        d.lineHeight = c.lineHeight;
        d.lineWidth = c.lineWidth;
        e = new createjs.Text(TEXT_HELP3, " 16px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        e.x = CANVAS_WIDTH_HALF - 20;
        e.y = p;
        e.textAlign = "center";
        e.textBaseline = "alphabetic";
        e.lineWidth = 500;
        e.lineHeight = 25;
        e.outline = 3;
        g = new createjs.Text(TEXT_HELP3, " 16px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        g.x =
            e.x;
        g.y = e.y;
        g.textAlign = e.textAlign;
        g.textBaseline = e.textBaseline;
        g.lineHeight = e.lineHeight;
        g.lineWidth = e.lineWidth;
        m.addChild(a, h, c, d, e, g);
        q = s_oSpriteLibrary.getSprite("but_continue");
        b = CANVAS_WIDTH_HALF - 20;
        f = CANVAS_HEIGHT_HALF + 180;
        l = new CGfxButton(b, f, q, s_oStage);
        l.addEventListener(ON_MOUSE_UP, this._onExitHelp, this);
        k = new createjs.Shape;
        k.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oStage.addChild(k);
        createjs.Tween.get(k).to({
            alpha: 0
        }, 1E3).call(function() {
            k.visible = !1
        })
    };
    this.unload = function() {
        s_oStage.removeChild(m);
        l.unload();
        var a = this;
        m.off("pressup", function() {
            a._onExitHelp()
        })
    };
    this._onExitHelp = function() {
        this.unload();
        setTimeout(s_oGame._onExitHelp, 200)
    };
    this._init()
}

function CLosePanel(b) {
    var f, a, c, e, h, d, g, k, n, m, l, q, r;
    this._init = function() {
        var p = s_oSpriteLibrary.getSprite("bg_help");
        $(s_oMain).trigger("save_score", s_iTotalScore);
        q = new createjs.Shape;
        q.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        q.alpha = .01;
        n = new createjs.Container;
        n.alpha = 1;
        n.visible = !1;
        f = new createjs.Container;
        f.y = CANVAS_HEIGHT;
        n.addChild(f);
        a = createBitmap(p);
        a.x = CANVAS_WIDTH_HALF;
        a.y = CANVAS_HEIGHT_HALF;
        a.regX = .5 * p.width + 20;
        a.regY = .5 * p.height;
        f.addChild(a);
        c = new createjs.Text(TEXT_LOSE,
            "30px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        c.x = CANVAS_WIDTH_HALF - 20;
        c.y = 240;
        c.textAlign = "center";
        c.outline = 5;
        c.textBaseline = "middle";
        f.addChild(c);
        e = new createjs.Text(TEXT_LOSE, "30px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        e.x = c.x;
        e.y = c.y;
        e.textAlign = c.textAlign;
        e.textBaseline = c.textBaseline;
        f.addChild(e);
        h = new createjs.Text(TEXT_TOTAL_SCORE + s_iTotalScore, "20px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        h.x = CANVAS_WIDTH_HALF - 20;
        h.y = 290;
        h.textAlign = "center";
        h.outline = 5;
        h.textBaseline = "middle";
        f.addChild(h);
        d =
            new createjs.Text(TEXT_TOTAL_SCORE + s_iTotalScore, "20px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        d.x = h.x;
        d.y = h.y;
        d.textAlign = h.textAlign;
        d.textBaseline = h.textBaseline;
        f.addChild(d);
        g = new createjs.Text(TEXT_RECORD_LENGTH_1 + " " + s_iLongestCircuit + " " + TEXT_RECORD_LENGTH_2, "20px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        g.x = CANVAS_WIDTH_HALF - 20;
        g.y = 330;
        g.lineWidth = 500;
        g.textAlign = "center";
        g.outline = 5;
        g.textBaseline = "middle";
        f.addChild(g);
        k = new createjs.Text(TEXT_RECORD_LENGTH_1 + " " + s_iLongestCircuit + " " + TEXT_RECORD_LENGTH_2,
            "20px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        k.x = g.x;
        k.y = g.y;
        k.lineWidth = 500;
        k.textAlign = g.textAlign;
        k.textBaseline = g.textBaseline;
        f.addChild(k);
        b.addChild(q, n, f);
        p = CANVAS_HEIGHT_HALF + 90;
        var r = s_oSpriteLibrary.getSprite("but_home");
        m = new CGfxButton(CANVAS_WIDTH_HALF - 20 - 180, p, r, f);
        m.addEventListener(ON_MOUSE_DOWN, this._onExit, this);
        r = s_oSpriteLibrary.getSprite("but_restart");
        l = new CGfxButton(CANVAS_WIDTH_HALF + 180, p, r, f);
        l.addEventListener(ON_MOUSE_DOWN, this._onRestart, this);
        l.pulseAnimation()
    };
    this.unload =
        function() {
            r.changeContainer(b);
            createjs.Tween.get(f).to({
                alpha: 0
            }, 500, createjs.Ease.cubicOut).call(function() {
                b.removeChild(q);
                b.removeChild(f)
            });
            createjs.Tween.get(n).to({
                alpha: 0
            }, 500, createjs.Ease.cubicOut).call(function() {
                b.removeChild(n);
                m.unload();
                m = null;
                q.removeAllEventListeners();
                l.unload();
                l = null
            })
        };
    this.show = function(a) {
        r = a;
        n.visible = !0;
        createjs.Tween.get(f).wait(CHECK_LEVEL_DELAY).to({
            y: 0
        }, 1E3, createjs.Ease.elasticOut);
        createjs.Tween.get(q).wait(CHECK_LEVEL_DELAY).to({
            alpha: .7
        }, 500, createjs.Ease.cubicOut).call(function() {
            $(s_oMain).trigger("show_interlevel_ad")
        });
        q.on("click", function() {})
    };
    this.getContainer = function() {
        return n
    };
    this._onRestart = function() {
        this.unload();
        createjs.Tween.get(q).to({
            alpha: 0
        }, 400, createjs.Ease.cubicOut).call(function() {
            b.removeChild(q)
        });
        s_oGame.restartGame()
    };
    this._onExit = function() {
        this.unload();
        s_oGame.onExit()
    };
    this._init();
    return this
}

function CWinPanel(b) {
    var f, a, c, e, h, d, g, k, n, m, l, q, r, p;
    this._init = function() {
        var p = s_oSpriteLibrary.getSprite("bg_help");
        $(s_oMain).trigger("share_event", s_iTotalScore);
        $(s_oMain).trigger("save_score", s_iTotalScore);
        f = s_oGame.getLevel();
        r = new createjs.Shape;
        r.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        r.alpha = .01;
        m = new createjs.Container;
        m.alpha = 1;
        m.visible = !1;
        a = new createjs.Container;
        a.y = CANVAS_HEIGHT;
        m.addChild(a);
        c = createBitmap(p);
        c.x = CANVAS_WIDTH_HALF;
        c.y = CANVAS_HEIGHT_HALF;
        c.regX = .5 * p.width + 20;
        c.regY = .5 * p.height;
        a.addChild(c);
        e = new createjs.Text(TEXT_WIN, "30px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        e.x = CANVAS_WIDTH_HALF - 20;
        e.y = 240;
        e.textAlign = "center";
        e.outline = 5;
        e.textBaseline = "middle";
        a.addChild(e);
        h = new createjs.Text(TEXT_WIN, "30px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        h.x = e.x;
        h.y = e.y;
        h.textAlign = e.textAlign;
        h.textBaseline = e.textBaseline;
        a.addChild(h);
        d = new createjs.Text(TEXT_TOTAL_SCORE + s_iTotalScore, "20px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        d.x = CANVAS_WIDTH_HALF - 20;
        d.y = 290;
        d.textAlign = "center";
        d.outline = 5;
        d.textBaseline = "middle";
        a.addChild(d);
        g = new createjs.Text(TEXT_TOTAL_SCORE + s_iTotalScore, "20px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        g.x = d.x;
        g.y = d.y;
        g.textAlign = d.textAlign;
        g.textBaseline = d.textBaseline;
        a.addChild(g);
        k = new createjs.Text(TEXT_RECORD_LENGTH_1 + " " + s_iLongestCircuit + " " + TEXT_RECORD_LENGTH_2, "20px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        k.x = CANVAS_WIDTH_HALF - 20;
        k.y = 330;
        k.lineWidth = 500;
        k.textAlign = "center";
        k.outline = 5;
        k.textBaseline = "middle";
        a.addChild(k);
        n = new createjs.Text(TEXT_RECORD_LENGTH_1 + " " + s_iLongestCircuit + " " + TEXT_RECORD_LENGTH_2, "20px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        n.x = k.x;
        n.y = k.y;
        n.lineWidth = 500;
        n.textAlign = k.textAlign;
        n.textBaseline = k.textBaseline;
        a.addChild(n);
        b.addChild(r, m, a);
        p = CANVAS_HEIGHT_HALF + 90;
        var t = s_oSpriteLibrary.getSprite("but_home");
        l = new CGfxButton(CANVAS_WIDTH_HALF - 20 - 180, p, t, a);
        l.addEventListener(ON_MOUSE_DOWN, this._onExit, this);
        t = s_oSpriteLibrary.getSprite("but_continue");
        q = new CGfxButton(CANVAS_WIDTH_HALF + 180,
            p, t, a);
        q.addEventListener(ON_MOUSE_DOWN, this._onContinue, this);
        q.pulseAnimation()
    };
    this.unload = function() {
        p.changeContainer(b);
        createjs.Tween.get(a).to({
            alpha: 0
        }, 500, createjs.Ease.cubicOut).call(function() {
            b.removeChild(a);
            b.removeChild(r)
        });
        createjs.Tween.get(m).to({
            alpha: 0
        }, 500, createjs.Ease.cubicOut).call(function() {
            b.removeChild(m);
            l.unload();
            l = null;
            r.removeAllEventListeners();
            q.unload();
            q = null
        })
    };
    this.show = function(b) {
        p = b;
        m.visible = !0;
        createjs.Tween.get(a).wait(CHECK_LEVEL_DELAY).to({
                y: 0
            }, 1E3,
            createjs.Ease.elasticOut);
        createjs.Tween.get(r).wait(CHECK_LEVEL_DELAY).to({
            alpha: .7
        }, 500, createjs.Ease.cubicOut).call(function() {
            $(s_oMain).trigger("show_interlevel_ad")
        });
        r.on("click", function() {})
    };
    this.getContainer = function() {
        return m
    };
    this._onContinue = function() {
        this.unload();
        createjs.Tween.get(r).to({
            alpha: 0
        }, 400, createjs.Ease.cubicOut).call(function() {
            b.removeChild(r)
        });
        if (9 > f) s_oGame.onNextLevel();
        else s_oMain.gotoLevelChoose()
    };
    this._onExit = function() {
        this.unload();
        s_oGame.onExit()
    };
    this._init();
    return this
}

function CMsgBox(b, f) {
    var a, c, e;
    this._init = function(b) {
        e = new createjs.Container;
        d.addChild(e);
        b = new createjs.Shape;
        b.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        b.alpha = .5;
        b.on("click", function() {});
        e.addChild(b);
        b = s_oSpriteLibrary.getSprite("msg_box");
        var f = createBitmap(b);
        f.x = CANVAS_WIDTH_HALF;
        f.y = CANVAS_HEIGHT_HALF;
        f.regX = .5 * b.width + 20;
        f.regY = .5 * b.height;
        e.addChild(f);
        a = new createjs.Text(TEXT_ERR_LS, "20px " + PRIMARY_FONT, "#fff");
        a.x = CANVAS_WIDTH_HALF;
        a.y = CANVAS_HEIGHT_HALF - 130;
        a.textAlign = "center";
        a.textBaseline = "middle";
        a.lineWidth = 450;
        e.addChild(a);
        c = new CGfxButton(CANVAS_WIDTH_HALF, CANVAS_HEIGHT_HALF + 100, s_oSpriteLibrary.getSprite("but_yes"), e);
        c.addEventListener(ON_MOUSE_UP, this._onButOk, this)
    };
    this._onButOk = function() {
        h.unload()
    };
    this.unload = function() {
        c.unload();
        d.removeChild(e)
    };
    var h = this;
    var d = f;
    this._init(b)
}

function CCreditsPanel() {
    var b, f, a, c, e, h, d, g, k, n, m, l;
    this._init = function() {
        c = new createjs.Shape;
        c.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        c.alpha = .7;
        c.on("mousedown", function() {});
        s_oStage.addChild(c);
        var q = s_oSpriteLibrary.getSprite("msg_box");
        l = new createjs.Container;
        l.y = CANVAS_HEIGHT + q.height / 2;
        s_oStage.addChild(l);
        a = createBitmap(q);
        a.regX = q.width / 2 + 20;
        a.regY = q.height / 2;
        a.x = CANVAS_WIDTH_HALF;
        a.y = CANVAS_HEIGHT_HALF;
        l.addChild(a);
        g = new createjs.Text(TEXT_CREDITS_DEVELOPED,
            "40px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        g.textAlign = "center";
        g.textBaseline = "alphabetic";
        g.x = CANVAS_WIDTH_HALF - 20;
        g.y = CANVAS_HEIGHT_HALF - 50;
        g.outline = 5;
        l.addChild(g);
        d = new createjs.Text(TEXT_CREDITS_DEVELOPED, "40px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        d.textAlign = "center";
        d.textBaseline = "alphabetic";
        d.x = g.x;
        d.y = g.y;
        l.addChild(d);
        q = s_oSpriteLibrary.getSprite("logo_ctl");
        e = createBitmap(q);
        e.regX = q.width / 2;
        e.regY = q.height / 2;
        e.x = CANVAS_WIDTH_HALF - 20;
        e.y = CANVAS_HEIGHT_HALF + 20;
        l.addChild(e);
        m = new createjs.Text(TEXT_LINK,
            "28px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        m.textAlign = "center";
        m.textBaseline = "alphabetic";
        m.x = CANVAS_WIDTH_HALF - 20;
        m.y = CANVAS_HEIGHT_HALF + 120;
        m.outline = 5;
        l.addChild(m);
        n = new createjs.Text(TEXT_LINK, "28px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        n.textAlign = "center";
        n.textBaseline = "alphabetic";
        n.x = m.x;
        n.y = m.y;
        l.addChild(n);
        k = new createjs.Shape;
        k.graphics.beginFill("#0f0f0f").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        k.alpha = .01;
        k.on("click", this._onLogoButRelease);
        l.addChild(k);
        s_bMobile || (k.cursor = "pointer");
        q = s_oSpriteLibrary.getSprite("but_exit");
        b = CANVAS_WIDTH_HALF + 220;
        f = CANVAS_HEIGHT_HALF - 155;
        h = new CGfxButton(b, f, q, l);
        h.addEventListener(ON_MOUSE_UP, this.unload, this);
        (new createjs.Tween.get(l)).to({
            y: 0
        }, 1E3, createjs.Ease.backOut)
    };
    this.unload = function() {
        k.off("click", this._onLogoButRelease);
        h.unload();
        h = null;
        s_oStage.removeChild(l, c)
    };
    this._onLogoButRelease = function() {
        window.open("http://www.codethislab.com", "_blank")
    };
    this._init()
}

function CPause(b) {
    var f, a, c, e, h;
    this.init = function(b) {
        s_oGame.pause(!0);
        e = new createjs.Container;
        h = b;
        h.addChild(e);
        f = new createjs.Shape;
        f.graphics.beginFill("#black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        f.alpha = .7;
        f.on("mousedown", this.exitPause);
        a = new createjs.Text(TEXT_PAUSE, " 40px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        a.textBaseline = "alphabetic";
        a.textAlign = "center";
        a.x = CANVAS_WIDTH_HALF;
        a.y = CANVAS_HEIGHT_HALF;
        a.outline = 5;
        c = new createjs.Text(TEXT_PAUSE, " 40px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        c.textBaseline = a.textBaseline;
        c.textAlign = a.textAlign;
        c.x = a.x;
        c.y = a.y;
        e.addChild(f, a, c);
        a.alpha = 1;
        c.alpha = 1
    };
    this.exitPause = function() {
        s_oInterface.closePanel()
    };
    this.onExit = function() {
        f.alpha = 0;
        a.alpha = 0;
        c.alpha = 0;
        s_oStage.removeChild(e);
        s_oGame.pause(!1)
    };
    this.init(b)
}

function CMalus(b, f, a) {
    var c, e, h, d, g;
    this._init = function() {
        c = b;
        e = f;
        h = a;
        d = new createjs.Text("-" + h + " " + TEXT_PTS, " 20px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        d.x = c;
        d.y = e;
        d.textAlign = "center";
        d.textBaseline = "alphabetic";
        d.outline = 4;
        g = new createjs.Text("-" + h + " " + TEXT_PTS, " 20px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        g.x = d.x;
        g.y = d.y;
        g.textAlign = d.textAlign;
        g.textBaseline = d.textBaseline;
        s_oStage.addChild(d, g);
        (new createjs.Tween.get(d)).to({
            y: 0,
            alpha: 0
        }, 800, createjs.Ease.cubicIn);
        (new createjs.Tween.get(g)).to({
            y: 0,
            alpha: 0
        }, 800, createjs.Ease.cubicIn).call(this.unload)
    };
    this.unload = function() {
        g = d = null
    };
    this._init()
}

function CMascotte() {
    var b, f;
    this._init = function() {
        b = 0;
        f = Math.floor(10 * Math.random() + 5);
        var c = {
            images: [s_oSpriteLibrary.getSprite("mascotte_01"), s_oSpriteLibrary.getSprite("mascotte_02"), s_oSpriteLibrary.getSprite("mascotte_03"), s_oSpriteLibrary.getSprite("mascotte_04"), s_oSpriteLibrary.getSprite("mascotte_05"), s_oSpriteLibrary.getSprite("mascotte_06"), s_oSpriteLibrary.getSprite("mascotte_07"), s_oSpriteLibrary.getSprite("mascotte_08"), s_oSpriteLibrary.getSprite("mascotte_09"), s_oSpriteLibrary.getSprite("mascotte_10"),
                s_oSpriteLibrary.getSprite("mascotte_11"), s_oSpriteLibrary.getSprite("mascotte_12"), s_oSpriteLibrary.getSprite("mascotte_13"), s_oSpriteLibrary.getSprite("mascotte_14"), s_oSpriteLibrary.getSprite("mascotte_15"), s_oSpriteLibrary.getSprite("mascotte_16"), s_oSpriteLibrary.getSprite("mascotte_17"), s_oSpriteLibrary.getSprite("mascotte_18"), s_oSpriteLibrary.getSprite("mascotte_19"), s_oSpriteLibrary.getSprite("mascotte_20"), s_oSpriteLibrary.getSprite("mascotte_21"), s_oSpriteLibrary.getSprite("mascotte_22"),
                s_oSpriteLibrary.getSprite("mascotte_23"), s_oSpriteLibrary.getSprite("mascotte_24"), s_oSpriteLibrary.getSprite("mascotte_25"), s_oSpriteLibrary.getSprite("mascotte_26"), s_oSpriteLibrary.getSprite("mascotte_27"), s_oSpriteLibrary.getSprite("mascotte_28"), s_oSpriteLibrary.getSprite("mascotte_29"), s_oSpriteLibrary.getSprite("mascotte_30"), s_oSpriteLibrary.getSprite("mascotte_31"), s_oSpriteLibrary.getSprite("mascotte_32"), s_oSpriteLibrary.getSprite("mascotte_33"), s_oSpriteLibrary.getSprite("mascotte_34"),
                s_oSpriteLibrary.getSprite("mascotte_35"), s_oSpriteLibrary.getSprite("mascotte_36"), s_oSpriteLibrary.getSprite("mascotte_37"), s_oSpriteLibrary.getSprite("mascotte_38"), s_oSpriteLibrary.getSprite("mascotte_39"), s_oSpriteLibrary.getSprite("mascotte_40"), s_oSpriteLibrary.getSprite("mascotte_41"), s_oSpriteLibrary.getSprite("mascotte_42"), s_oSpriteLibrary.getSprite("mascotte_43"), s_oSpriteLibrary.getSprite("mascotte_44"), s_oSpriteLibrary.getSprite("mascotte_45"), s_oSpriteLibrary.getSprite("mascotte_46"),
                s_oSpriteLibrary.getSprite("mascotte_47"), s_oSpriteLibrary.getSprite("mascotte_48"), s_oSpriteLibrary.getSprite("mascotte_49"), s_oSpriteLibrary.getSprite("mascotte_50"), s_oSpriteLibrary.getSprite("mascotte_51"), s_oSpriteLibrary.getSprite("mascotte_52"), s_oSpriteLibrary.getSprite("mascotte_53"), s_oSpriteLibrary.getSprite("mascotte_54"), s_oSpriteLibrary.getSprite("mascotte_55"), s_oSpriteLibrary.getSprite("mascotte_56"), s_oSpriteLibrary.getSprite("mascotte_57"), s_oSpriteLibrary.getSprite("mascotte_58"),
                s_oSpriteLibrary.getSprite("mascotte_59"), s_oSpriteLibrary.getSprite("mascotte_60"), s_oSpriteLibrary.getSprite("mascotte_61"), s_oSpriteLibrary.getSprite("mascotte_62"), s_oSpriteLibrary.getSprite("mascotte_63"), s_oSpriteLibrary.getSprite("mascotte_64"), s_oSpriteLibrary.getSprite("mascotte_65"), s_oSpriteLibrary.getSprite("mascotte_66"), s_oSpriteLibrary.getSprite("mascotte_67"), s_oSpriteLibrary.getSprite("mascotte_68"), s_oSpriteLibrary.getSprite("mascotte_69"), s_oSpriteLibrary.getSprite("mascotte_70"),
                s_oSpriteLibrary.getSprite("mascotte_71"), s_oSpriteLibrary.getSprite("mascotte_72"), s_oSpriteLibrary.getSprite("mascotte_73"), s_oSpriteLibrary.getSprite("mascotte_74"), s_oSpriteLibrary.getSprite("mascotte_75"), s_oSpriteLibrary.getSprite("mascotte_76"), s_oSpriteLibrary.getSprite("mascotte_77"), s_oSpriteLibrary.getSprite("mascotte_78"), s_oSpriteLibrary.getSprite("mascotte_79"), s_oSpriteLibrary.getSprite("mascotte_80"), s_oSpriteLibrary.getSprite("mascotte_81"), s_oSpriteLibrary.getSprite("mascotte_82"),
                s_oSpriteLibrary.getSprite("mascotte_83"), s_oSpriteLibrary.getSprite("mascotte_84"), s_oSpriteLibrary.getSprite("mascotte_85"), s_oSpriteLibrary.getSprite("mascotte_86"), s_oSpriteLibrary.getSprite("mascotte_87"), s_oSpriteLibrary.getSprite("mascotte_88"), s_oSpriteLibrary.getSprite("mascotte_89"), s_oSpriteLibrary.getSprite("mascotte_90"), s_oSpriteLibrary.getSprite("mascotte_91"), s_oSpriteLibrary.getSprite("mascotte_92"), s_oSpriteLibrary.getSprite("mascotte_93"), s_oSpriteLibrary.getSprite("mascotte_94"),
                s_oSpriteLibrary.getSprite("mascotte_95"), s_oSpriteLibrary.getSprite("mascotte_96"), s_oSpriteLibrary.getSprite("mascotte_97"), s_oSpriteLibrary.getSprite("mascotte_98"), s_oSpriteLibrary.getSprite("mascotte_99"), s_oSpriteLibrary.getSprite("mascotte_100"), s_oSpriteLibrary.getSprite("mascotte_101"), s_oSpriteLibrary.getSprite("mascotte_102"), s_oSpriteLibrary.getSprite("mascotte_103"), s_oSpriteLibrary.getSprite("mascotte_104"), s_oSpriteLibrary.getSprite("mascotte_105"), s_oSpriteLibrary.getSprite("mascotte_106"),
                s_oSpriteLibrary.getSprite("mascotte_107"), s_oSpriteLibrary.getSprite("mascotte_108"), s_oSpriteLibrary.getSprite("mascotte_109"), s_oSpriteLibrary.getSprite("mascotte_110"), s_oSpriteLibrary.getSprite("mascotte_111"), s_oSpriteLibrary.getSprite("mascotte_112"), s_oSpriteLibrary.getSprite("mascotte_113"), s_oSpriteLibrary.getSprite("mascotte_114"), s_oSpriteLibrary.getSprite("mascotte_115"), s_oSpriteLibrary.getSprite("mascotte_116"), s_oSpriteLibrary.getSprite("mascotte_117"), s_oSpriteLibrary.getSprite("mascotte_118"),
                s_oSpriteLibrary.getSprite("mascotte_119"), s_oSpriteLibrary.getSprite("mascotte_120"), s_oSpriteLibrary.getSprite("mascotte_121"), s_oSpriteLibrary.getSprite("mascotte_122"), s_oSpriteLibrary.getSprite("mascotte_123")
            ],
            frames: {
                width: 247,
                height: 315,
                regX: 123.5,
                regY: 315
            },
            animations: {
                idle: [0, 29, !1],
                drink: [30, 76, "idle"],
                win: [77, 92, "win"],
                lose: [94, 121, "lose"]
            },
            framerate: 20
        };
        c = new createjs.SpriteSheet(c);
        a = createSprite(c, "idle", 0, 0, 247, 315);
        a.x = 260;
        a.y = 640;
        a.addEventListener("animationend", this.changeAnimation);
        s_oStage.addChild(a)
    };
    this.changeAnimation = function() {
        "win" === a.currentAnimation ? a.gotoAndPlay("win") : "lose" === a.currentAnimation ? a.gotoAndPlay("lose") : (b++, b > f ? (b = 0, playSound("gulp", 1, !1), a.gotoAndPlay("drink")) : a.gotoAndPlay("idle"))
    };
    this.animationWin = function() {
        a.gotoAndPlay("win")
    };
    this.animationLose = function() {
        a.gotoAndPlay("lose")
    };
    this.animationIdle = function() {
        a.gotoAndPlay("idle")
    };
    this.changeContainer = function(b) {
        b.addChild(a);
        a.alpha = 1
    };
    var a = this;
    this._init()
}

function CAreYouSurePanel() {
    var b, f, a, c, e;
    this._init = function() {
        c = new createjs.Shape;
        c.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        c.alpha = .5;
        c.on("mousedown", function() {});
        s_oStage.addChild(c);
        (new createjs.Tween.get(c)).to({
            alpha: .7
        }, 500);
        e = new createjs.Container;
        s_oStage.addChild(e);
        var d = s_oSpriteLibrary.getSprite("bg_help"),
            g = createBitmap(d);
        g.regX = d.width / 2 + 20;
        g.regY = d.height / 2;
        g.x = CANVAS_WIDTH_HALF;
        g.y = CANVAS_HEIGHT_HALF;
        e.addChild(g);
        e.y = CANVAS_HEIGHT + d.height / 2;
        b =
            e.y;
        (new createjs.Tween.get(e)).to({
            y: 0
        }, 1E3, createjs.Ease.backOut);
        d = new createjs.Text(TEXT_ARE_SURE, " 50px " + PRIMARY_FONT, SECONDARY_FONT_COLOR);
        d.x = CANVAS_WIDTH_HALF - 20;
        d.y = CANVAS_HEIGHT_HALF - 50;
        d.textAlign = "center";
        d.textBaseline = "middle";
        d.outline = 5;
        e.addChild(d);
        g = new createjs.Text(TEXT_ARE_SURE, " 50px " + PRIMARY_FONT, PRIMARY_FONT_COLOR);
        g.x = d.x;
        g.y = d.y;
        g.textAlign = "center";
        g.textBaseline = "middle";
        g.lineWidth = d.lineWidth;
        e.addChild(g);
        d = CANVAS_HEIGHT_HALF + 90;
        f = new CGfxButton(CANVAS_WIDTH_HALF -
            20 + 180, d, s_oSpriteLibrary.getSprite("but_yes"), e);
        f.addEventListener(ON_MOUSE_UP, this._onButYes, this);
        a = new CGfxButton(CANVAS_WIDTH_HALF - 20 - 180, d, s_oSpriteLibrary.getSprite("but_no"), e);
        a.addEventListener(ON_MOUSE_UP, this._onButNo, this);
        s_oGame.pause(!0)
    };
    this._onButYes = function() {
        (new createjs.Tween.get(c)).to({
            alpha: 0
        }, 500);
        (new createjs.Tween.get(e)).to({
            y: b
        }, 400, createjs.Ease.backIn).call(function() {
            h.unload();
            s_oGame.onExit()
        })
    };
    this._onButNo = function() {
        s_oInterface.closePanel();
        (new createjs.Tween.get(c)).to({
                alpha: 0
            },
            500);
        (new createjs.Tween.get(e)).to({
            y: b
        }, 400, createjs.Ease.backIn).call(function() {
            h.unload()
        });
        s_oGame.pause(!1)
    };
    this.unload = function() {
        a.unload();
        f.unload();
        s_oStage.removeChild(c);
        s_oStage.removeChild(e);
        c.off("mousedown", function() {})
    };
    var h = this;
    this._init()
};