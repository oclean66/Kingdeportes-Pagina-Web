/*
 Platform.js <https://mths.be/platform>
 Copyright 2014-2018 Benjamin Tan <https://bnjmnt4n.now.sh/>
 Copyright 2011-2013 John-David Dalton
 Available under MIT license <https://mths.be/mit>
*/
(function() {
    var a = "undefined" !== typeof window && "undefined" !== typeof window.document ? window.document : {},
        b = "undefined" !== typeof module && module.exports,
        c = "undefined" !== typeof Element && "ALLOW_KEYBOARD_INPUT" in Element,
        d = function() {
            for (var c, b = ["requestFullscreen exitFullscreen fullscreenElement fullscreenEnabled fullscreenchange fullscreenerror".split(" "), "webkitRequestFullscreen webkitExitFullscreen webkitFullscreenElement webkitFullscreenEnabled webkitfullscreenchange webkitfullscreenerror".split(" "),
                    "webkitRequestFullScreen webkitCancelFullScreen webkitCurrentFullScreenElement webkitCancelFullScreen webkitfullscreenchange webkitfullscreenerror".split(" "), "mozRequestFullScreen mozCancelFullScreen mozFullScreenElement mozFullScreenEnabled mozfullscreenchange mozfullscreenerror".split(" "), "msRequestFullscreen msExitFullscreen msFullscreenElement msFullscreenEnabled MSFullscreenChange MSFullscreenError".split(" ")
                ], d = 0, e = b.length, k = {}; d < e; d++)
                if ((c = b[d]) && c[1] in a) {
                    for (d = 0; d < c.length; d++) k[b[0][d]] =
                        c[d];
                    return k
                }
            return !1
        }(),
        e = {
            change: d.fullscreenchange,
            error: d.fullscreenerror
        },
        k = {
            request: function(b) {
                var e = d.requestFullscreen;
                b = b || a.documentElement;
                if (/5\.1[.\d]* Safari/.test(navigator.userAgent)) b[e]();
                else b[e](c && Element.ALLOW_KEYBOARD_INPUT)
            },
            exit: function() {
                a[d.exitFullscreen]()
            },
            toggle: function(a) {
                this.isFullscreen ? this.exit() : this.request(a)
            },
            onchange: function(a) {
                this.on("change", a)
            },
            onerror: function(a) {
                this.on("error", a)
            },
            on: function(c, b) {
                var d = e[c];
                d && a.addEventListener(d, b, !1)
            },
            off: function(c,
                b) {
                var d = e[c];
                d && a.removeEventListener(d, b, !1)
            },
            raw: d
        };
    d ? (Object.defineProperties(k, {
        isFullscreen: {
            get: function() {
                return !!a[d.fullscreenElement]
            }
        },
        element: {
            enumerable: !0,
            get: function() {
                return a[d.fullscreenElement]
            }
        },
        enabled: {
            enumerable: !0,
            get: function() {
                return !!a[d.fullscreenEnabled]
            }
        }
    }), b ? module.exports = k : window.screenfull = k) : b ? module.exports = !1 : window.screenfull = !1
})();
(function() {
    function a(a) {
        a = String(a);
        return a.charAt(0).toUpperCase() + a.slice(1)
    }

    function b(a, c) {
        var b = -1,
            e = a ? a.length : 0;
        if ("number" == typeof e && -1 < e && e <= g)
            for (; ++b < e;) c(a[b], b, a);
        else d(a, c)
    }

    function c(c) {
        c = String(c).replace(/^ +| +$/g, "");
        return /^(?:webOS|i(?:OS|P))/.test(c) ? c : a(c)
    }

    function d(a, c) {
        for (var b in a) v.call(a, b) && c(a[b], b, a)
    }

    function e(c) {
        return null == c ? a(c) : E.call(c).slice(8, -1)
    }

    function k(a, c) {
        var b = null != a ? typeof a[c] : "number";
        return !/^(?:boolean|number|string|undefined)$/.test(b) &&
            ("object" == b ? !!a[c] : !0)
    }

    function l(a) {
        return String(a).replace(/([ -])(?!$)/g, "$1?")
    }

    function q(a, c) {
        var d = null;
        b(a, function(b, e) {
            d = c(d, b, e, a)
        });
        return d
    }

    function p(a) {
        function b(f) {
            return q(f, function(f, b) {
                var d = b.pattern || l(b);
                !f && (f = RegExp("\\b" + d + " *\\d+[.\\w_]*", "i").exec(a) || RegExp("\\b" + d + " *\\w+-[\\w]*", "i").exec(a) || RegExp("\\b" + d + "(?:; *(?:[a-z]+[_-])?[a-z]+\\d+|[^ ();-]*)", "i").exec(a)) && ((f = String(b.label && !RegExp(d, "i").test(b.label) ? b.label : f).split("/"))[1] && !/[\d.]+/.test(f[0]) && (f[0] +=
                    " " + f[1]), b = b.label || b, f = c(f[0].replace(RegExp(d, "i"), b).replace(RegExp("; *(?:" + b + "[_-])?", "i"), " ").replace(RegExp("(" + b + ")[-_.]?(\\w)", "i"), "$1 $2")));
                return f
            })
        }

        function m(f) {
            return q(f, function(f, b) {
                return f || (RegExp(b + "(?:-[\\d.]+/|(?: for [\\w-]+)?[ /-])([\\d.]+[^ ();/_-]*)", "i").exec(a) || 0)[1] || null
            })
        }
        var g = n,
            h = a && "object" == typeof a && "String" != e(a);
        h && (g = a, a = null);
        var v = g.navigator || {},
            u = v.userAgent || "";
        a || (a = u);
        var t = h ? !!v.likeChrome : /\bChrome\b/.test(a) && !/internal|\n/i.test(E.toString()),
            z = h ? "Object" : "ScriptBridgingProxyObject",
            O = h ? "Object" : "Environment",
            H = h && g.java ? "JavaPackage" : e(g.java),
            R = h ? "Object" : "RuntimeObject";
        O = (H = /\bJava/.test(H) && g.java) && e(g.environment) == O;
        var T = H ? "a" : "\u03b1",
            x = H ? "b" : "\u03b2",
            J = g.document || {},
            I = g.operamini || g.opera,
            M = r.test(M = h && I ? I["[[Class]]"] : e(I)) ? M : I = null,
            f, U = a;
        h = [];
        var V = null,
            S = a == u;
        u = S && I && "function" == typeof I.version && I.version();
        var F = function(f) {
                return q(f, function(f, b) {
                    return f || RegExp("\\b" + (b.pattern || l(b)) + "\\b", "i").exec(a) && (b.label ||
                        b)
                })
            }([{
                label: "EdgeHTML",
                pattern: "Edge"
            }, "Trident", {
                label: "WebKit",
                pattern: "AppleWebKit"
            }, "iCab", "Presto", "NetFront", "Tasman", "KHTML", "Gecko"]),
            w = function(f) {
                return q(f, function(f, b) {
                    return f || RegExp("\\b" + (b.pattern || l(b)) + "\\b", "i").exec(a) && (b.label || b)
                })
            }(["Adobe AIR", "Arora", "Avant Browser", "Breach", "Camino", "Electron", "Epiphany", "Fennec", "Flock", "Galeon", "GreenBrowser", "iCab", "Iceweasel", "K-Meleon", "Konqueror", "Lunascape", "Maxthon", {
                    label: "Microsoft Edge",
                    pattern: "Edge"
                }, "Midori", "Nook Browser",
                "PaleMoon", "PhantomJS", "Raven", "Rekonq", "RockMelt", {
                    label: "Samsung Internet",
                    pattern: "SamsungBrowser"
                }, "SeaMonkey", {
                    label: "Silk",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Sleipnir", "SlimBrowser", {
                    label: "SRWare Iron",
                    pattern: "Iron"
                }, "Sunrise", "Swiftfox", "Waterfox", "WebPositive", "Opera Mini", {
                    label: "Opera Mini",
                    pattern: "OPiOS"
                }, "Opera", {
                    label: "Opera",
                    pattern: "OPR"
                }, "Chrome", {
                    label: "Chrome Mobile",
                    pattern: "(?:CriOS|CrMo)"
                }, {
                    label: "Firefox",
                    pattern: "(?:Firefox|Minefield)"
                }, {
                    label: "Firefox for iOS",
                    pattern: "FxiOS"
                },
                {
                    label: "IE",
                    pattern: "IEMobile"
                }, {
                    label: "IE",
                    pattern: "MSIE"
                }, "Safari"
            ]),
            G = b([{
                    label: "BlackBerry",
                    pattern: "BB10"
                }, "BlackBerry", {
                    label: "Galaxy S",
                    pattern: "GT-I9000"
                }, {
                    label: "Galaxy S2",
                    pattern: "GT-I9100"
                }, {
                    label: "Galaxy S3",
                    pattern: "GT-I9300"
                }, {
                    label: "Galaxy S4",
                    pattern: "GT-I9500"
                }, {
                    label: "Galaxy S5",
                    pattern: "SM-G900"
                }, {
                    label: "Galaxy S6",
                    pattern: "SM-G920"
                }, {
                    label: "Galaxy S6 Edge",
                    pattern: "SM-G925"
                }, {
                    label: "Galaxy S7",
                    pattern: "SM-G930"
                }, {
                    label: "Galaxy S7 Edge",
                    pattern: "SM-G935"
                }, "Google TV", "Lumia", "iPad",
                "iPod", "iPhone", "Kindle", {
                    label: "Kindle Fire",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Nexus", "Nook", "PlayBook", "PlayStation Vita", "PlayStation", "TouchPad", "Transformer", {
                    label: "Wii U",
                    pattern: "WiiU"
                }, "Wii", "Xbox One", {
                    label: "Xbox 360",
                    pattern: "Xbox"
                }, "Xoom"
            ]),
            Q = function(f) {
                return q(f, function(f, b, c) {
                    return f || (b[G] || b[/^[a-z]+(?: +[a-z]+\b)*/i.exec(G)] || RegExp("\\b" + l(c) + "(?:\\b|\\w*\\d)", "i").exec(a)) && c
                })
            }({
                Apple: {
                    iPad: 1,
                    iPhone: 1,
                    iPod: 1
                },
                Archos: {},
                Amazon: {
                    Kindle: 1,
                    "Kindle Fire": 1
                },
                Asus: {
                    Transformer: 1
                },
                "Barnes & Noble": {
                    Nook: 1
                },
                BlackBerry: {
                    PlayBook: 1
                },
                Google: {
                    "Google TV": 1,
                    Nexus: 1
                },
                HP: {
                    TouchPad: 1
                },
                HTC: {},
                LG: {},
                Microsoft: {
                    Xbox: 1,
                    "Xbox One": 1
                },
                Motorola: {
                    Xoom: 1
                },
                Nintendo: {
                    "Wii U": 1,
                    Wii: 1
                },
                Nokia: {
                    Lumia: 1
                },
                Samsung: {
                    "Galaxy S": 1,
                    "Galaxy S2": 1,
                    "Galaxy S3": 1,
                    "Galaxy S4": 1
                },
                Sony: {
                    PlayStation: 1,
                    "PlayStation Vita": 1
                }
            }),
            y = function(f) {
                return q(f, function(f, b) {
                    var d = b.pattern || l(b);
                    if (!f && (f = RegExp("\\b" + d + "(?:/[\\d.]+|[ \\w.]*)", "i").exec(a))) {
                        var g = f,
                            e = b.label || b,
                            m = {
                                "10.0": "10",
                                "6.4": "10 Technical Preview",
                                "6.3": "8.1",
                                "6.2": "8",
                                "6.1": "Server 2008 R2 / 7",
                                "6.0": "Server 2008 / Vista",
                                "5.2": "Server 2003 / XP 64-bit",
                                "5.1": "XP",
                                "5.01": "2000 SP1",
                                "5.0": "2000",
                                "4.0": "NT",
                                "4.90": "ME"
                            };
                        d && e && /^Win/i.test(g) && !/^Windows Phone /i.test(g) && (m = m[/[\d.]+$/.exec(g)]) && (g = "Windows " + m);
                        g = String(g);
                        d && e && (g = g.replace(RegExp(d, "i"), e));
                        f = g = c(g.replace(/ ce$/i, " CE").replace(/\bhpw/i, "web").replace(/\bMacintosh\b/, "Mac OS").replace(/_PowerPC\b/i, " OS").replace(/\b(OS X) [^ \d]+/i, "$1").replace(/\bMac (OS X)\b/, "$1").replace(/\/(\d)/,
                            " $1").replace(/_/g, ".").replace(/(?: BePC|[ .]*fc[ \d.]+)$/i, "").replace(/\bx86\.64\b/gi, "x86_64").replace(/\b(Windows Phone) OS\b/, "$1").replace(/\b(Chrome OS \w+) [\d.]+\b/, "$1").split(" on ")[0])
                    }
                    return f
                })
            }(["Windows Phone", "Android", "CentOS", {
                    label: "Chrome OS",
                    pattern: "CrOS"
                }, "Debian", "Fedora", "FreeBSD", "Gentoo", "Haiku", "Kubuntu", "Linux Mint", "OpenBSD", "Red Hat", "SuSE", "Ubuntu", "Xubuntu", "Cygwin", "Symbian OS", "hpwOS", "webOS ", "webOS", "Tablet OS", "Tizen", "Linux", "Mac OS X", "Macintosh", "Mac",
                "Windows 98;", "Windows "
            ]);
        F && (F = [F]);
        Q && !G && (G = b([Q]));
        if (f = /\bGoogle TV\b/.exec(G)) G = f[0];
        /\bSimulator\b/i.test(a) && (G = (G ? G + " " : "") + "Simulator");
        "Opera Mini" == w && /\bOPiOS\b/.test(a) && h.push("running in Turbo/Uncompressed mode");
        "IE" == w && /\blike iPhone OS\b/.test(a) ? (f = p(a.replace(/like iPhone OS/, "")), Q = f.manufacturer, G = f.product) : /^iP/.test(G) ? (w || (w = "Safari"), y = "iOS" + ((f = / OS ([\d_]+)/i.exec(a)) ? " " + f[1].replace(/_/g, ".") : "")) : "Konqueror" != w || /buntu/i.test(y) ? Q && "Google" != Q && (/Chrome/.test(w) &&
            !/\bMobile Safari\b/i.test(a) || /\bVita\b/.test(G)) || /\bAndroid\b/.test(y) && /^Chrome/.test(w) && /\bVersion\//i.test(a) ? (w = "Android Browser", y = /\bAndroid\b/.test(y) ? y : "Android") : "Silk" == w ? (/\bMobi/i.test(a) || (y = "Android", h.unshift("desktop mode")), /Accelerated *= *true/i.test(a) && h.unshift("accelerated")) : "PaleMoon" == w && (f = /\bFirefox\/([\d.]+)\b/.exec(a)) ? h.push("identifying as Firefox " + f[1]) : "Firefox" == w && (f = /\b(Mobile|Tablet|TV)\b/i.exec(a)) ? (y || (y = "Firefox OS"), G || (G = f[1])) : !w || (f = !/\bMinefield\b/i.test(a) &&
            /\b(?:Firefox|Safari)\b/.exec(w)) ? (w && !G && /[\/,]|^[^(]+?\)/.test(a.slice(a.indexOf(f + "/") + 8)) && (w = null), (f = G || Q || y) && (G || Q || /\b(?:Android|Symbian OS|Tablet OS|webOS)\b/.test(y)) && (w = /[a-z]+(?: Hat)?/i.exec(/\bAndroid\b/.test(y) ? y : f) + " Browser")) : "Electron" == w && (f = (/\bChrome\/([\d.]+)\b/.exec(a) || 0)[1]) && h.push("Chromium " + f) : y = "Kubuntu";
        u || (u = m(["(?:Cloud9|CriOS|CrMo|Edge|FxiOS|IEMobile|Iron|Opera ?Mini|OPiOS|OPR|Raven|SamsungBrowser|Silk(?!/[\\d.]+$))", "Version", l(w), "(?:Firefox|Minefield|NetFront)"]));
        if (f = "iCab" == F && 3 < parseFloat(u) && "WebKit" || /\bOpera\b/.test(w) && (/\bOPR\b/.test(a) ? "Blink" : "Presto") || /\b(?:Midori|Nook|Safari)\b/i.test(a) && !/^(?:Trident|EdgeHTML)$/.test(F) && "WebKit" || !F && /\bMSIE\b/i.test(a) && ("Mac OS" == y ? "Tasman" : "Trident") || "WebKit" == F && /\bPlayStation\b(?! Vita\b)/i.test(w) && "NetFront") F = [f];
        "IE" == w && (f = (/; *(?:XBLWP|ZuneWP)(\d+)/i.exec(a) || 0)[1]) ? (w += " Mobile", y = "Windows Phone " + (/\+$/.test(f) ? f : f + ".x"), h.unshift("desktop mode")) : /\bWPDesktop\b/i.test(a) ? (w = "IE Mobile", y = "Windows Phone 8.x",
            h.unshift("desktop mode"), u || (u = (/\brv:([\d.]+)/.exec(a) || 0)[1])) : "IE" != w && "Trident" == F && (f = /\brv:([\d.]+)/.exec(a)) && (w && h.push("identifying as " + w + (u ? " " + u : "")), w = "IE", u = f[1]);
        if (S) {
            if (k(g, "global"))
                if (H && (f = H.lang.System, U = f.getProperty("os.arch"), y = y || f.getProperty("os.name") + " " + f.getProperty("os.version")), O) {
                    try {
                        u = g.require("ringo/engine").version.join("."), w = "RingoJS"
                    } catch (X) {
                        (f = g.system) && f.global.system == g.system && (w = "Narwhal", y || (y = f[0].os || null))
                    }
                    w || (w = "Rhino")
                } else "object" == typeof g.process &&
                    !g.process.browser && (f = g.process) && ("object" == typeof f.versions && ("string" == typeof f.versions.electron ? (h.push("Node " + f.versions.node), w = "Electron", u = f.versions.electron) : "string" == typeof f.versions.nw && (h.push("Chromium " + u, "Node " + f.versions.node), w = "NW.js", u = f.versions.nw)), w || (w = "Node.js", U = f.arch, y = f.platform, u = (u = /[\d.]+/.exec(f.version)) ? u[0] : null));
            else e(f = g.runtime) == z ? (w = "Adobe AIR", y = f.flash.system.Capabilities.os) : e(f = g.phantom) == R ? (w = "PhantomJS", u = (f = f.version || null) && f.major + "." + f.minor +
                "." + f.patch) : "number" == typeof J.documentMode && (f = /\bTrident\/(\d+)/i.exec(a)) ? (u = [u, J.documentMode], (f = +f[1] + 4) != u[1] && (h.push("IE " + u[1] + " mode"), F && (F[1] = ""), u[1] = f), u = "IE" == w ? String(u[1].toFixed(1)) : u[0]) : "number" == typeof J.documentMode && /^(?:Chrome|Firefox)\b/.test(w) && (h.push("masking as " + w + " " + u), w = "IE", u = "11.0", F = ["Trident"], y = "Windows");
            y = y && c(y)
        }
        u && (f = /(?:[ab]|dp|pre|[ab]\d+pre)(?:\d+\+?)?$/i.exec(u) || /(?:alpha|beta)(?: ?\d)?/i.exec(a + ";" + (S && v.appMinorVersion)) || /\bMinefield\b/i.test(a) &&
            "a") && (V = /b/i.test(f) ? "beta" : "alpha", u = u.replace(RegExp(f + "\\+?$"), "") + ("beta" == V ? x : T) + (/\d+\+?/.exec(f) || ""));
        if ("Fennec" == w || "Firefox" == w && /\b(?:Android|Firefox OS)\b/.test(y)) w = "Firefox Mobile";
        else if ("Maxthon" == w && u) u = u.replace(/\.[\d.]+/, ".x");
        else if (/\bXbox\b/i.test(G)) "Xbox 360" == G && (y = null), "Xbox 360" == G && /\bIEMobile\b/.test(a) && h.unshift("mobile mode");
        else if (!/^(?:Chrome|IE|Opera)$/.test(w) && (!w || G || /Browser|Mobi/.test(w)) || "Windows CE" != y && !/Mobi/i.test(a))
            if ("IE" == w && S) try {
                null === g.external &&
                    h.unshift("platform preview")
            } catch (X) {
                h.unshift("embedded")
            } else(/\bBlackBerry\b/.test(G) || /\bBB10\b/.test(a)) && (f = (RegExp(G.replace(/ +/g, " *") + "/([.\\d]+)", "i").exec(a) || 0)[1] || u) ? (f = [f, /BB10/.test(a)], y = (f[1] ? (G = null, Q = "BlackBerry") : "Device Software") + " " + f[0], u = null) : this != d && "Wii" != G && (S && I || /Opera/.test(w) && /\b(?:MSIE|Firefox)\b/i.test(a) || "Firefox" == w && /\bOS X (?:\d+\.){2,}/.test(y) || "IE" == w && (y && !/^Win/.test(y) && 5.5 < u || /\bWindows XP\b/.test(y) && 8 < u || 8 == u && !/\bTrident\b/.test(a))) && !r.test(f =
                p.call(d, a.replace(r, "") + ";")) && f.name && (f = "ing as " + f.name + ((f = f.version) ? " " + f : ""), r.test(w) ? (/\bIE\b/.test(f) && "Mac OS" == y && (y = null), f = "identify" + f) : (f = "mask" + f, w = M ? c(M.replace(/([a-z])([A-Z])/g, "$1 $2")) : "Opera", /\bIE\b/.test(f) && (y = null), S || (u = null)), F = ["Presto"], h.push(f));
            else w += " Mobile";
        if (f = (/\bAppleWebKit\/([\d.]+\+?)/i.exec(a) || 0)[1]) {
            f = [parseFloat(f.replace(/\.(\d)$/, ".0$1")), f];
            if ("Safari" == w && "+" == f[1].slice(-1)) w = "WebKit Nightly", V = "alpha", u = f[1].slice(0, -1);
            else if (u == f[1] || u == (f[2] =
                    (/\bSafari\/([\d.]+\+?)/i.exec(a) || 0)[1])) u = null;
            f[1] = (/\bChrome\/([\d.]+)/i.exec(a) || 0)[1];
            537.36 == f[0] && 537.36 == f[2] && 28 <= parseFloat(f[1]) && "WebKit" == F && (F = ["Blink"]);
            S && (t || f[1]) ? (F && (F[1] = "like Chrome"), f = f[1] || (f = f[0], 530 > f ? 1 : 532 > f ? 2 : 532.05 > f ? 3 : 533 > f ? 4 : 534.03 > f ? 5 : 534.07 > f ? 6 : 534.1 > f ? 7 : 534.13 > f ? 8 : 534.16 > f ? 9 : 534.24 > f ? 10 : 534.3 > f ? 11 : 535.01 > f ? 12 : 535.02 > f ? "13+" : 535.07 > f ? 15 : 535.11 > f ? 16 : 535.19 > f ? 17 : 536.05 > f ? 18 : 536.1 > f ? 19 : 537.01 > f ? 20 : 537.11 > f ? "21+" : 537.13 > f ? 23 : 537.18 > f ? 24 : 537.24 > f ? 25 : 537.36 > f ? 26 : "Blink" !=
                F ? "27" : "28")) : (F && (F[1] = "like Safari"), f = (f = f[0], 400 > f ? 1 : 500 > f ? 2 : 526 > f ? 3 : 533 > f ? 4 : 534 > f ? "4+" : 535 > f ? 5 : 537 > f ? 6 : 538 > f ? 7 : 601 > f ? 8 : "8"));
            F && (F[1] += " " + (f += "number" == typeof f ? ".x" : /[.+]/.test(f) ? "" : "+"));
            "Safari" == w && (!u || 45 < parseInt(u)) && (u = f)
        }
        "Opera" == w && (f = /\bzbov|zvav$/.exec(y)) ? (w += " ", h.unshift("desktop mode"), "zvav" == f ? (w += "Mini", u = null) : w += "Mobile", y = y.replace(RegExp(" *" + f + "$"), "")) : "Safari" == w && /\bChrome\b/.exec(F && F[1]) && (h.unshift("desktop mode"), w = "Chrome Mobile", u = null, /\bOS X\b/.test(y) ? (Q =
            "Apple", y = "iOS 4.3+") : y = null);
        u && 0 == u.indexOf(f = /[\d.]+$/.exec(y)) && -1 < a.indexOf("/" + f + "-") && (y = String(y.replace(f, "")).replace(/^ +| +$/g, ""));
        F && !/\b(?:Avant|Nook)\b/.test(w) && (/Browser|Lunascape|Maxthon/.test(w) || "Safari" != w && /^iOS/.test(y) && /\bSafari\b/.test(F[1]) || /^(?:Adobe|Arora|Breach|Midori|Opera|Phantom|Rekonq|Rock|Samsung Internet|Sleipnir|Web)/.test(w) && F[1]) && (f = F[F.length - 1]) && h.push(f);
        h.length && (h = ["(" + h.join("; ") + ")"]);
        Q && G && 0 > G.indexOf(Q) && h.push("on " + Q);
        G && h.push((/^on /.test(h[h.length -
            1]) ? "" : "on ") + G);
        if (y) {
            var W = (f = / ([\d.+]+)$/.exec(y)) && "/" == y.charAt(y.length - f[0].length - 1);
            y = {
                architecture: 32,
                family: f && !W ? y.replace(f[0], "") : y,
                version: f ? f[1] : null,
                toString: function() {
                    var a = this.version;
                    return this.family + (a && !W ? " " + a : "") + (64 == this.architecture ? " 64-bit" : "")
                }
            }
        }(f = /\b(?:AMD|IA|Win|WOW|x86_|x)64\b/i.exec(U)) && !/\bi686\b/i.test(U) ? (y && (y.architecture = 64, y.family = y.family.replace(RegExp(" *" + f), "")), w && (/\bWOW64\b/i.test(a) || S && /\w(?:86|32)$/.test(v.cpuClass || v.platform) && !/\bWin64; x64\b/i.test(a)) &&
            h.unshift("32-bit")) : y && /^OS X/.test(y.family) && "Chrome" == w && 39 <= parseFloat(u) && (y.architecture = 64);
        a || (a = null);
        g = {};
        g.description = a;
        g.layout = F && F[0];
        g.manufacturer = Q;
        g.name = w;
        g.prerelease = V;
        g.product = G;
        g.ua = a;
        g.version = w && u;
        g.os = y || {
            architecture: null,
            family: null,
            version: null,
            toString: function() {
                return "null"
            }
        };
        g.parse = p;
        g.toString = function() {
            return this.description || ""
        };
        g.version && h.unshift(u);
        g.name && h.unshift(w);
        y && w && (y != String(y).split(" ")[0] || y != w.split(" ")[0] && !G) && h.push(G ? "(" + y + ")" : "on " +
            y);
        h.length && (g.description = h.join(" "));
        return g
    }
    var h = {
            "function": !0,
            object: !0
        },
        n = h[typeof window] && window || this,
        t = h[typeof exports] && exports;
    h = h[typeof module] && module && !module.nodeType && module;
    var m = t && h && "object" == typeof global && global;
    !m || m.global !== m && m.window !== m && m.self !== m || (n = m);
    var g = Math.pow(2, 53) - 1,
        r = /\bOpera/;
    m = Object.prototype;
    var v = m.hasOwnProperty,
        E = m.toString,
        u = p();
    "function" == typeof define && "object" == typeof define.amd && define.amd ? (n.platform = u, define(function() {
            return u
        })) : t &&
        h ? d(u, function(a, b) {
            t[b] = a
        }) : n.platform = u
}).call(this);

function buildIOSMeta() {
    for (var a = [{
            name: "viewport",
            content: "width=device-width, height=device-height, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no"
        }, {
            name: "apple-mobile-web-app-capable",
            content: "yes"
        }, {
            name: "apple-mobile-web-app-status-bar-style",
            content: "black"
        }], b = 0; b < a.length; b++) {
        var c = document.createElement("meta");
        c.name = a[b].name;
        c.content = a[b].content;
        var d = window.document.head.querySelector('meta[name="' + c.name + '"]');
        d && d.parentNode.removeChild(d);
        window.document.head.appendChild(c)
    }
}

function hideIOSFullscreenPanel() {
    jQuery(".xxx-ios-fullscreen-message").css("display", "none");
    jQuery(".xxx-ios-fullscreen-scroll").css("display", "none");
    jQuery(".xxx-game-iframe-full").removeClass("xxx-game-iframe-iphone-se")
}

function buildIOSFullscreenPanel() {
    jQuery("body").append('<div class="xxx-ios-fullscreen-message"><div class="xxx-ios-fullscreen-swipe"></div></div><div class="xxx-ios-fullscreen-scroll"></div>')
}

function showIOSFullscreenPanel() {
    jQuery(".xxx-ios-fullscreen-message").css("display", "block");
    jQuery(".xxx-ios-fullscreen-scroll").css("display", "block")
}

function __iosResize() {
    window.scrollTo(0, 0);
    if ("iPhone" === platform.product) switch (window.devicePixelRatio) {
        case 2:
            switch (window.innerWidth) {
                case 568:
                    320 !== window.innerHeight && jQuery(".xxx-game-iframe-full").addClass("xxx-game-iframe-iphone-se");
                    break;
                case 667:
                    375 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                default:
                    hideIOSFullscreenPanel()
            }
            break;
        case 3:
            switch (window.innerWidth) {
                case 736:
                    414 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                case 724:
                    375 === window.innerHeight ? hideIOSFullscreenPanel() : showIOSFullscreenPanel();
                    break;
                default:
                    hideIOSFullscreenPanel()
            }
            break;
        default:
            hideIOSFullscreenPanel()
    }
}

function iosResize() {
    __iosResize();
    setTimeout(function() {
        __iosResize()
    }, 500)
}

function iosInIframe() {
    try {
        return window.self !== window.top
    } catch (a) {
        return !0
    }
}
$(document).ready(function() {
    platform && "iPhone" === platform.product && !iosInIframe() && (buildIOSFullscreenPanel(), buildIOSMeta())
});
jQuery(window).resize(function() {
    platform && "iPhone" === platform.product && !iosInIframe() && iosResize()
});
var s_iOffsetX, s_iOffsetY, s_iScaleFactor = 1,
    s_bIsIphone = !1;
(function(a) {
    (jQuery.browser = jQuery.browser || {}).mobile = /android|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(ad|hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|tablet|treo|up\.(browser|link)|vodafone|wap|webos|windows (ce|phone)|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(a.substr(0,
        4))
})(navigator.userAgent || navigator.vendor || window.opera);
$(window).resize(function() {
    sizeHandler()
});

function trace(a) {
    console.log(a)
}

function isChrome() {
    return /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor)
}

function isIOS() {
    var a = "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";");
    for (-1 !== navigator.userAgent.toLowerCase().indexOf("iphone") && (s_bIsIphone = !0); a.length;)
        if (navigator.platform === a.pop()) return !0;
    return s_bIsIphone = !1
}

function getSize(a) {
    var b = a.toLowerCase(),
        c = window.document,
        d = c.documentElement;
    if (void 0 === window["inner" + a]) a = d["client" + a];
    else if (window["inner" + a] != d["client" + a]) {
        var e = c.createElement("body");
        e.id = "vpw-test-b";
        e.style.cssText = "overflow:scroll";
        var k = c.createElement("div");
        k.id = "vpw-test-d";
        k.style.cssText = "position:absolute;top:-1000px";
        k.innerHTML = "<style>@media(" + b + ":" + d["client" + a] + "px){body#vpw-test-b div#vpw-test-d{" + b + ":7px!important}}</style>";
        e.appendChild(k);
        d.insertBefore(e, c.head);
        a = 7 == k["offset" + a] ? d["client" + a] : window["inner" + a];
        d.removeChild(e)
    } else a = window["inner" + a];
    return a
}
window.addEventListener("orientationchange", onOrientationChange);

function onOrientationChange() {
    sizeHandler()
}

function getIOSWindowHeight() {
    return document.documentElement.clientWidth / window.innerWidth * window.innerHeight
}

function getHeightOfIOSToolbars() {
    var a = (0 === window.orientation ? screen.height : screen.width) - getIOSWindowHeight();
    return 1 < a ? a : 0
}

function sizeHandler() {
    window.scrollTo(0, 1);
    if ($("#canvas")) {
        var a = navigator.userAgent.match(/(iPad|iPhone|iPod)/g) ? getIOSWindowHeight() : getSize("Height");
        var b = getSize("Width");
        _checkOrientation(b, a);
        var c = Math.min(a / CANVAS_HEIGHT, b / CANVAS_WIDTH),
            d = CANVAS_WIDTH * c;
        c *= CANVAS_HEIGHT;
        if (c < a) {
            var e = a - c;
            c += e;
            d += CANVAS_WIDTH / CANVAS_HEIGHT * e
        } else d < b && (e = b - d, d += e, c += CANVAS_HEIGHT / CANVAS_WIDTH * e);
        e = a / 2 - c / 2;
        var k = b / 2 - d / 2,
            l = CANVAS_WIDTH / d;
        if (k * l < -EDGEBOARD_X || e * l < -EDGEBOARD_Y) c = Math.min(a / (CANVAS_HEIGHT - 2 *
            EDGEBOARD_Y), b / (CANVAS_WIDTH - 2 * EDGEBOARD_X)), d = CANVAS_WIDTH * c, c *= CANVAS_HEIGHT, e = (a - c) / 2, k = (b - d) / 2, l = CANVAS_WIDTH / d;
        s_iOffsetX = -1 * k * l;
        s_iOffsetY = -1 * e * l;
        0 <= e && (s_iOffsetY = 0);
        0 <= k && (s_iOffsetX = 0);
        null !== s_oGame && s_oGame.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        null !== s_oMenu && s_oMenu.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        s_bIsIphone ? (canvas = document.getElementById("canvas"), s_oStage.canvas.width = 2 * d, s_oStage.canvas.height = 2 * c, canvas.style.width = d + "px", canvas.style.height = c + "px", s_iScaleFactor = 2 * Math.min(d /
            CANVAS_WIDTH, c / CANVAS_HEIGHT), s_oStage.scaleX = s_oStage.scaleY = s_iScaleFactor) : s_bMobile || isChrome() ? ($("#canvas").css("width", d + "px"), $("#canvas").css("height", c + "px")) : (s_oStage.canvas.width = d, s_oStage.canvas.height = c, s_iScaleFactor = Math.min(d / CANVAS_WIDTH, c / CANVAS_HEIGHT), s_oStage.scaleX = s_oStage.scaleY = s_iScaleFactor);
        0 > e ? $("#canvas").css("top", e + "px") : $("#canvas").css("top", "0px");
        $("#canvas").css("left", k + "px");
        fullscreenHandler()
    }
}

function _checkOrientation(a, b) {
    s_bMobile && ENABLE_CHECK_ORIENTATION && (a > b ? "landscape" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"), s_oMain.stopUpdate()) : "portrait" === $(".orientation-msg-container").attr("data-orientation") ? ($(".orientation-msg-container").css("display", "none"), s_oMain.startUpdate()) : ($(".orientation-msg-container").css("display", "block"),
        s_oMain.stopUpdate()))
}

function createBitmap(a, b, c) {
    var d = new createjs.Bitmap(a),
        e = new createjs.Shape;
    b && c ? e.graphics.beginFill("#fff").drawRect(0, 0, b, c) : e.graphics.beginFill("#ff0").drawRect(0, 0, a.width, a.height);
    d.hitArea = e;
    return d
}

function createSprite(a, b, c, d, e, k) {
    a = null !== b ? new createjs.Sprite(a, b) : new createjs.Sprite(a);
    b = new createjs.Shape;
    b.graphics.beginFill("#000000").drawRect(-c, -d, e, k);
    a.hitArea = b;
    return a
}

function randomFloatBetween(a, b, c) {
    "undefined" === typeof c && (c = 2);
    return parseFloat(Math.min(a + Math.random() * (b - a), b).toFixed(c))
}

function shuffle(a) {
    for (var b = a.length, c, d; 0 !== b;) d = Math.floor(Math.random() * b), --b, c = a[b], a[b] = a[d], a[d] = c;
    return a
}

function formatTime(a) {
    a /= 1E3;
    var b = Math.floor(a / 60);
    a = parseFloat(a - 60 * b).toFixed(1);
    var c = "";
    c = 10 > b ? c + ("0" + b + ":") : c + (b + ":");
    return 10 > a ? c + ("0" + a) : c + a
}

function rotateVector2D(a, b) {
    var c = b.getX() * Math.cos(a) + b.getY() * Math.sin(a),
        d = b.getX() * -Math.sin(a) + b.getY() * Math.cos(a);
    b.set(c, d)
}

function NoClickDelay(a) {
    this.element = a;
    window.Touch && this.element.addEventListener("touchstart", this, !1)
}
NoClickDelay.prototype = {
    handleEvent: function(a) {
        switch (a.type) {
            case "touchstart":
                this.onTouchStart(a);
                break;
            case "touchmove":
                this.onTouchMove(a);
                break;
            case "touchend":
                this.onTouchEnd(a)
        }
    },
    onTouchStart: function(a) {
        a.preventDefault();
        this.moved = !1;
        this.element.addEventListener("touchmove", this, !1);
        this.element.addEventListener("touchend", this, !1)
    },
    onTouchMove: function(a) {
        this.moved = !0
    },
    onTouchEnd: function(a) {
        this.element.removeEventListener("touchmove", this, !1);
        this.element.removeEventListener("touchend",
            this, !1);
        if (!this.moved) {
            a = document.elementFromPoint(a.changedTouches[0].clientX, a.changedTouches[0].clientY);
            3 === a.nodeType && (a = a.parentNode);
            var b = document.createEvent("MouseEvents");
            b.initEvent("click", !0, !0);
            a.dispatchEvent(b)
        }
    }
};

function getUrlVars(a) {
    a = a.trim();
    var b = [];
    a = a.split("&");
    for (var c = 0; c < a.length; c++) {
        var d = a[c].split("=");
        b[d[0]] = d[1]
    }
    return b
}

function tryCheckLogin() {
    var a = checkLogin();
    a = getUrlVars(a);
    "true" === a.res ? (s_bLogged = !0, WHEEL_SETTINGS = a.bonus_prize.split("#"), s_oGameSettings.initSymbolWin(a.paytable), COIN_BET = a.coin_bet.split("#"), MAX_BET = parseFloat(COIN_BET[COIN_BET.length - 1]), MIN_BET = parseFloat(COIN_BET[0]), $(s_oMain).trigger("start_session"), s_oMenu.exitFromMenu()) : s_oMsgBox.show("can't login #" + a.desc)
}

function tryCallSpin(a, b, c) {
    a = callSpin(c, a, b);
    a = getUrlVars(a);
    if ("true" === a.res) s_oGame.onSpinReceived(a);
    else s_oMsgBox.show(a.desc)
}

function ctlArcadeResume() {
    null !== s_oMain && s_oMain.startUpdate()
}

function ctlArcadePause() {
    null !== s_oMain && s_oMain.stopUpdate()
}

function getParamValue(a) {
    for (var b = window.location.search.substring(1).split("&"), c = 0; c < b.length; c++) {
        var d = b[c].split("=");
        if (d[0] == a) return d[1]
    }
}

function playSound(a, b, c) {
    return !1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile ? (s_aSounds[a].play(), s_aSounds[a].volume(b), s_aSounds[a].loop(c), s_aSounds[a]) : null
}

function stopSound(a) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].stop()
}

function setVolume(a, b) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].volume(b)
}

function setMute(a, b) {
    !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || s_aSounds[a].mute(b)
}
(function() {
    function a(a) {
        var c = {
            focus: "visible",
            focusin: "visible",
            pageshow: "visible",
            blur: "hidden",
            focusout: "hidden",
            pagehide: "hidden"
        };
        a = a || window.event;
        a.type in c ? document.body.className = c[a.type] : (document.body.className = this[b] ? "hidden" : "visible", "hidden" === document.body.className ? s_oMain.stopUpdate() : s_oMain.startUpdate())
    }
    var b = "hidden";
    b in document ? document.addEventListener("visibilitychange", a) : (b = "mozHidden") in document ? document.addEventListener("mozvisibilitychange", a) : (b = "webkitHidden") in
        document ? document.addEventListener("webkitvisibilitychange", a) : (b = "msHidden") in document ? document.addEventListener("msvisibilitychange", a) : "onfocusin" in document ? document.onfocusin = document.onfocusout = a : window.onpageshow = window.onpagehide = window.onfocus = window.onblur = a
})();

function fullscreenHandler() {
    ENABLE_FULLSCREEN && !1 !== screenfull.enabled && (s_bFullscreen = screen.height < window.innerHeight + 3 && screen.height > window.innerHeight - 3 ? !0 : !1, null !== s_oInterface && s_oInterface.resetFullscreenBut(), null !== s_oMenu && s_oMenu.resetFullscreenBut())
}
if (screenfull.enabled) screenfull.on("change", function() {
    s_bFullscreen = screenfull.isFullscreen;
    null !== s_oInterface && s_oInterface.resetFullscreenBut();
    null !== s_oMenu && s_oMenu.resetFullscreenBut()
});

function CSpriteLibrary() {
    var a = {},
        b, c, d, e, k, l;
    this.init = function(a, p, h) {
        b = {};
        d = c = 0;
        e = a;
        k = p;
        l = h
    };
    this.addSprite = function(d, e) {
        a.hasOwnProperty(d) || (a[d] = b[d] = {
            szPath: e,
            oSprite: new Image,
            bLoaded: !1
        }, c++)
    };
    this.getSprite = function(b) {
        return a.hasOwnProperty(b) ? a[b].oSprite : null
    };
    this._onSpritesLoaded = function() {
        c = 0;
        k.call(l)
    };
    this._onSpriteLoaded = function(a) {
        e.call(l, a);
        ++d === c && this._onSpritesLoaded()
    };
    this.loadSprites = function() {
        for (var a in b) b[a].oSprite.oSpriteLibrary = this, b[a].oSprite.szKey = a,
            b[a].oSprite.onload = function() {
                this.oSpriteLibrary.setLoaded(this.szKey);
                this.oSpriteLibrary._onSpriteLoaded(this.szKey)
            }, b[a].oSprite.src = b[a].szPath
    };
    this.setLoaded = function(b) {
        a[b].bLoaded = !0
    };
    this.isLoaded = function(b) {
        return a[b].bLoaded
    };
    this.getNumSprites = function() {
        return c
    }
}
var CANVAS_WIDTH = 1500,
    CANVAS_HEIGHT = 768,
    EDGEBOARD_X = 200,
    EDGEBOARD_Y = 70,
    FPS = 30,
    FPS_TIME = 1E3 / FPS,
    DISABLE_SOUND_MOBILE = !1,
    FONT_GAME_1 = "odin_roundedbold",
    FONT_GAME_2 = "Digital-7",
    STATE_LOADING = 0,
    STATE_MENU = 1,
    STATE_HELP = 1,
    STATE_GAME = 3,
    GAME_STATE_IDLE = 0,
    GAME_STATE_SPINNING = 1,
    GAME_STATE_SHOW_ALL_WIN = 2,
    GAME_STATE_SHOW_WIN = 3,
    GAME_STATE_BONUS = 4,
    REEL_STATE_START = 0,
    REEL_STATE_MOVING = 1,
    REEL_STATE_STOP = 2,
    SPIN_BUT_STATE_SPIN = "spin",
    SPIN_BUT_STATE_STOP = "stop",
    SPIN_BUT_STATE_AUTOSPIN = "autospin",
    SPIN_BUT_STATE_DISABLE =
    "disable",
    SPIN_BUT_STATE_FREESPIN = "freespin",
    SPIN_BUT_STATE_SKIP = "skip",
    ON_MOUSE_DOWN = 0,
    ON_MOUSE_UP = 1,
    ON_MOUSE_OVER = 2,
    ON_MOUSE_OUT = 3,
    ON_DRAG_START = 4,
    ON_DRAG_END = 5,
    BONUS_BUTTON_1 = "up_left",
    BONUS_BUTTON_2 = "center_left",
    BONUS_BUTTON_3 = "down_left",
    BONUS_BUTTON_4 = "up_right",
    BONUS_BUTTON_5 = "center_right",
    BONUS_BUTTON_6 = "down_right",
    REEL_OFFSET_X = 290,
    REEL_OFFSET_Y = 97,
    NUM_REELS = 5,
    NUM_ROWS = 3,
    NUM_SYMBOLS = 13,
    WILD_SYMBOL = 12,
    BONUS_SYMBOL = 13,
    FREESPIN_SYMBOL = 1,
    NUM_PAYLINES = 20,
    SYMBOL_WIDTH = 171,
    SYMBOL_HEIGHT = 164,
    SYMBOL_ANIM_WIDTH = 340,
    SYMBOL_ANIM_HEIGHT = 326,
    SPACE_BETWEEN_SYMBOLS = 17,
    SPACE_HEIGHT_BETWEEN_SYMBOLS = 4,
    MAX_FRAMES_REEL_EASE = 16,
    MIN_REEL_LOOPS, REEL_DELAY, REEL_START_Y = REEL_OFFSET_Y - 3 * (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS),
    REEL_ARRIVAL_Y = REEL_OFFSET_Y + 3 * (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS),
    TIME_SHOW_WIN, TIME_SHOW_ALL_WINS, TIME_SPIN_BUT_CHANGE = 1E3,
    TIME_HOLD_AUTOSPIN = 1E3,
    COIN_BET, MIN_BET, MAX_BET, TOTAL_MONEY, WIN_OCCURRENCE, SLOT_CASH, MIN_WIN, FREESPIN_OCCURRENCE, BONUS_OCCURRENCE, FREESPIN_SYMBOL_NUM_OCCURR,
    NUM_FREESPIN, BONUS_PRIZE, BONUS_PRIZE_OCCURR, PAYTABLE_VALUES, BONUS_FREESPIN = 1,
    BONUS_GOALKEEPER = 2,
    WHEEL_SETTINGS, SEGMENT_ROT = 18,
    TIME_ANIM_IDLE = 1E4,
    MIN_FAKE_SPIN = 3,
    WHEEL_SPIN_TIMESPEED = 2600,
    ANIM_SPIN_TIMESPEED = 50,
    TIME_ANIM_WIN = 5E3,
    ANIM_WIN1_TIMESPEED = 300,
    ANIM_WIN2_TIMESPEED = 50,
    LED_SPIN = 3,
    ANIM_IDLE1_TIMESPEED = 2E3,
    ANIM_IDLE2_TIMESPEED = 100,
    ANIM_IDLE3_TIMESPEED = 150,
    STATE_BONUS_IDLE = 0,
    STATE_BONUS_KICK = 1,
    STATE_BONUS_WIN = 2,
    STATE_BONUS_LOSE = 3,
    NUM_SPIN_FOR_ADS, ENABLE_FULLSCREEN, ENABLE_CHECK_ORIENTATION, SHOW_CREDITS;

function CSlotSettings() {
    this._init = function() {
        this._initSymbolSpriteSheets();
        this._initSymbolAnims();
        this._initSymbolsOccurence()
    };
    this._initSymbolSpriteSheets = function() {
        s_aSymbolData = [];
        for (var a = 1; a < NUM_SYMBOLS + 1; a++) {
            var b = {
                images: [s_oSpriteLibrary.getSprite("symbol_" + a)],
                frames: {
                    width: SYMBOL_WIDTH,
                    height: SYMBOL_HEIGHT,
                    regX: 0,
                    regY: 0
                },
                animations: {
                    "static": [0, 1],
                    moving: [1, 2]
                }
            };
            s_aSymbolData[a] = new createjs.SpriteSheet(b)
        }
    };
    this.initSymbolWin = function(a) {
        a = a.split("#");
        s_aSymbolWin = [];
        for (var b =
                0; b < a.length; b++) {
            var c = a[b].split(",");
            s_aSymbolWin[b] = [];
            for (var d = 0; d < c.length; d++) s_aSymbolWin[b][d] = parseFloat(c[d])
        }
    };
    this._initSymbolsOccurence = function() {
        s_aRandSymbols = [];
        var a;
        for (a = 0; 1 > a; a++) s_aRandSymbols.push(1);
        for (a = 0; 2 > a; a++) s_aRandSymbols.push(2);
        for (a = 0; 3 > a; a++) s_aRandSymbols.push(3);
        for (a = 0; 4 > a; a++) s_aRandSymbols.push(4);
        for (a = 0; 4 > a; a++) s_aRandSymbols.push(5);
        for (a = 0; 6 > a; a++) s_aRandSymbols.push(6);
        for (a = 0; 6 > a; a++) s_aRandSymbols.push(7);
        for (a = 0; 6 > a; a++) s_aRandSymbols.push(8);
        for (a =
            0; 6 > a; a++) s_aRandSymbols.push(9);
        for (a = 0; 6 > a; a++) s_aRandSymbols.push(10);
        for (a = 0; 6 > a; a++) s_aRandSymbols.push(11);
        for (a = 0; 1 > a; a++) s_aRandSymbols.push(12);
        for (a = 0; 1 > a; a++) s_aRandSymbols.push(13)
    };
    this._initSymbolAnims = function() {
        s_aSymbolAnims = [];
        for (var a = Math.floor(FPS / 2), b = 0; b < NUM_SYMBOLS; b++) {
            var c = {
                framerate: a,
                images: [s_oSpriteLibrary.getSprite("symbol_" + (b + 1) + "_anim")],
                frames: {
                    width: SYMBOL_ANIM_WIDTH,
                    height: SYMBOL_ANIM_HEIGHT
                },
                animations: {
                    "static": [0],
                    anim: [0, 23]
                }
            };
            s_aSymbolAnims[b] = new createjs.SpriteSheet(c)
        }
        s_oAnimRegPoint = [{
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, {
            x: 85,
            y: 82
        }, , {
            x: 85,
            y: 82
        }]
    };
    this._init()
}
var s_aSymbolData, s_aPaylineCombo, s_aSymbolWin, s_aSymbolAnims, s_aRandSymbols, s_oAnimRegPoint = [],
    TEXT_MONEY = "MONEY",
    TEXT_BET = "BET",
    TEXT_COIN = "COIN",
    TEXT_MAX_BET = "MAX BET",
    TEXT_LINES = "LINES",
    TEXT_PAYTABLE = "PAYTABLE",
    TEXT_WIN = "WIN",
    TEXT_HELP_BONUS1 = "3 OR MORE ON ANY REELS, WILL TRIGGER PENALTY KICK BONUS!!",
    TEXT_HELP_BONUS2 = "CHOOSE WHERE TO KICK THE BALL TO GET A PRIZE!!",
    TEXT_HELP_FREESPIN = "GET 3 OR MORE FREESPIN SYMBOL ON ANY REEL TO TRIGGER FREESPINS",
    TEXT_CURRENCY = "$",
    TEXT_CONGRATS = "CONGRATULATIONS!!",
    TEXT_YOU_WIN = "YOU GOT",
    TEXT_FREESPINS = "FREESPINS",
    TEXT_DEVELOPED = "DEVELOPED BY",
    TEXT_PRELOADER_CONTINUE = "START",
    TEXT_NO_MAX_BET = "NOT ENOUGH MONEY FOR MAX BET!!",
    TEXT_NOT_ENOUGH_MONEY = "NOT ENOUGH MONEY FOR THE CURRENT BET!",
    TEXT_CONGRATULATIONS = "Congratulations!",
    TEXT_MSG_SHARE1 = "You collected <strong>",
    TEXT_MSG_SHARE2 = " points</strong>!<br><br>Share your score with your friends!",
    TEXT_MSG_SHARING1 = "My score is ",
    TEXT_MSG_SHARING2 = " points! Can you do better?";

function CPreloader() {
    var a, b, c, d, e, k, l, q, p, h;
    this._init = function() {
        s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("progress_bar", "./sprites/progress_bar.png");
        s_oSpriteLibrary.addSprite("200x200", "./sprites/200x200.jpg");
        s_oSpriteLibrary.addSprite("but_start", "./sprites/but_start.png");
        s_oSpriteLibrary.loadSprites();
        h = new createjs.Container;
        s_oStage.addChild(h)
    };
    this.unload = function() {
        h.removeAllChildren();
        p.unload()
    };
    this._onImagesLoaded = function() {};
    this._onAllImagesLoaded = function() {
        this.attachSprites();
        s_oMain.preloaderReady()
    };
    this.attachSprites = function() {
        var n = new createjs.Shape;
        n.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        h.addChild(n);
        n = s_oSpriteLibrary.getSprite("200x200");
        l = createBitmap(n);
        l.regX = .5 * n.width;
        l.regY = .5 * n.height;
        l.x = CANVAS_WIDTH / 2;
        l.y = CANVAS_HEIGHT / 2 - 180;
        h.addChild(l);
        q = new createjs.Shape;
        q.graphics.beginFill("rgba(0,0,0,0.01)").drawRoundRect(l.x - 100, l.y - 100, 200, 200, 10);
        h.addChild(q);
        l.mask = q;
        n = s_oSpriteLibrary.getSprite("progress_bar");
        d = createBitmap(n);
        d.x = CANVAS_WIDTH / 2 - n.width / 2;
        d.y = CANVAS_HEIGHT / 2 + 50;
        h.addChild(d);
        a = n.width;
        b = n.height;
        e = new createjs.Shape;
        e.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(d.x, d.y, 1, b);
        h.addChild(e);
        d.mask = e;
        c = new createjs.Text("", "30px " + FONT_GAME_1, "#fff");
        c.x = CANVAS_WIDTH / 2;
        c.y = CANVAS_HEIGHT / 2 + 100;
        c.textBaseline = "alphabetic";
        c.textAlign = "center";
        h.addChild(c);
        n = s_oSpriteLibrary.getSprite("but_start");
        p = new CTextButton(CANVAS_WIDTH / 2, CANVAS_HEIGHT /
            2, n, TEXT_PRELOADER_CONTINUE, "Arial", "#000", "bold 40", h);
        p.addEventListener(ON_MOUSE_UP, this._onButStartRelease, this);
        p.setVisible(!1);
        k = new createjs.Shape;
        k.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        h.addChild(k);
        createjs.Tween.get(k).to({
            alpha: 0
        }, 500).call(function() {
            createjs.Tween.removeTweens(k);
            h.removeChild(k)
        })
    };
    this._onButStartRelease = function() {
        s_oMain._onRemovePreloader()
    };
    this.refreshLoader = function(h) {
        c.text = h + "%";
        100 === h && (p.setVisible(!0), c.visible = !1, d.visible = !1);
        e.graphics.clear();
        h = Math.floor(h * a / 100);
        e.graphics.beginFill("rgba(0,0,0,0.01)").drawRect(d.x, d.y, h, b)
    };
    this._init()
}

function CMain(a) {
    var b, c = 0,
        d = 0,
        e = STATE_LOADING,
        k, l;
    this.initContainer = function() {
        var a = document.getElementById("canvas");
        s_oStage = new createjs.Stage(a);
        s_oAttachSection = new createjs.Container;
        s_oStage.addChild(s_oAttachSection);
        createjs.Touch.enable(s_oStage);
        s_bMobile = jQuery.browser.mobile;
        !1 === s_bMobile && s_oStage.enableMouseOver(20);
        s_iPrevTime = (new Date).getTime();
        createjs.Ticker.setFPS(FPS);
        createjs.Ticker.addEventListener("tick", this._update);
        navigator.userAgent.match(/Windows Phone/i) && (DISABLE_SOUND_MOBILE = !0);
        s_oSpriteLibrary = new CSpriteLibrary;
        seekAndDestroy() ? k = new CPreloader : window.location.href = "http://www.codethislab.com/contact-us.html"
    };
    this.preloaderReady = function() {
        this._loadImages();
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || this._initSounds();
        b = !0
    };
    this.soundLoaded = function() {
        c++;
        k.refreshLoader(Math.floor(c / d * 100))
    };
    this._initSounds = function() {
        var a = [];
        a.push({
            path: "./sounds/",
            filename: "crowd",
            loop: !0,
            volume: 1,
            ingamename: "crowd"
        });
        a.push({
            path: "./sounds/",
            filename: "press_but",
            loop: !1,
            volume: 1,
            ingamename: "press_but"
        });
        a.push({
            path: "./sounds/",
            filename: "reel_stop",
            loop: !1,
            volume: 1,
            ingamename: "reel_stop"
        });
        a.push({
            path: "./sounds/",
            filename: "reel_stop_bonus",
            loop: !1,
            volume: 1,
            ingamename: "reel_stop_bonus"
        });
        a.push({
            path: "./sounds/",
            filename: "reel_stop_freespin",
            loop: !1,
            volume: 1,
            ingamename: "reel_stop_freespin"
        });
        a.push({
            path: "./sounds/",
            filename: "start_reel",
            loop: !1,
            volume: 1,
            ingamename: "start_reel"
        });
        a.push({
            path: "./sounds/",
            filename: "spin_but",
            loop: !1,
            volume: 1,
            ingamename: "spin_but"
        });
        a.push({
            path: "./sounds/",
            filename: "kick",
            loop: !1,
            volume: 1,
            ingamename: "kick"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol1",
            loop: !1,
            volume: 1,
            ingamename: "symbol1"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol2",
            loop: !1,
            volume: 1,
            ingamename: "symbol2"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol3",
            loop: !1,
            volume: 1,
            ingamename: "symbol3"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol4",
            loop: !1,
            volume: 1,
            ingamename: "symbol4"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol5",
            loop: !1,
            volume: 1,
            ingamename: "symbol5"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol6",
            loop: !1,
            volume: 1,
            ingamename: "symbol6"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol7",
            loop: !1,
            volume: 1,
            ingamename: "symbol7"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol8",
            loop: !1,
            volume: 1,
            ingamename: "symbol8"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol9_10_11",
            loop: !1,
            volume: 1,
            ingamename: "symbol9_10_11"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol12",
            loop: !1,
            volume: 1,
            ingamename: "symbol12"
        });
        a.push({
            path: "./sounds/",
            filename: "symbol13",
            loop: !1,
            volume: 1,
            ingamename: "symbol13"
        });
        a.push({
            path: "./sounds/",
            filename: "bonus_win",
            loop: !1,
            volume: 1,
            ingamename: "bonus_win"
        });
        a.push({
            path: "./sounds/",
            filename: "avatar_win",
            loop: !1,
            volume: 1,
            ingamename: "avatar_win"
        });
        a.push({
            path: "./sounds/",
            filename: "soundtrack",
            loop: !0,
            volume: 1,
            ingamename: "soundtrack"
        });
        d += a.length;
        s_aSounds = [];
        for (var b = 0; b < a.length; b++) s_aSounds[a[b].ingamename] = new Howl({
            src: [a[b].path + a[b].filename + ".mp3", a[b].path + a[b].filename + ".ogg"],
            autoplay: !1,
            preload: !0,
            loop: a[b].loop,
            volume: a[b].volume,
            onload: s_oMain.soundLoaded
        })
    };
    this._loadImages =
        function() {
            s_oSpriteLibrary.init(this._onImagesLoaded, this._onAllImagesLoaded, this);
            s_oSpriteLibrary.addSprite("bg_menu", "./sprites/bg_menu.jpg");
            s_oSpriteLibrary.addSprite("but_bg", "./sprites/but_play_bg.png");
            s_oSpriteLibrary.addSprite("but_exit", "./sprites/but_exit.png");
            s_oSpriteLibrary.addSprite("bg_game", "./sprites/bg_game.jpg");
            s_oSpriteLibrary.addSprite("paytable1", "./sprites/paytable1.jpg");
            s_oSpriteLibrary.addSprite("paytable2", "./sprites/paytable2.jpg");
            s_oSpriteLibrary.addSprite("paytable3",
                "./sprites/paytable3.jpg");
            s_oSpriteLibrary.addSprite("paytable4", "./sprites/paytable4.jpg");
            s_oSpriteLibrary.addSprite("mask_slot", "./sprites/mask_slot.png");
            s_oSpriteLibrary.addSprite("coin_but", "./sprites/but_coin_bg.png");
            s_oSpriteLibrary.addSprite("info_but", "./sprites/but_info_bg.png");
            s_oSpriteLibrary.addSprite("win_frame_anim", "./sprites/win_frame_anim.png");
            s_oSpriteLibrary.addSprite("but_lines_bg", "./sprites/but_lines_bg.png");
            s_oSpriteLibrary.addSprite("but_maxbet_bg", "./sprites/but_maxbet_bg.png");
            s_oSpriteLibrary.addSprite("audio_icon", "./sprites/audio_icon.png");
            s_oSpriteLibrary.addSprite("msg_box", "./sprites/msg_box.png");
            s_oSpriteLibrary.addSprite("but_arrow_next", "./sprites/but_arrow_next.png");
            s_oSpriteLibrary.addSprite("but_arrow_prev", "./sprites/but_arrow_prev.png");
            s_oSpriteLibrary.addSprite("logo", "./sprites/logo.png");
            s_oSpriteLibrary.addSprite("but_spin", "./sprites/but_spin.png");
            s_oSpriteLibrary.addSprite("bg_loading_bonus", "./sprites/bg_loading_bonus.jpg");
            s_oSpriteLibrary.addSprite("bg_loading",
                "./sprites/bg_loading.jpg");
            s_oSpriteLibrary.addSprite("but_fullscreen", "./sprites/but_fullscreen.png");
            s_oSpriteLibrary.addSprite("but_credits", "./sprites/but_credits.png");
            s_oSpriteLibrary.addSprite("ctl_logo", "./sprites/ctl_logo.png");
            s_oSpriteLibrary.addSprite("but_exit_info", "./sprites/but_exit_info.png");
            s_oSpriteLibrary.addSprite("amount_win_bg", "./sprites/amount_win_bg.png");
            for (var a = 1; a < NUM_SYMBOLS + 1; a++) s_oSpriteLibrary.addSprite("symbol_" + a, "./sprites/symbol_" + a + ".png"), s_oSpriteLibrary.addSprite("symbol_" +
                a + "_anim", "./sprites/symbol_" + a + "_anim.jpg");
            for (a = 1; a < NUM_PAYLINES + 1; a++) s_oSpriteLibrary.addSprite("payline_" + a, "./sprites/paylines/payline_" + a + ".png"), s_oSpriteLibrary.addSprite("bet_but" + a, "./sprites/paylines/bet_but" + a + ".png");
            for (a = 0; 30 > a; a++) s_oSpriteLibrary.addSprite("avatar_idle_" + a, "./sprites/avatar/avatar_idle/avatar_idle_" + a + ".png");
            for (a = 0; 38 > a; a++) s_oSpriteLibrary.addSprite("avatar_win_" + a, "./sprites/avatar/avatar_win/avatar_win_" + a + ".png");
            d += s_oSpriteLibrary.getNumSprites();
            s_oSpriteLibrary.loadSprites()
        };
    this._onImagesLoaded = function() {
        c++;
        k.refreshLoader(Math.floor(c / d * 100))
    };
    this._onAllImagesLoaded = function() {};
    this._onRemovePreloader = function() {
        s_oGameSettings = new CSlotSettings;
        s_oMsgBox = new CMsgBox;
        k.unload();
        WIN_OCCURRENCE = q.win_occurrence;
        MIN_REEL_LOOPS = q.min_reel_loop;
        REEL_DELAY = q.reel_delay;
        TIME_SHOW_WIN = q.time_show_win;
        TIME_SHOW_ALL_WINS = q.time_show_all_wins;
        SLOT_CASH = q.slot_cash;
        TOTAL_MONEY = parseFloat(q.money);
        FREESPIN_OCCURRENCE = q.freespin_occurrence;
        BONUS_OCCURRENCE = q.bonus_occurrence;
        FREESPIN_SYMBOL_NUM_OCCURR = q.freespin_symbol_num_occur;
        NUM_FREESPIN = q.num_freespin;
        BONUS_PRIZE = q.bonus_prize;
        BONUS_PRIZE_OCCURR = q.bonus_prize_occur;
        COIN_BET = q.coin_bet;
        ENABLE_FULLSCREEN = a.fullscreen;
        NUM_SPIN_FOR_ADS = a.num_spin_ads_showing;
        PAYTABLE_VALUES = [];
        for (var b = 1; 11 > b; b++) PAYTABLE_VALUES[b] = a["paytable_symbol_" + b];
        s_oSoundTrack = playSound("soundtrack", 1, !0);
        this.gotoMenu()
    };
    this.gotoMenu = function() {
        new CMenu;
        e = STATE_MENU
    };
    this.gotoGame = function() {
        l = new CGame(q);
        e = STATE_GAME
    };
    this.gotoHelp = function() {
        new CHelp;
        e = STATE_HELP
    };
    this.stopUpdate = function() {
        b = !1;
        createjs.Ticker.paused = !0;
        $("#block_game").css("display", "block");
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || Howler.mute(!0)
    };
    this.startUpdate = function() {
        s_iPrevTime = (new Date).getTime();
        b = !0;
        createjs.Ticker.paused = !1;
        $("#block_game").css("display", "none");
        (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) && s_bAudioActive && Howler.mute(!1)
    };
    this._update = function(a) {
        if (!1 !== b) {
            var c = (new Date).getTime();
            s_iTimeElaps = c - s_iPrevTime;
            s_iCntTime += s_iTimeElaps;
            s_iCntFps++;
            s_iPrevTime = c;
            1E3 <= s_iCntTime && (s_iCurFps = s_iCntFps, s_iCntTime -= 1E3, s_iCntFps = 0);
            e === STATE_GAME && l.update();
            s_oStage.update(a)
        }
    };
    s_oMain = this;
    var q = a;
    ENABLE_CHECK_ORIENTATION = q.check_orientation;
    SHOW_CREDITS = q.show_credits;
    this.initContainer()
}
var s_bMobile, s_bAudioActive = !0,
    s_bFullscreen = !1,
    s_iCntTime = 0,
    s_iTimeElaps = 0,
    s_iPrevTime = 0,
    s_iCntFps = 0,
    s_iCurFps = 0,
    s_oDrawLayer, s_oStage, s_oAttachSection, s_oMain, s_oSpriteLibrary, s_bLogged = !1,
    s_oMsgBox, s_oGameSettings, s_aSounds, s_oSoundTrack = null;

function CTextButton(a, b, c, d, e, k, l, q) {
    var p, h, n, t, m, g, r, v, E, u, z, B;
    this._init = function(a, b, c, d, g, e, k, r) {
        p = !1;
        t = [];
        m = [];
        B = r;
        E = createBitmap(c);
        h = c.width;
        n = c.height;
        r = Math.ceil(k / 20);
        u = new createjs.Text(d, k + "px " + g, "#000000");
        var l = u.getBounds();
        u.textAlign = "center";
        u.textBaseline = "alphabetic";
        u.x = c.width / 2 + r;
        u.y = Math.floor(c.height / 2) + l.height / 3 + r;
        z = new createjs.Text(d, k + "px " + g, e);
        z.textAlign = "center";
        z.textBaseline = "alphabetic";
        z.x = c.width / 2;
        z.y = Math.floor(c.height / 2) + l.height / 3;
        v = new createjs.Container;
        v.x = a;
        v.y = b;
        v.regX = c.width / 2;
        v.regY = c.height / 2;
        v.cursor = "pointer";
        v.addChild(E, u, z);
        B.addChild(v);
        this._initListener()
    };
    this.unload = function() {
        v.off("mousedown", g);
        v.off("pressup", r);
        B.removeChild(v)
    };
    this.setVisible = function(a) {
        v.visible = a
    };
    this.enable = function() {
        p = !1;
        E.filters = [];
        E.cache(0, 0, h, n);
        z.color = "#fff"
    };
    this.disable = function() {
        p = !0;
        var a = (new createjs.ColorMatrix).adjustSaturation(-100).adjustBrightness(40);
        E.filters = [new createjs.ColorMatrixFilter(a)];
        E.cache(0, 0, h, n);
        z.color = "#a39b9d"
    };
    this.setText = function(a) {
        z.text = a;
        u.text = a
    };
    this._initListener = function() {
        g = v.on("mousedown", this.buttonDown);
        r = v.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        t[a] = b;
        m[a] = c
    };
    this.buttonRelease = function() {
        p || (playSound("press_but", 1, !1), v.scaleX = 1, v.scaleY = 1, t[ON_MOUSE_UP] && t[ON_MOUSE_UP].call(m[ON_MOUSE_UP]))
    };
    this.buttonDown = function() {
        p || (v.scaleX = .9, v.scaleY = .9, t[ON_MOUSE_DOWN] && t[ON_MOUSE_DOWN].call(m[ON_MOUSE_DOWN]))
    };
    this.setPosition = function(a, b) {
        v.x = a;
        v.y = b
    };
    this.changeText =
        function(a) {
            z.text = a;
            u.text = a
        };
    this.setX = function(a) {
        v.x = a
    };
    this.setY = function(a) {
        v.y = a
    };
    this.getButtonImage = function() {
        return v
    };
    this.getX = function() {
        return v.x
    };
    this.getY = function() {
        return v.y
    };
    this._init(a, b, c, d, e, k, l, q);
    return this
}

function CGfxButton(a, b, c, d) {
    var e, k, l, q, p, h = [],
        n, t, m;
    this._init = function(a, b, c) {
        e = !1;
        k = c.width;
        l = c.height;
        q = [];
        p = [];
        m = createBitmap(c);
        m.x = a;
        m.y = b;
        m.regX = c.width / 2;
        m.regY = c.height / 2;
        m.cursor = "pointer";
        g.addChild(m);
        this._initListener()
    };
    this.unload = function() {
        m.off("mousedown", n);
        m.off("pressup", t);
        g.removeChild(m)
    };
    this.enable = function() {
        e = !1;
        m.filters = [];
        m.cache(0, 0, k, l)
    };
    this.disable = function() {
        e = !0;
        var a = (new createjs.ColorMatrix).adjustSaturation(-100).adjustBrightness(40);
        m.filters = [new createjs.ColorMatrixFilter(a)];
        m.cache(0, 0, k, l)
    };
    this.setVisible = function(a) {
        m.visible = a
    };
    this._initListener = function() {
        n = m.on("mousedown", this.buttonDown);
        t = m.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        q[a] = b;
        p[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, d) {
        q[a] = b;
        p[a] = c;
        h = d
    };
    this.buttonRelease = function() {
        e || (playSound("press_but", 1, !1), m.scaleX = 1, m.scaleY = 1, q[ON_MOUSE_UP] && q[ON_MOUSE_UP].call(p[ON_MOUSE_UP], h))
    };
    this.buttonDown = function() {
        e || (m.scaleX = .9, m.scaleY = .9, q[ON_MOUSE_DOWN] && q[ON_MOUSE_DOWN].call(p[ON_MOUSE_DOWN],
            h))
    };
    this.setPosition = function(a, b) {
        m.x = a;
        m.y = b
    };
    this.setX = function(a) {
        m.x = a
    };
    this.setY = function(a) {
        m.y = a
    };
    this.getButtonImage = function() {
        return m
    };
    this.getX = function() {
        return m.x
    };
    this.getY = function() {
        return m.y
    };
    var g = d;
    this._init(a, b, c);
    return this
}

function CToggle(a, b, c, d, e) {
    var k, l, q, p, h, n, t;
    this._init = function(a, b, c, d, e) {
        t = void 0 !== e ? e : s_oStage;
        l = [];
        q = [];
        e = new createjs.SpriteSheet({
            images: [c],
            frames: {
                width: c.width / 2,
                height: c.height,
                regX: c.width / 2 / 2,
                regY: c.height / 2
            },
            animations: {
                state_true: [0],
                state_false: [1]
            }
        });
        k = d;
        p = createSprite(e, "state_" + k, c.width / 2 / 2, c.height / 2, c.width / 2, c.height);
        p.x = a;
        p.y = b;
        p.stop();
        s_bMobile || (p.cursor = "pointer");
        t.addChild(p);
        this._initListener()
    };
    this.unload = function() {
        p.off("mousedown", h);
        p.off("pressup", n);
        t.removeChild(p)
    };
    this._initListener = function() {
        h = p.on("mousedown", this.buttonDown);
        n = p.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        l[a] = b;
        q[a] = c
    };
    this.setCursorType = function(a) {
        p.cursor = a
    };
    this.setActive = function(a) {
        k = a;
        p.gotoAndStop("state_" + k)
    };
    this.buttonRelease = function() {
        p.scaleX = 1;
        p.scaleY = 1;
        playSound("press_but", 1, !1);
        k = !k;
        p.gotoAndStop("state_" + k);
        l[ON_MOUSE_UP] && l[ON_MOUSE_UP].call(q[ON_MOUSE_UP], k)
    };
    this.buttonDown = function() {
        p.scaleX = .9;
        p.scaleY = .9;
        l[ON_MOUSE_DOWN] && l[ON_MOUSE_DOWN].call(q[ON_MOUSE_DOWN])
    };
    this.setPosition = function(a, b) {
        p.x = a;
        p.y = b
    };
    this._init(a, b, c, d, e)
}

function CBetBut(a, b, c, d, e, k, l, q) {
    var p, h, n, t = [],
        m, g;
    this._init = function(a, b, c, d, e, k, l) {
        p = !1;
        h = [];
        n = [];
        g = new createjs.Container;
        g.x = a;
        g.y = b;
        r.addChild(g);
        a = new createjs.SpriteSheet({
            images: [c],
            frames: {
                width: c.width / 2,
                height: c.height
            },
            animations: {
                on: [0, 1],
                off: [1, 2]
            }
        });
        m = createSprite(a, "on", 0, 0, c.width / 2, c.height);
        m.stop();
        m.cursor = "pointer";
        g.addChild(m);
        this._initListener()
    };
    this.unload = function() {
        m.off("mousedown", this.buttonDown);
        m.off("pressup", this.buttonRelease);
        r.removeChild(m)
    };
    this.disable =
        function(a) {
            p = a
        };
    this.setVisible = function(a) {
        m.visible = a
    };
    this.setOn = function() {
        m.gotoAndStop("on")
    };
    this.setOff = function() {
        m.gotoAndStop("off")
    };
    this._initListener = function() {
        m.on("mousedown", this.buttonDown);
        m.on("pressup", this.buttonRelease)
    };
    this.addEventListener = function(a, b, c) {
        h[a] = b;
        n[a] = c
    };
    this.addEventListenerWithParams = function(a, b, c, d) {
        h[a] = b;
        n[a] = c;
        t = d
    };
    this.buttonRelease = function() {
        h[ON_MOUSE_UP] && !1 === p && (playSound("press_but", 1, !1), h[ON_MOUSE_UP].call(n[ON_MOUSE_UP], t))
    };
    this.buttonDown =
        function() {
            h[ON_MOUSE_DOWN] && !1 === p && h[ON_MOUSE_DOWN].call(n[ON_MOUSE_DOWN], t)
        };
    this.setPosition = function(a, b) {
        m.x = a;
        m.y = b
    };
    this.setX = function(a) {
        m.x = a
    };
    this.setY = function(a) {
        m.y = a
    };
    this.getButtonImage = function() {
        return m
    };
    this.getX = function() {
        return m.x
    };
    this.getY = function() {
        return m.y
    };
    var r = q;
    this._init(a, b, c, d, e, k, l)
}

function CMenu() {
    var a, b, c, d, e, k, l = null,
        q = null,
        p, h, n, t, m, g;
    this._init = function() {
        n = createBitmap(s_oSpriteLibrary.getSprite("bg_menu"));
        s_oAttachSection.addChild(n);
        var r = s_oSpriteLibrary.getSprite("but_bg");
        t = new CGfxButton(CANVAS_WIDTH / 2 + 420, CANVAS_HEIGHT - 164, r, s_oStage);
        t.addEventListener(ON_MOUSE_UP, this._onButPlayRelease, this);
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) r = s_oSpriteLibrary.getSprite("audio_icon"), e = CANVAS_WIDTH - r.width / 4 - 10, k = r.height / 2 + 10, m = new CToggle(e, k, r, s_bAudioActive, s_oAttachSection),
            m.addEventListener(ON_MOUSE_UP, this._onAudioToggle, this);
        SHOW_CREDITS ? (r = s_oSpriteLibrary.getSprite("but_credits"), a = r.width / 2 + 10, b = r.height / 2 + 10, h = new CGfxButton(a, b, r, s_oAttachSection), h.addEventListener(ON_MOUSE_UP, this._onButCreditsRelease, this), c = a + r.width + 10, d = b) : (r = s_oSpriteLibrary.getSprite("but_fullscreen"), c = r.width / 4 + 10, d = r.height / 2 + 10);
        r = window.document;
        var v = r.documentElement;
        l = v.requestFullscreen || v.mozRequestFullScreen || v.webkitRequestFullScreen || v.msRequestFullscreen;
        q = r.exitFullscreen ||
            r.mozCancelFullScreen || r.webkitExitFullscreen || r.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (l = !1);
        l && screenfull.enabled && (r = s_oSpriteLibrary.getSprite("but_fullscreen"), p = new CToggle(c, d, r, s_bFullscreen, s_oAttachSection), p.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        g = new createjs.Shape;
        g.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        s_oAttachSection.addChild(g);
        createjs.Tween.get(g).to({
            alpha: 0
        }, 400).call(function() {
            g.visible = !1
        });
        setVolume("soundtrack", 1);
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.unload = function() {
        t.unload();
        t = null;
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) m.unload(), m = null;
        SHOW_CREDITS && h.unload();
        l && screenfull.enabled && p.unload();
        s_oAttachSection.removeChild(n);
        n = null;
        s_oAttachSection.removeChild(g);
        s_oMenu = g = null;
        setVolume("soundtrack", 0)
    };
    this.refreshButtonPos = function(g, n) {
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || m.setPosition(e - g, n + k);
        SHOW_CREDITS && h.setPosition(a + g, b + n);
        l && screenfull.enabled && p.setPosition(c + g,
            d + n)
    };
    this._onButPlayRelease = function() {
        tryCheckLogin()
    };
    this.exitFromMenu = function() {
        this.unload();
        s_oMain.gotoGame()
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this._onButCreditsRelease = function() {
        new CCreditsPanel
    };
    this.resetFullscreenBut = function() {
        l && screenfull.enabled && p.setActive(s_bFullscreen)
    };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? q.call(window.document) : l.call(window.document.documentElement);
        sizeHandler()
    };
    s_oMenu = this;
    this._init()
}
var s_oMenu = null;

function CGame() {
    var a, b, c = !1,
        d = !1,
        e, k, l, q, p, h, n, t, m, g, r, v, E, u, z, B, K, P, C, N, D, L, A, O, H, R, T, x, J = null,
        I, M;
    this._init = function() {
        l = GAME_STATE_IDLE;
        t = K = h = q = 0;
        L = [0, 1, 2, 3, 4];
        p = L[0];
        n = NUM_PAYLINES;
        v = TOTAL_MONEY;
        g = MIN_BET;
        r = g * n;
        e = !1;
        P = z = u = 0;
        s_oTweenController = new CTweenController;
        O = createBitmap(s_oSpriteLibrary.getSprite("bg_game"));
        s_oAttachSection.addChild(O);
        this._initReels();
        R = new createjs.Bitmap(s_oSpriteLibrary.getSprite("mask_slot"));
        s_oAttachSection.addChild(R);
        var a = {
            images: [s_oSpriteLibrary.getSprite("logo")],
            frames: {
                width: 230,
                height: 86,
                regX: 165,
                regY: 0
            },
            animations: {
                normal: [0],
                freespin: [1, 55]
            }
        };
        x = new CInterface(g, r, v);
        this._initStaticSymbols();
        M = new CAvatar(s_oAttachSection);
        M.show(0);
        a = new createjs.SpriteSheet(a);
        H = createSprite(a, "normal", 165, 0, 230, 86);
        H.stop();
        s_oAttachSection.addChild(H);
        J = new CPayTablePanel;
        v < r && x.disableSpin();
        MIN_WIN = s_aSymbolWin[0][s_aSymbolWin[0].length - 1];
        for (a = 0; a < s_aSymbolWin.length; a++)
            for (var b = s_aSymbolWin[a], d = 0; d < b.length; d++) 0 !== b[d] && b[d] < MIN_WIN && (MIN_WIN = b[d]);
        I = new CBonusPanel;
        T = new CFreespinPanel(s_oStage);
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY);
        playSound("crowd", 1, !0);
        c = !0
    };
    this.unload = function() {
        stopSound("crowd");
        x.unload();
        J.unload();
        for (var a = 0; a < C.length; a++) C[a].unload();
        for (a = 0; a < NUM_ROWS; a++)
            for (var b = 0; b < NUM_REELS; b++) N[a][b].unload();
        s_oAttachSection.removeAllChildren();
        s_oGame = null
    };
    this.refreshButtonPos = function(f, c) {
        x.refreshButtonPos(f, c);
        J.refreshButtonPos(f, c);
        40 > s_iOffsetY ? (a = 800, b = -2) : (a = 1432, b = 80);
        H.x = a;
        H.y = b + c;
        M.refreshButtonPos(f, c)
    };
    this._initReels = function() {
        var a = REEL_OFFSET_X,
            b = REEL_OFFSET_Y,
            c = 0;
        C = [];
        for (var d = 0; d < NUM_REELS; d++) C[d] = new CReelColumn(d, a, b, c), C[d + NUM_REELS] = new CReelColumn(d + NUM_REELS, a, b + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * NUM_ROWS, c), a += SYMBOL_WIDTH + SPACE_BETWEEN_SYMBOLS, c += REEL_DELAY
    };
    this._initStaticSymbols = function() {
        var a = REEL_OFFSET_X,
            b = REEL_OFFSET_Y;
        N = [];
        for (var c = 0; c < NUM_ROWS; c++) {
            N[c] = [];
            for (var d = 0; d < NUM_REELS; d++) {
                var g = new CStaticSymbolCell(c, d, a, b);
                N[c][d] = g;
                a += SYMBOL_WIDTH + SPACE_BETWEEN_SYMBOLS
            }
            a = REEL_OFFSET_X;
            b += SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS
        }
    };
    this.generateLosingPattern = function() {
        for (var a = [], b = 0; b < NUM_ROWS; b++) {
            var c = Math.floor(Math.random() * (s_aRandSymbols.length - 2));
            c = s_aRandSymbols[c];
            a[b] = c
        }
        A = [];
        for (b = 0; b < NUM_ROWS; b++) {
            A[b] = [];
            for (var g = 0; g < NUM_REELS; g++)
                if (0 === g) A[b][g] = a[b];
                else {
                    do c = Math.floor(Math.random() * (s_aRandSymbols.length - 2)), c = s_aRandSymbols[c]; while (a[0] === c || a[1] === c || a[2] === c);
                    A[b][g] = c
                }
        }
        D = [];
        d = !0
    };
    this._generateRandSymbols = function() {
        for (var a = [], b = 0; b < NUM_ROWS; b++) a[b] = s_aRandSymbols[Math.floor(Math.random() * s_aRandSymbols.length)];
        return a
    };
    this.reelArrived = function(a, b) {
        if (q > MIN_REEL_LOOPS)
            if (p === b) {
                if (!1 === C[a].isReadyToStop()) {
                    var c = a;
                    a < NUM_REELS ? (c += NUM_REELS, C[c].setReadyToStop(), C[a].restart([A[0][a], A[1][a], A[2][a]], !0)) : (c -= NUM_REELS, C[c].setReadyToStop(), C[a].restart([A[0][c], A[1][c], A[2][c]], !0))
                }
            } else C[a].restart(this._generateRandSymbols(), !1);
        else C[a].restart(this._generateRandSymbols(), !1), d && 0 === a && q++
    };
    this.stopNextReel = function(a, b) {
        h++;
        0 === h % 2 ? (p = L[h / 2], h === 2 * NUM_REELS && this._endReelAnimation()) : b ? playSound("reel_stop_bonus",
            1, !1) : a ? playSound("reel_stop_freespin", 1, !1) : playSound("reel_stop", 1, !1)
    };
    this._endReelAnimation = function() {
        d = !1;
        m = h = q = 0;
        p = L[0];
        0 < z && (x.disableGuiButtons(), x.disableSpin());
        "freespin" === H.currentAnimation && !1 === k && x.refreshFreeSpinNum(u);
        if (0 < D.length) {
            M.show(1);
            for (var a = 0; a < D.length; a++) {
                0 < D[a].line && (J.highlightCombo(D[a].value, D[a].num_win), x.showLine(D[a].line));
                for (var b = D[a].list, c = 0; c < b.length; c++) N[b[c].row][b[c].col].showWinFrame()
            }
            "freespin" === H.currentAnimation && 0 === u && (H.gotoAndStop("normal"),
                x.refreshFreeSpinNum(""), x.setSpinState(SPIN_BUT_STATE_SPIN));
            0 < E && x.refreshWinText(E);
            t = 0;
            l = GAME_STATE_SHOW_ALL_WIN;
            playSound("avatar_win", 1, !1);
            z !== BONUS_GOALKEEPER && x.refreshMoney(v)
        } else if (0 < u) x.disableSpin(), this.onSpin();
        else if ("freespin" === H.currentAnimation && (H.gotoAndStop("normal"), x.refreshFreeSpinNum(""), x.setSpinState(SPIN_BUT_STATE_SPIN)), e)
            if (v < r && 0 === u) this.resetCoinBet(), e = !1, x.enableGuiButtons();
            else this.onSpin();
        else l = GAME_STATE_IDLE;
        v < r && 0 === u ? (this.resetCoinBet(), e = !1, x.enableGuiButtons()) :
            e || 0 !== u || 0 !== z || (x.enableGuiButtons(), x.disableBetBut(!1));
        P++;
        P === NUM_SPIN_FOR_ADS && (P = 0, $(s_oMain).trigger("show_interlevel_ad"));
        $(s_oMain).trigger("save_score", v)
    };
    this.hidePayTable = function() {
        J.hide()
    };
    this.showWin = function() {
        if (0 < m) {
            stopSound("avatar_win");
            var a = D[m - 1].line;
            0 < a && x.hideLine(a);
            var b = D[m - 1].list;
            for (a = 0; a < b.length; a++) C[b[a].col].setVisible(b[a].row, !0), C[b[a].col + NUM_REELS].setVisible(b[a].row, !0)
        }
        if (m === D.length)
            if (m = 0, k) k = !1, T.show(u);
            else if (0 < u) x.disableSpin(), this.onSpin();
        else if (z === BONUS_GOALKEEPER) I.isVisible() || (this._hideAllWins(), I.show(BONUS_PRIZE[B]), l = GAME_STATE_BONUS);
        else if (e) this.onSpin();
        else x.enableGuiButtons(), x.disableBetBut(!1), l = GAME_STATE_IDLE;
        else {
            a = D[m].line;
            b = D[m].list;
            if (0 === a) {
                var c = Math.floor(b.length / 2);
                a = b[c].row;
                c = b[c].col
            } else {
                x.showLine(a);
                c = 2;
                var d = !1;
                3 > b.length ? D[m].value === FREESPIN_SYMBOL ? (c = b[0].col, a = b[0].row, d = !0) : (c = b.length - 1, a = b[c].row) : a = b[c].row;
                for (; !d && A[a][c] === WILD_SYMBOL;)
                    if (c--, 0 > c) {
                        c = 0;
                        a = b[c].row;
                        break
                    } else a = b[c].row
            }
            b = {
                x: 0,
                y: 0
            };
            0 === a ? 0 === c ? d = {
                x: 0,
                y: 0
            } : 4 === c ? (d = {
                x: SYMBOL_ANIM_WIDTH,
                y: 0
            }, b = {
                x: SYMBOL_WIDTH,
                y: 0
            }) : (d = {
                x: SYMBOL_ANIM_WIDTH / 2,
                y: 0
            }, b = {
                x: SYMBOL_WIDTH / 2,
                y: 0
            }) : 1 === a ? 0 === c ? (d = {
                x: 0,
                y: SYMBOL_ANIM_HEIGHT / 2
            }, b = {
                x: 0,
                y: SYMBOL_HEIGHT / 2
            }) : 4 === c ? (d = {
                x: SYMBOL_ANIM_WIDTH,
                y: SYMBOL_ANIM_HEIGHT / 2
            }, b = {
                x: SYMBOL_WIDTH,
                y: SYMBOL_HEIGHT / 2
            }) : (d = {
                x: SYMBOL_ANIM_WIDTH / 2,
                y: SYMBOL_ANIM_HEIGHT / 2
            }, b = {
                x: SYMBOL_WIDTH / 2,
                y: SYMBOL_HEIGHT / 2
            }) : 0 === c ? (d = {
                x: 0,
                y: SYMBOL_ANIM_HEIGHT
            }, b = {
                x: 0,
                y: SYMBOL_HEIGHT
            }) : 4 === c ? (d = {
                    x: SYMBOL_ANIM_WIDTH,
                    y: SYMBOL_ANIM_HEIGHT
                },
                b = {
                    x: SYMBOL_WIDTH,
                    y: SYMBOL_HEIGHT
                }) : (d = {
                x: SYMBOL_ANIM_WIDTH / 2,
                y: SYMBOL_ANIM_HEIGHT
            }, b = {
                x: SYMBOL_WIDTH / 2,
                y: SYMBOL_HEIGHT
            });
            N[a][c].show(D[m].value, D[m].amount, b, d, e || !1 === k && 0 < u ? 1 : 3);
            m++
        }
    };
    this._hideAllWins = function() {
        for (var a = 0; a < NUM_ROWS; a++)
            for (var b = 0; b < NUM_REELS; b++) N[a][b].hideWinFrame();
        x.hideAllLines()
    };
    this._prepareForWinsShowing = function() {
        this._hideAllWins();
        m = t = 0;
        t = TIME_SHOW_WIN;
        l = GAME_STATE_SHOW_WIN;
        this.showWin();
        0 === u && x.setSpinState(SPIN_BUT_STATE_SKIP)
    };
    this.activateLines = function(a) {
        n =
            a;
        this.removeWinShowing();
        r = a = g * n;
        x.refreshTotalBet(r);
        x.refreshNumLines(n);
        a > v ? x.disableSpin() : x.enableSpin()
    };
    this.resetCoinBet = function() {
        K = 0;
        var a = parseFloat(COIN_BET[K]),
            b = a * n;
        g = a;
        g = Math.floor(100 * g) / 100;
        r = b;
        x.refreshBet(g);
        x.refreshTotalBet(r);
        x.enableSpin()
    };
    this.addLine = function() {
        n === NUM_PAYLINES ? n = 1 : n++;
        r = g * n;
        r = Math.floor(100 * r) / 100;
        x.refreshTotalBet(r);
        x.refreshNumLines(n);
        x.enableSpin()
    };
    this.changeCoinBet = function() {
        K++;
        K === COIN_BET.length && (K = 0);
        var a = parseFloat(COIN_BET[K]),
            b = a * n;
        g =
            a;
        g = Math.floor(100 * g) / 100;
        r = b;
        r = Math.floor(100 * r) / 100;
        x.refreshBet(g);
        x.refreshTotalBet(r);
        x.enableSpin()
    };
    this.onMaxBet = function() {
        if (v < MAX_BET * NUM_PAYLINES) s_oMsgBox.show(TEXT_NO_MAX_BET);
        else {
            var a = MAX_BET;
            n = NUM_PAYLINES;
            a *= n;
            g = MAX_BET;
            r = a;
            x.refreshBet(g);
            x.refreshTotalBet(r);
            x.refreshNumLines(n);
            a > v ? x.disableSpin() : (x.enableSpin(), this.onSpin())
        }
    };
    this.removeWinShowing = function() {
        J.resetHighlightCombo();
        x.resetWin();
        for (var a = 0; a < NUM_ROWS; a++)
            for (var b = 0; b < NUM_REELS; b++) N[a][b].hide(), C[b].setVisible(a, !0), C[b + NUM_REELS].setVisible(a, !0);
        for (a = 0; a < C.length; a++) C[a].activate();
        l = GAME_STATE_IDLE
    };
    this.forceStopReel = function() {
        0 === u && (e = !1);
        l = GAME_STATE_IDLE;
        for (var a = 0; a < NUM_REELS; a++) C[a].forceStop([A[0][a], A[1][a], A[2][a]], REEL_OFFSET_Y), C[a + NUM_REELS].forceStop(null, REEL_OFFSET_Y + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * NUM_ROWS);
        this._endReelAnimation()
    };
    this.onSpin = function() {
        v < r && 0 === u ? (x.enableGuiButtons(), e = !1, s_oMsgBox.show(TEXT_NOT_ENOUGH_MONEY)) : (stopSound("avatar_win"), playSound("spin_but",
            1, !1), x.disableBetBut(!0), this.removeWinShowing(), !0 === s_bLogged ? (r = "freespin" === H.currentAnimation ? 0 : g * n, tryCallSpin(g, r, n)) : this.generateLosingPattern(), this._hideAllWins(), x.disableGuiButtons())
    };
    this.onSkip = function() {
        if (0 < z) this._hideAllWins(), I.show(BONUS_PRIZE[B]), l = GAME_STATE_BONUS;
        else this.onSpin()
    };
    this.onAutoSpin = function() {
        e = !0;
        this.onSpin()
    };
    this.onStopAutoSpin = function() {
        e = !1;
        l !== GAME_STATE_SPINNING && l !== GAME_STATE_BONUS && x.enableGuiButtons()
    };
    this.generateLosingPattern = function() {
        for (var a = [], b = 0; b < NUM_ROWS; b++) {
            var c = Math.floor(Math.random() * (s_aRandSymbols.length - 2));
            c = s_aRandSymbols[c];
            a[b] = c
        }
        A = [];
        for (b = 0; b < NUM_ROWS; b++) {
            A[b] = [];
            for (var g = 0; g < NUM_REELS; g++)
                if (0 === g) A[b][g] = a[b];
                else {
                    do c = Math.floor(Math.random() * (s_aRandSymbols.length - 2)), c = s_aRandSymbols[c]; while (a[0] === c || a[1] === c || a[2] === c);
                    A[b][g] = c
                }
        }
        D = [];
        d = !0
    };
    this.onSpinReceived = function(a) {
        v -= r;
        x.refreshMoney(v);
        "true" === a.res ? (u = parseInt(a.num_freespin), "true" === a.win ? (A = JSON.parse(a.pattern), D = JSON.parse(a.win_lines), k = !1, 1 === parseInt(a.freespin) ? (z = BONUS_FREESPIN, e = !1, k = !0) : 0 < parseInt(a.bonus) ? (z = BONUS_GOALKEEPER, e = !1, B = a.bonus_prize) : z = 0, E = parseFloat(a.tot_win)) : (z = 0, A = JSON.parse(a.pattern), D = []), d = !0, v = parseFloat(a.money)) : s_oGame.generateLosingPattern();
        l = GAME_STATE_SPINNING
    };
    this.onInfoClicked = function() {
        l !== GAME_STATE_SPINNING && (J.isVisible() ? J.hide() : J.show())
    };
    this.exitFromFreespinPanel = function() {
        x.refreshFreeSpinNum(u);
        H.gotoAndPlay("freespin");
        x.setSpinState(SPIN_BUT_STATE_FREESPIN);
        x.disableSpin();
        this.onSpin()
    };
    this.exitFromBonus = function() {
        $(s_oMain).trigger("bonus_end", v);
        x.refreshMoney(v);
        if (e) this.onSpin();
        else this.removeWinShowing(), x.enableGuiButtons(), x.disableBetBut(!1), x.enableSpin();
        $(s_oMain).trigger("save_score", v)
    };
    this.onExit = function() {
        this.unload();
        s_oMain.gotoMenu();
        $(s_oMain).trigger("end_session");
        $(s_oMain).trigger("share_event", {
            img: "200x200.jpg",
            title: TEXT_CONGRATULATIONS,
            msg: TEXT_MSG_SHARE1 + v + TEXT_MSG_SHARE2,
            msg_share: TEXT_MSG_SHARING1 + v + TEXT_MSG_SHARING2
        })
    };
    this.getState = function() {
        return l
    };
    this.update = function() {
        if (!1 !== c) {
            switch (l) {
                case GAME_STATE_IDLE:
                    if (e) return;
                    0 === u && (t += s_iTimeElaps, t > TIME_SPIN_BUT_CHANGE && (t = 0, x.toggleAutoSpinImage()));
                    x.update();
                    break;
                case GAME_STATE_SPINNING:
                    for (var a = 0; a < C.length; a++) C[a].update();
                    break;
                case GAME_STATE_SHOW_ALL_WIN:
                    t += s_iTimeElaps;
                    t > TIME_SHOW_ALL_WINS && this._prepareForWinsShowing();
                    break;
                case GAME_STATE_BONUS:
                    I.update()
            }
            M.update()
        }
    };
    s_oGame = this;
    this._init()
}
var s_oGame = null,
    s_oTweenController;

function CReelColumn(a, b, c, d) {
    var e, k, l, q, p, h, n, t, m, g, r, v, E, u, z;
    this._init = function(a, b, c, d) {
        l = k = e = !1;
        n = 0;
        q = a;
        h = d;
        p = q < NUM_REELS ? q : q - NUM_REELS;
        m = 0;
        g = MAX_FRAMES_REEL_EASE;
        t = REEL_STATE_START;
        r = c;
        v = r + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * NUM_ROWS;
        this.initContainer(b, c)
    };
    this.initContainer = function(a, b) {
        z = new createjs.Container;
        z.x = a;
        z.y = b;
        var c = 0;
        E = [];
        u = [];
        for (var d = 0; d < NUM_ROWS; d++) {
            var g = s_aRandSymbols[Math.floor(Math.random() * s_aRandSymbols.length)],
                e = createSprite(s_aSymbolData[g], "static",
                    0, 0, SYMBOL_WIDTH, SYMBOL_HEIGHT);
            e.stop();
            e.x = 0;
            e.y = c;
            z.addChild(e);
            E[d] = e;
            u[d] = g;
            c += SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS
        }
        s_oAttachSection.addChild(z)
    };
    this.unload = function() {
        s_oAttachSection.removeChild(z)
    };
    this.activate = function() {
        r = z.y;
        v = r + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * NUM_ROWS;
        e = !0
    };
    this._setSymbol = function(a) {
        z.removeAllChildren();
        for (var b = 0, c = 0; c < a.length; c++) {
            var d = new createjs.Sprite(s_aSymbolData[a[c]], "static", 0, 0, SYMBOL_WIDTH, SYMBOL_HEIGHT);
            d.stop();
            d.x = 0;
            d.y = b;
            z.addChild(d);
            E[c] = d;
            u[c] = a[c];
            b += SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS
        }
    };
    this.forceStop = function(a, b) {
        null !== a && this._setSymbol(a);
        z.y = b;
        e = !1;
        m = 0;
        g = MAX_FRAMES_REEL_EASE;
        t = REEL_STATE_START;
        n = 0;
        l = k = !1
    };
    this.setVisible = function(a, b) {
        E[a].visible = b
    };
    this.restart = function(a, b) {
        z.y = r = REEL_START_Y;
        v = r + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * NUM_ROWS;
        this._setSymbol(a);
        if (k = b) {
            m = 0;
            g = MAX_FRAMES_REEL_EASE;
            t = REEL_STATE_STOP;
            for (var c = 0; c < NUM_ROWS; c++) E[c].gotoAndStop("static");
            l = !0
        } else
            for (c = 0; c < NUM_ROWS; c++) E[c].gotoAndStop("moving")
    };
    this.setReadyToStop = function() {
        m = 0;
        g = MAX_FRAMES_REEL_EASE;
        t = REEL_STATE_STOP
    };
    this.isReadyToStop = function() {
        return k
    };
    this.getPosUpLeft = function(a) {
        return {
            x: z.x,
            y: z.y + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * a
        }
    };
    this.getY = function() {
        return z.y
    };
    this._updateStart = function() {
        0 === m && q < NUM_REELS && playSound("start_reel", 1, !1);
        m++;
        m > g && (m = 0, g /= 2, t++, r = z.y, v = r + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * NUM_ROWS);
        var a = s_oTweenController.easeInBack(m, 0, 1, g);
        a = s_oTweenController.tweenValue(r, v, a);
        z.y =
            a
    };
    this._updateMoving = function() {
        m++;
        m > g && (m = 0, r = z.y, v = r + (SYMBOL_HEIGHT + SPACE_HEIGHT_BETWEEN_SYMBOLS) * NUM_ROWS);
        var a = s_oTweenController.easeLinear(m, 0, 1, g);
        a = s_oTweenController.tweenValue(r, v, a);
        z.y = a
    };
    this._updateStopping = function() {
        m++;
        if (m >= g) e = !1, m = 0, g = MAX_FRAMES_REEL_EASE, t = REEL_STATE_START, n = 0, k = !1, l && (l = !1, z.y = REEL_OFFSET_Y), s_oGame.stopNextReel(u[0] === FREESPIN_SYMBOL || u[1] === FREESPIN_SYMBOL || u[2] === FREESPIN_SYMBOL ? !0 : !1, u[0] === BONUS_SYMBOL || u[1] === BONUS_SYMBOL || u[2] === BONUS_SYMBOL ? !0 : !1);
        else {
            var a = s_oTweenController.easeOutCubic(m, 0, 1, g);
            a = s_oTweenController.tweenValue(r, v, a);
            z.y = a
        }
    };
    this.update = function() {
        if (!1 !== e && (n++, n > h)) switch (!1 === k && z.y > REEL_ARRIVAL_Y && s_oGame.reelArrived(q, p), t) {
            case REEL_STATE_START:
                this._updateStart();
                break;
            case REEL_STATE_MOVING:
                this._updateMoving();
                break;
            case REEL_STATE_STOP:
                this._updateStopping()
        }
    };
    this._init(a, b, c, d)
}

function CInterface(a, b, c) {
    var d, e, k, l, q, p, h, n, t, m, g, r, v, E, u, z, B, K, P, C, N, D, L, A, O, H, R = null,
        T = null,
        x, J, I, M;
    this._init = function(a, b, c) {
        var f = s_oSpriteLibrary.getSprite("but_exit");
        d = CANVAS_WIDTH - f.width / 2 - 2;
        e = f.height / 2 + 2;
        P = new CGfxButton(d, e, f, s_oAttachSection);
        P.addEventListener(ON_MOUSE_UP, this._onExit, this);
        if (!1 === DISABLE_SOUND_MOBILE || !1 === s_bMobile) f = s_oSpriteLibrary.getSprite("audio_icon"), u = d - f.width / 2 - 2, z = f.height / 2 + 2, L = new CToggle(u, z, f, s_bAudioActive, s_oAttachSection), L.addEventListener(ON_MOUSE_UP,
            this._onAudioToggle, this);
        f = window.document;
        var B = f.documentElement;
        R = B.requestFullscreen || B.mozRequestFullScreen || B.webkitRequestFullScreen || B.msRequestFullscreen;
        T = f.exitFullscreen || f.mozCancelFullScreen || f.webkitExitFullscreen || f.msExitFullscreen;
        !1 === ENABLE_FULLSCREEN && (R = !1);
        R && screenfull.enabled && (f = s_oSpriteLibrary.getSprite("but_fullscreen"), q = f.width / 4 + 2, p = f.height / 2 + 2, H = new CToggle(q, p, f, s_bFullscreen, s_oAttachSection), H.addEventListener(ON_MOUSE_UP, this._onFullscreenRelease, this));
        this._initPaylines();
        f = s_oSpriteLibrary.getSprite("info_but");
        t = CANVAS_HEIGHT - f.height / 2 - 80;
        N = new CTextButton(420, t, f, TEXT_PAYTABLE, FONT_GAME_1, "#ffffff", 24, s_oAttachSection);
        N.addEventListener(ON_MOUSE_UP, this._onInfo, this);
        f = s_oSpriteLibrary.getSprite("but_lines_bg");
        m = CANVAS_HEIGHT - f.height / 2 - 80;
        D = new CTextButton(640, m, f, TEXT_LINES + " " + NUM_PAYLINES, FONT_GAME_1, "#ffffff", 24, s_oAttachSection);
        D.addEventListener(ON_MOUSE_UP, this._onAddLine, this);
        f = s_oSpriteLibrary.getSprite("coin_but");
        g = CANVAS_HEIGHT - f.height / 2 - 80;
        A =
            new CTextButton(860, g, f, TEXT_COIN + " " + a.toFixed(2), FONT_GAME_1, "#ffffff", 24, s_oAttachSection);
        A.addEventListener(ON_MOUSE_UP, this._onBet, this);
        f = s_oSpriteLibrary.getSprite("but_maxbet_bg");
        r = CANVAS_HEIGHT - f.height / 2 - 80;
        O = new CTextButton(1080, r, f, TEXT_MAX_BET, FONT_GAME_1, "#ffffff", 25, s_oAttachSection);
        O.addEventListener(ON_MOUSE_UP, this._onMaxBet, this);
        f = s_oSpriteLibrary.getSprite("but_spin");
        v = CANVAS_WIDTH - 100;
        E = CANVAS_HEIGHT - f.height / 2;
        C = new CSpinBut(v - s_iOffsetX, E - s_iOffsetY, f, f.width / 5, f.height,
            s_oAttachSection);
        C.addEventListener(ON_MOUSE_UP, this._onSpin, this);
        n = CANVAS_HEIGHT - 140;
        x = new createjs.Text(TEXT_MONEY + ": " + c.toFixed(2) + TEXT_CURRENCY, "26px " + FONT_GAME_2, "#ffde00");
        x.x = 375;
        x.y = n;
        x.textAlign = "left";
        x.textBaseline = "alphabetic";
        s_oAttachSection.addChild(x);
        h = CANVAS_HEIGHT - 140;
        J = new createjs.Text(TEXT_BET + ": " + b.toFixed(2) + TEXT_CURRENCY, "26px " + FONT_GAME_2, "#ffde00");
        J.x = 715;
        J.y = h;
        J.textAlign = "left";
        J.textBaseline = "alphabetic";
        J.shadow = new createjs.Shadow("#000000", 1, 1, 2);
        s_oAttachSection.addChild(J);
        I = new createjs.Text(TEXT_WIN + ": 0" + TEXT_CURRENCY, "26px " + FONT_GAME_2, "#ffde00");
        I.x = 1050;
        I.y = CANVAS_HEIGHT - 140;
        I.textAlign = "center";
        I.textBaseline = "alphabetic";
        I.shadow = new createjs.Shadow("#000000", 1, 1, 2);
        s_oAttachSection.addChild(I);
        k = CANVAS_WIDTH - 108;
        l = CANVAS_HEIGHT - 108;
        M = new createjs.Text("", "70px " + FONT_GAME_1, "#ffde00");
        M.x = k - s_iOffsetX;
        M.y = l - s_iOffsetY;
        M.textAlign = "center";
        M.textBaseline = "alphabetic";
        s_oAttachSection.addChild(M);
        this.refreshButtonPos(s_iOffsetX, s_iOffsetY)
    };
    this.unload = function() {
        P.unload();
        P = null;
        C.unload();
        C = null;
        N.unload();
        N = null;
        D.unload();
        D = null;
        A.unload();
        A = null;
        O.unload();
        O = null;
        !1 === DISABLE_SOUND_MOBILE && (L.unload(), L = null);
        for (var a = 0; a < NUM_PAYLINES; a++) B[a].unload();
        R && screenfull.enabled && H.unload();
        s_oInterface = null
    };
    this.refreshButtonPos = function(a, b) {
        P.setPosition(d - a, b + e);
        !1 !== DISABLE_SOUND_MOBILE && !1 !== s_bMobile || L.setPosition(u - a, b + z);
        v - a > CANVAS_WIDTH - 300 && (C.setPosition(v - a, E - b), M.x = k - a, M.y = l - b);
        R && screenfull.enabled && H.setPosition(q + a, p + b)
    };
    this._initPaylines = function() {
        var a =
            s_oSpriteLibrary.getSprite("bet_but4");
        B = [];
        var b = a.height / 2,
            c = 77 + b,
            d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but4"), "4", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 4);
        B[3] = d;
        c += 50;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but2"), "2", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 2);
        B[1] = d;
        c += 50;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but20"),
            "20", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 20);
        B[19] = d;
        c += 50;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but17"), "17", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 17);
        B[16] = d;
        c += 50;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but10"), "10", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked,
            this, 10);
        B[9] = d;
        c += 50;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but1"), "1", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 1);
        B[0] = d;
        c += 51;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but11"), "11", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 11);
        B[10] = d;
        c += 50;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but16"), "16",
            FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 16);
        B[15] = d;
        c += 50;
        d = new CBetBut(200 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but3"), "3", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 3);
        B[2] = d;
        d = new CBetBut(200 + a.width / 2, c + 50, s_oSpriteLibrary.getSprite("bet_but5"), "5", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked,
            this, 5);
        B[4] = d;
        c = 77 + b;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but12"), "12", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 12);
        B[11] = d;
        c += 50;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but14"), "14", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 14);
        B[13] = d;
        c += 50;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but9"),
            "9", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 9);
        B[8] = d;
        c += 50;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but18"), "18", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 18);
        B[17] = d;
        c += 50;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but6"), "6", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked,
            this, 6);
        B[5] = d;
        c += 51;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but7"), "7", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 7);
        B[6] = d;
        c += 50;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but19"), "19", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 19);
        B[18] = d;
        c += 50;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but8"), "8",
            FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 8);
        B[7] = d;
        c += 50;
        d = new CBetBut(1175 + a.width / 2, c, s_oSpriteLibrary.getSprite("bet_but13"), "13", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked, this, 13);
        B[12] = d;
        d = new CBetBut(1175 + a.width / 2, c + 50, s_oSpriteLibrary.getSprite("bet_but15"), "15", FONT_GAME_1, "#ffd202", 24, s_oAttachSection);
        d.addEventListenerWithParams(ON_MOUSE_UP, this._onBetLineClicked,
            this, 15);
        B[14] = d;
        K = [];
        for (a = 0; a < NUM_PAYLINES; a++) b = createBitmap(s_oSpriteLibrary.getSprite("payline_" + (a + 1))), b.visible = !1, s_oAttachSection.addChild(b), K[a] = b
    };
    this.refreshMoney = function(a) {
        x.text = TEXT_MONEY + ": " + a.toFixed(2) + TEXT_CURRENCY
    };
    this.refreshBet = function(a) {
        A.setText(TEXT_COIN + " " + a.toFixed(2))
    };
    this.refreshTotalBet = function(a) {
        J.text = TEXT_BET + ": " + a.toFixed(2) + TEXT_CURRENCY
    };
    this.refreshNumLines = function(a) {
        D.setText(TEXT_LINES + " " + a);
        for (var b = 0; b < NUM_PAYLINES; b++) b < a ? (B[b].setOn(), K[b].visible = !0) : B[b].setOff();
        setTimeout(function() {
            for (var a = 0; a < NUM_PAYLINES; a++) K[a].visible = !1
        }, 1E3)
    };
    this.resetWin = function() {
        I.text = TEXT_WIN + ": 0" + TEXT_CURRENCY
    };
    this.refreshWinText = function(a) {
        I.text = TEXT_WIN + ": " + a.toFixed(2) + TEXT_CURRENCY
    };
    this.refreshFreeSpinNum = function(a) {
        M.text = a
    };
    this.showLine = function(a) {
        K[a - 1].visible = !0
    };
    this.hideLine = function(a) {
        K[a - 1].visible = !1
    };
    this.hideAllLines = function() {
        for (var a = 0; a < NUM_PAYLINES; a++) K[a].visible = !1
    };
    this.disableBetBut = function(a) {
        for (var b = 0; b < NUM_PAYLINES; b++) B[b].disable(a)
    };
    this.enableGuiButtons = function() {
        C.enable();
        O.enable();
        A.enable();
        D.enable();
        N.enable()
    };
    this.enableSpin = function() {
        C.enable();
        O.enable()
    };
    this.disableSpin = function() {
        C.disable();
        O.disable()
    };
    this.disableGuiButtons = function() {
        C.getState() !== SPIN_BUT_STATE_FREESPIN && C.setState(SPIN_BUT_STATE_STOP);
        O.disable();
        A.disable();
        D.disable();
        N.disable()
    };
    this.toggleAutoSpinImage = function() {
        C.toggleAutoSpinImage()
    };
    this.setSpinState = function(a) {
        C.setState(a)
    };
    this._onBetLineClicked = function(a) {
        this.refreshNumLines(a);
        s_oGame.activateLines(a)
    };
    this._onExit = function() {
        s_oGame.onExit()
    };
    this._onSpin = function(a) {
        if (a === SPIN_BUT_STATE_AUTOSPIN) s_oGame.onAutoSpin();
        else if (a === SPIN_BUT_STATE_SPIN || a === SPIN_BUT_STATE_AUTOSPIN) s_oGame.onSpin();
        else if (a === SPIN_BUT_STATE_SKIP) s_oGame.onSkip();
        else s_oGame.forceStopReel()
    };
    this._onAddLine = function() {
        s_oGame.addLine()
    };
    this._onInfo = function() {
        s_oGame.onInfoClicked()
    };
    this._onBet = function() {
        s_oGame.changeCoinBet()
    };
    this._onMaxBet = function() {
        s_oGame.onMaxBet()
    };
    this.resetFullscreenBut =
        function() {
            R && screenfull.enabled && H.setActive(s_bFullscreen)
        };
    this._onFullscreenRelease = function() {
        s_bFullscreen ? T.call(window.document) : R.call(window.document.documentElement);
        sizeHandler()
    };
    this._onAudioToggle = function() {
        Howler.mute(s_bAudioActive);
        s_bAudioActive = !s_bAudioActive
    };
    this.update = function() {
        C.update()
    };
    s_oInterface = this;
    this._init(a, b, c);
    return this
}
var s_oInterface = null;

function CPayTablePanel() {
    var a, b, c, d, e, k, l, q, p, h, n, t;
    this._init = function() {
        c = 0;
        k = [];
        n = new createjs.Container;
        n.on("click", function() {});
        n.visible = !1;
        s_oAttachSection.addChild(n);
        var d = new createjs.Container;
        n.addChild(d);
        var g = createBitmap(s_oSpriteLibrary.getSprite("paytable1"));
        d.addChild(g);
        this._createPayouts(d);
        k[0] = d;
        d = new createjs.Container;
        d.visible = !1;
        n.addChild(d);
        g = createBitmap(s_oSpriteLibrary.getSprite("paytable2"));
        d.addChild(g);
        k[1] = d;
        l = k[c];
        d = new createjs.Container;
        d.visible = !1;
        n.addChild(d);
        g = createBitmap(s_oSpriteLibrary.getSprite("paytable3"));
        d.addChild(g);
        g = new createjs.Text(TEXT_HELP_BONUS1, "28px " + FONT_GAME_1, "#fff");
        g.textAlign = "center";
        g.x = 976;
        g.y = 264;
        g.lineWidth = 400;
        d.addChild(g);
        g = new createjs.Text(TEXT_HELP_BONUS2, "40px " + FONT_GAME_1, "#fff");
        g.textAlign = "center";
        g.x = 976;
        g.y = 430;
        g.lineWidth = 400;
        d.addChild(g);
        k[2] = d;
        d = new createjs.Container;
        d.visible = !1;
        n.addChild(d);
        g = createBitmap(s_oSpriteLibrary.getSprite("paytable4"));
        d.addChild(g);
        g = new createjs.Text(TEXT_HELP_FREESPIN,
            "40px " + FONT_GAME_1, "#fff");
        g.textAlign = "center";
        g.x = CANVAS_WIDTH / 2;
        g.y = 420;
        g.lineWidth = 400;
        d.addChild(g);
        k[3] = d;
        l = k[c];
        p = new CGfxButton(CANVAS_WIDTH - 290, CANVAS_HEIGHT - 160, s_oSpriteLibrary.getSprite("but_arrow_next"), n);
        p.addEventListener(ON_MOUSE_UP, this._onNext, this);
        h = new CGfxButton(290, CANVAS_HEIGHT - 160, s_oSpriteLibrary.getSprite("but_arrow_prev"), n);
        h.addEventListener(ON_MOUSE_UP, this._onPrev, this);
        d = s_oSpriteLibrary.getSprite("but_credits");
        a = d.width / 2 + 2;
        b = d.height / 2 + 2;
        t = new CGfxButton(a, b,
            d, n);
        t.addEventListener(ON_MOUSE_UP, this._onCredits, this);
        d = s_oSpriteLibrary.getSprite("but_exit_info");
        q = new CGfxButton(1220, 154, d, n);
        q.addEventListener(ON_MOUSE_UP, this._onExit, this)
    };
    this.unload = function() {
        n.off("click", function() {});
        q.unload();
        p.unload();
        h.unload();
        t.unload();
        s_oAttachSection.removeChild(n);
        for (var a = 0; a < d.length; a++) n.removeChild(d[a]);
        for (a = 0; a < e.length; a++) n.removeChild(e[a])
    };
    this._createPayouts = function(a) {
        d = [];
        e = [];
        for (var b = [{
                x: 544,
                y: 266
            }, {
                x: 764,
                y: 266
            }, {
                x: 984,
                y: 266
            }, {
                x: 435,
                y: 376
            }, {
                x: 655,
                y: 376
            }, {
                x: 875,
                y: 376
            }, {
                x: 1095,
                y: 376
            }, {
                x: 544,
                y: 486
            }, {
                x: 764,
                y: 486
            }, {
                x: 984,
                y: 486
            }], c = 0, k = 0; k < s_aSymbolWin.length; k++) {
            var h = s_aSymbolWin[k];
            do {
                var l = h.indexOf(0); - 1 !== l && h.splice(l, 1)
            } while (-1 !== l);
            l = h.length;
            if (0 !== l) {
                var m = 24;
                4 === l && (m = 18);
                var n = b[c].y;
                d[k] = [];
                e[k] = [];
                for (var p = 0; p < l; p++) {
                    var q = new createjs.Text("X" + (5 - p), "21px " + FONT_GAME_1, "#ffffff");
                    q.textAlign = "center";
                    q.x = b[c].x;
                    q.y = n;
                    q.textBaseline = "alphabetic";
                    a.addChild(q);
                    d[k][p] = q;
                    var t = new createjs.Text(h[l - p - 1], "21px " + FONT_GAME_1,
                        "#ffff00");
                    t.textAlign = "center";
                    t.x = q.x + 50;
                    t.y = q.y;
                    t.textBaseline = "alphabetic";
                    a.addChild(t);
                    e[k][p] = t;
                    n += m
                }
                c++
            }
        }
    };
    this._onNext = function() {
        c === k.length - 1 ? c = 0 : c++;
        l.visible = !1;
        k[c].visible = !0;
        l = k[c]
    };
    this._onPrev = function() {
        0 === c ? c = k.length - 1 : c--;
        l.visible = !1;
        k[c].visible = !0;
        l = k[c]
    };
    this._onCredits = function() {
        new CCreditsPanel
    };
    this.refreshButtonPos = function(c, d) {
        t.setPosition(a + c, b + d)
    };
    this.show = function() {
        c = 0;
        l.visible = !1;
        k[c].visible = !0;
        l = k[c];
        n.visible = !0
    };
    this.hide = function() {
        n.visible = !1
    };
    this.resetHighlightCombo =
        function() {
            for (var a = 0; a < d.length; a++)
                if (void 0 !== d[a])
                    for (var b = 0; b < d[a].length; b++) d[a][b].color = "#ffffff", e[a][b].color = "#ffff00", createjs.Tween.removeTweens(e[a][b]), e[a][b].alpha = 1
        };
    this.highlightCombo = function(a, b) {
        e[a - 1][NUM_REELS - b].color = "#ff9000";
        this.tweenAlpha(e[a - 1][NUM_REELS - b], 0)
    };
    this.tweenAlpha = function(a, b) {
        var c = this;
        createjs.Tween.get(a).to({
            alpha: b
        }, 200).call(function() {
            1 === b ? c.tweenAlpha(a, 0) : c.tweenAlpha(a, 1)
        })
    };
    this._onExit = function() {
        s_oGame.hidePayTable()
    };
    this.isVisible =
        function() {
            return n.visible
        };
    this._init()
}

function CStaticSymbolCell(a, b, c, d) {
    var e, k, l, q, p = -1,
        h, n, t, m, g, r, v;
    this._init = function(a, b, c, d) {
        l = c;
        q = d;
        e = 0;
        v = new createjs.Container;
        v.visible = !1;
        s_oAttachSection.addChild(v);
        r = new createjs.Container;
        r.visible = !1;
        r.x = c;
        r.y = d;
        v.addChild(r);
        h = [];
        for (a = 0; a < NUM_SYMBOLS; a++) b = createSprite(s_aSymbolAnims[a], "static", 0, 0, SYMBOL_ANIM_WIDTH, SYMBOL_ANIM_HEIGHT), b.stop(), b.on("animationend", this._onAnimEnded, null, !1), r.addChild(b), h[a] = b, h[a].visible = !1;
        a = s_oSpriteLibrary.getSprite("amount_win_bg");
        g = createBitmap(a);
        g.regX = a.width / 2;
        g.regY = a.height / 2;
        g.x = SYMBOL_ANIM_WIDTH / 2;
        g.y = SYMBOL_ANIM_HEIGHT;
        r.addChild(g);
        m = new createjs.Text("", "48px " + FONT_GAME_1, "#000");
        m.textAlign = "center";
        m.textBaseline = "alphabetic";
        m.x = SYMBOL_ANIM_WIDTH / 2 + 2;
        m.y = SYMBOL_ANIM_HEIGHT + 17;
        r.addChild(m);
        t = new createjs.Text("", "48px " + FONT_GAME_1, "#ffd102");
        t.textAlign = "center";
        t.textBaseline = "alphabetic";
        t.x = SYMBOL_ANIM_WIDTH / 2;
        t.y = SYMBOL_ANIM_HEIGHT + 15;
        r.addChild(t);
        a = {
            framerate: 20,
            images: [s_oSpriteLibrary.getSprite("win_frame_anim")],
            frames: {
                width: SYMBOL_WIDTH,
                height: SYMBOL_HEIGHT
            },
            animations: {
                "static": [0],
                anim: [1, 19]
            }
        };
        a = new createjs.SpriteSheet(a);
        n = new createjs.Sprite(a, "static", 0, 0, SYMBOL_WIDTH, SYMBOL_HEIGHT);
        n.stop();
        n.x = c;
        n.y = d;
        v.addChild(n)
    };
    this.unload = function() {
        s_oAttachSection.removeChild(v)
    };
    this.hide = function() {
        if (-1 < p) {
            var a = p + 1;
            9 === a || 10 === a || 11 === a ? stopSound("symbol9_10_11") : stopSound("symbol" + a);
            n.gotoAndStop("static");
            n.visible = !1;
            g.visible = !1;
            t.text = "";
            m.text = "";
            h[p].gotoAndPlay("static");
            h[p].visible = !1;
            v.visible = !1;
            p = -1
        }
    };
    this.show =
        function(a, b, c, d, n) {
            e = 0;
            k = n;
            for (n = 0; n < NUM_SYMBOLS; n++) h[n].visible = n + 1 === a ? !0 : !1;
            g.visible = !1;
            0 < b && (t.text = "x" + b, m.text = "x" + b, g.visible = !0);
            h[a - 1].gotoAndPlay("anim");
            p = a - 1;
            h[a - 1].spriteSheet.getNumFrames();
            r.regX = d.x;
            r.regY = d.y;
            r.x = l + c.x;
            r.y = q + c.y;
            r.scaleX = r.scaleY = .5;
            r.visible = !0;
            r.alpha = 1;
            v.visible = !0;
            createjs.Tween.get(r).to({
                scaleX: 1,
                scaleY: 1
            }, 1500, createjs.Ease.cubicOut);
            9 === a || 10 === a || 11 === a ? playSound("symbol9_10_11", 1, !1) : playSound("symbol" + a, 1, !1)
        };
    this.showWinFrame = function() {
        n.gotoAndPlay("anim");
        n.visible = !0;
        v.visible = !0
    };
    this.hideWinFrame = function() {
        n.gotoAndPlay("static");
        n.visible = !1;
        v.visible = !1
    };
    this._onAnimEnded = function() {
        e++;
        e === k && -1 < p && (h[p].stop(), createjs.Tween.get(r).to({
            scaleX: .52,
            scaleY: .52,
            alpha: 0
        }, 500, createjs.Ease.cubicOut).call(function() {
            E.stopAnim();
            s_oGame.showWin()
        }))
    };
    this.stopAnim = function() {
        var a = p + 1;
        9 === a || 10 === a || 11 === a ? stopSound("symbol9_10_11") : stopSound("symbol" + a);
        h[p].visible = !1;
        r.visible = !1;
        n.gotoAndStop("static");
        n.visible = !1
    };
    var E = this;
    this._init(a, b,
        c, d)
}

function CTweenController() {
    this.tweenValue = function(a, b, c) {
        return a + c * (b - a)
    };
    this.easeLinear = function(a, b, c, d) {
        return c * a / d + b
    };
    this.easeInCubic = function(a, b, c, d) {
        d = (a /= d) * a * a;
        return b + c * d
    };
    this.easeBackInQuart = function(a, b, c, d) {
        d = (a /= d) * a;
        return b + c * (2 * d * d + 2 * d * a + -3 * d)
    };
    this.easeInBack = function(a, b, c, d) {
        return c * (a /= d) * a * (2.70158 * a - 1.70158) + b
    };
    this.easeOutCubic = function(a, b, c, d) {
        return c * ((a = a / d - 1) * a * a + 1) + b
    };
    this.getTrajectoryPoint = function(a, b) {
        var c = new createjs.Point,
            d = (1 - a) * (1 - a),
            e = a * a;
        c.x = d *
            b.start.x + 2 * (1 - a) * a * b.traj.x + e * b.end.x;
        c.y = d * b.start.y + 2 * (1 - a) * a * b.traj.y + e * b.end.y;
        return c
    }
}

function CMsgBox() {
    var a, b, c, d, e;
    this._init = function() {
        e = new createjs.Container;
        e.visible = !1;
        s_oStage.addChild(e);
        a = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        e.addChild(a);
        c = new createjs.Text("", "30px " + FONT_GAME_1, "#000");
        c.x = CANVAS_WIDTH / 2 + 2;
        c.y = CANVAS_HEIGHT / 2 - 48;
        c.lineWidth = 400;
        c.textAlign = "center";
        e.addChild(c);
        b = new createjs.Text("", "30px " + FONT_GAME_1, "#ffffff");
        b.x = CANVAS_WIDTH / 2;
        b.y = CANVAS_HEIGHT / 2 - 50;
        b.textAlign = "center";
        b.lineWidth = 400;
        e.addChild(b);
        d = new CGfxButton(CANVAS_WIDTH /
            2 + 210, CANVAS_HEIGHT / 2 - 110, s_oSpriteLibrary.getSprite("but_exit_info"), e);
        d.addEventListener(ON_MOUSE_UP, this._onExit, this)
    };
    this.show = function(a) {
        c.text = a;
        b.text = a;
        e.visible = !0
    };
    this.hide = function() {
        e.visible = !1
    };
    this._onExit = function() {
        this.hide()
    };
    this._init();
    return this
}

function CBonusPanel() {
    var a, b = !1,
        c = !1,
        d, e, k, l, q, p, h, n, t, m, g, r, v, E, u, z, B, K, P, C, N, D, L, A;
    this._init = function() {
        a = !1;
        b = !0;
        d = -1;
        A.removeAllChildren();
        var c = createBitmap(s_oSpriteLibrary.getSprite("bg_bonus"));
        A.addChild(c);
        c = s_oSpriteLibrary.getSprite("ball_shadow");
        z = createBitmap(c);
        z.x = CANVAS_WIDTH / 2 - 100;
        z.y = CANVAS_HEIGHT - 330;
        A.addChild(z);
        B = new CBonusBall(CANVAS_WIDTH / 2, 538, A);
        c = s_oSpriteLibrary.getSprite("but_goal");
        m = new CGfxButton(425, 155, c, A);
        m.addEventListenerWithParams(ON_MOUSE_UP, this._onShot,
            this, BONUS_BUTTON_1);
        g = new CGfxButton(495, 235, c, A);
        g.addEventListenerWithParams(ON_MOUSE_UP, this._onShot, this, BONUS_BUTTON_2);
        r = new CGfxButton(565, 315, c, A);
        r.addEventListenerWithParams(ON_MOUSE_UP, this._onShot, this, BONUS_BUTTON_3);
        v = new CGfxButton(1080, 155, c, A);
        v.addEventListenerWithParams(ON_MOUSE_UP, this._onShot, this, BONUS_BUTTON_4);
        E = new CGfxButton(1010, 235, c, A);
        E.addEventListenerWithParams(ON_MOUSE_UP, this._onShot, this, BONUS_BUTTON_5);
        u = new CGfxButton(940, 315, c, A);
        u.addEventListenerWithParams(ON_MOUSE_UP,
            this._onShot, this, BONUS_BUTTON_6);
        K = new CBonusGoalkeeper(A);
        P = new CBonusPlayer(646, 0, A);
        this._startBonus()
    };
    this._loadAllResources = function() {
        A = new createjs.Container;
        A.on("click", function() {});
        s_oAttachSection.addChild(A);
        var a = s_oSpriteLibrary.getSprite("bg_loading_bonus");
        N = createBitmap(a);
        A.addChild(N);
        a = s_oSpriteLibrary.getSprite("progress_bar");
        L = createBitmap(a);
        L.x = CANVAS_WIDTH / 2 - a.width / 2;
        L.y = CANVAS_HEIGHT - 170;
        A.addChild(L);
        q = a.width;
        p = a.height;
        t = new createjs.Shape;
        t.graphics.beginFill("rgba(255,255,255,0.01)").drawRect(L.x,
            L.y, 1, p);
        A.addChild(t);
        L.mask = t;
        D = new createjs.Text("", "30px " + FONT_GAME_1, "#fff");
        D.x = CANVAS_WIDTH / 2;
        D.y = CANVAS_HEIGHT - 125;
        D.shadow = new createjs.Shadow("#000", 2, 2, 2);
        D.textBaseline = "alphabetic";
        D.textAlign = "center";
        A.addChild(D);
        s_oSpriteLibrary.init(this._onResourceBonusLoaded, this._onAllImagesLoaded, this);
        s_oSpriteLibrary.addSprite("bg_bonus", "./sprites/bonus/bg_bonus.jpg");
        s_oSpriteLibrary.addSprite("ball_shadow", "./sprites/bonus/ball_shadow.png");
        s_oSpriteLibrary.addSprite("but_goal", "./sprites/bonus/but_goal.png");
        s_oSpriteLibrary.addSprite("ball_anim", "./sprites/bonus/ball_anim.png");
        s_oSpriteLibrary.addSprite("bonus_panel_bg", "./sprites/bonus/bonus_panel_bg.png");
        for (a = 0; 23 > a; a++) s_oSpriteLibrary.addSprite("gk_idle_" + a, "./sprites/bonus/goalkeeper_idle/gk_idle_" + a + ".png");
        for (a = 0; 33 > a; a++) s_oSpriteLibrary.addSprite("gk_save_left_" + a, "./sprites/bonus/goalkeeper_save_left/gk_save_left_" + a + ".png"), s_oSpriteLibrary.addSprite("gk_save_right_" + a, "./sprites/bonus/goalkeeper_save_right/gk_save_right_" + a + ".png");
        for (a =
            0; 30 > a; a++) s_oSpriteLibrary.addSprite("player_" + a, "./sprites/bonus/player/player_" + a + ".png");
        h = 0;
        n = s_oSpriteLibrary.getNumSprites();
        s_oSpriteLibrary.loadSprites();
        c = !0
    };
    this._onResourceBonusLoaded = function() {
        h++;
        var a = Math.floor(h / n * 100);
        D.text = a + "%";
        t.graphics.clear();
        a = Math.floor(a * q / 100);
        t.graphics.beginFill("rgba(255,255,255,0.01)").drawRect(L.x, L.y, a, p);
        h === n && this._init()
    };
    this._onAllImagesLoaded = function() {};
    this.show = function(a) {
        e = a;
        b ? this._startBonus() : this._loadAllResources();
        $(s_oMain).trigger("bonus_start")
    };
    this.hide = function() {
        a = !1;
        A.off("click", function() {});
        A.visible = !1;
        C.unload();
        this._enableAllButtons();
        c = !1
    };
    this._startBonus = function() {
        z.visible = !0;
        K.show();
        A.on("click", function() {});
        a = A.visible = !0;
        d = STATE_BONUS_IDLE
    };
    this._enableAllButtons = function() {
        g.setVisible(!0);
        E.setVisible(!0);
        r.setVisible(!0);
        u.setVisible(!0);
        m.setVisible(!0);
        v.setVisible(!0)
    };
    this._disableAllButtons = function() {
        g.setVisible(!1);
        E.setVisible(!1);
        r.setVisible(!1);
        u.setVisible(!1);
        m.setVisible(!1);
        v.setVisible(!1)
    };
    this._onShot =
        function(a) {
            s_oBonusPanel._disableAllButtons();
            switch (a) {
                case BONUS_BUTTON_1:
                    k = m.getX();
                    l = m.getY();
                    break;
                case BONUS_BUTTON_2:
                    k = g.getX();
                    l = g.getY();
                    break;
                case BONUS_BUTTON_3:
                    k = r.getX();
                    l = r.getY();
                    break;
                case BONUS_BUTTON_4:
                    k = v.getX();
                    l = v.getY();
                    break;
                case BONUS_BUTTON_5:
                    k = E.getX();
                    l = E.getY();
                    break;
                case BONUS_BUTTON_6:
                    k = u.getX(), l = u.getY()
            }
            d = STATE_BONUS_KICK;
            P.show()
        };
    this.kick = function() {
        playSound("kick", 1, !1);
        z.visible = !1;
        B.show(k, l);
        K.dive(Math.round(Math.random() + 1))
    };
    this.ballArrived = function() {
        d =
            STATE_BONUS_WIN;
        new CScoreText(e, k, l);
        setTimeout(function() {
            C = new CBonusResultPanel(e, A)
        }, 2E3)
    };
    this.unload = function() {
        this.hide();
        s_oGame.exitFromBonus()
    };
    this.isVisible = function() {
        return c
    };
    this.update = function() {
        if (a) switch (d) {
            case STATE_BONUS_IDLE:
                K.update();
                break;
            case STATE_BONUS_KICK:
                K.update(), P.update(), B.update()
        }
    };
    s_oBonusPanel = this
}
var s_oBonusPanel = null,
    s_aSession = [];
NUM_ROWS = 3;
NUM_REELS = 5;
var _aFinalSymbols = [],
    _aPaylineCombo = [];
_aPaylineCombo = _initPaylines();
var _aSymbolWin = [],
    _iNumSymbolFreeSpin = 0;
s_aSession.bBonus = 0;

function _initSettings() {
    s_aSession.iMoney = TOTAL_MONEY;
    s_aSession.iSlotCash = SLOT_CASH;
    s_aSession.win_occurrence = WIN_OCCURRENCE;
    s_aSession.freespin_occurrence = FREESPIN_OCCURRENCE;
    s_aSession.bonus_occurrence = BONUS_OCCURRENCE;
    s_aSession.freespin_symbol_num_occur = FREESPIN_SYMBOL_NUM_OCCURR;
    s_aSession.num_freespin = NUM_FREESPIN;
    s_aSession.bonus_prize = BONUS_PRIZE;
    s_aSession.bonus_prize_occur = BONUS_PRIZE_OCCURR;
    s_aSession.coin_bet = COIN_BET;
    _aSymbolWin = _initSymbolWin()
}

function checkLogin() {
    s_aSession.iTotFreeSpin = 0;
    s_aSession.bFreeSpin = 0;
    _initSettings();
    _setMinWin();
    return _tryToCheckLogin()
}

function callSpin(a, b, c) {
    return _onSpin(a, b, c)
}

function _tryToCheckLogin() {
    for (var a = [], b = 0; b < _aSymbolWin.length; b++) a[b] = _aSymbolWin[b].join(",");
    return "res=true&login=true&money=" + s_aSession.iMoney + "&bonus_prize=" + s_aSession.bonus_prize.join("#") + "&paytable=" + a.join("#") + "&coin_bet=" + s_aSession.coin_bet.join("#")
}

function _setMinWin() {
    s_aSession.min_win = 9999999999999;
    for (var a = 0; a < _aSymbolWin.length; a++)
        for (var b = _aSymbolWin[a], c = 0; c < b.length; c++) 0 !== b[c] && b[c] < s_aSession.min_win && (s_aSession.min_win = b[c])
}

function _onSpin(a, b, c) {
    if (c > s_aSession.iMoney) _dieError("INVALID BET: " + c + ",money:" + s_aSession.iMoney);
    else {
        s_aSession.iMoney -= c;
        s_aSession.iSlotCash += c;
        var d = s_aSession.bBonus = 0,
            e = 0;
        if (s_aSession.iSlotCash < s_aSession.min_win * b) return generLosingPattern(), 1 === s_aSession.bFreeSpin && (--s_aSession.iTotFreeSpin, 0 > s_aSession.iTotFreeSpin && (s_aSession.iTotFreeSpin = 0, s_aSession.bFreeSpin = 0)), $(s_oMain).trigger("bet_placed", {
                bet: b,
                tot_bet: c,
                payline: a,
                amount_win: 0
            }), "res=true&win=false&pattern=" + JSON.stringify(_aFinalSymbols) +
            "&money=" + s_aSession.iMoney + "&freespin=0&num_freespin=" + s_aSession.iTotFreeSpin + "&bonus=false&bonus_prize=-1&cash=" + s_aSession.iSlotCash;
        if (Math.floor(100 * Math.random()) < s_aSession.win_occurrence) {
            if (0 === s_aSession.bFreeSpin && 0 === s_aSession.bBonus) {
                var k = Math.floor(100 * Math.random());
                0 === s_aSession.iTotFreeSpin && k < s_aSession.freespin_occurrence + s_aSession.bonus_occurrence && (k = Math.floor(Math.random() * (s_aSession.freespin_occurrence + s_aSession.bonus_occurrence) + 1), k <= s_aSession.freespin_occurrence ?
                    d = 1 : e = s_aSession.iSlotCash >= s_aSession.bonus_prize[0] * b ? 1 : 0)
            }
            var l, q = 0;
            do {
                generateRandomSymbols(d, e);
                k = checkWin(d, e, a);
                var p = 0;
                for (l = 0; l < k.length; l++) p += k[l].amount;
                p *= b;
                var h = 0;
                l = -1;
                if (1 === e) {
                    s_aSession.bBonus = 1;
                    l = [];
                    for (h = 0; h < s_aSession.bonus_prize_occur.length; h++)
                        for (var n = s_aSession.bonus_prize_occur[h], t = 0; t < n; t++) l.push(h);
                    l = l[Math.floor(Math.random() * l.length)];
                    h = s_aSession.bonus_prize[l] * b
                }
                q++
            } while (0 === k.length || h + p > s_aSession.iSlotCash || h + p < c);
            s_aSession.iMoney = s_aSession.iMoney + p + h;
            s_aSession.iSlotCash =
                s_aSession.iSlotCash - p - h;
            1 === d && 2 < _iNumSymbolFreeSpin ? (s_aSession.bFreeSpin = 1, s_aSession.iTotFreeSpin = s_aSession.num_freespin[_iNumSymbolFreeSpin - 3]) : 1 === s_aSession.bFreeSpin && (--s_aSession.iTotFreeSpin, 0 > s_aSession.iTotFreeSpin && (s_aSession.iTotFreeSpin = 0, s_aSession.bFreeSpin = 0));
            e = p + h;
            $(s_oMain).trigger("bet_placed", {
                bet: b,
                tot_bet: c,
                payline: a,
                amount_win: e
            });
            return "res=true&win=true&pattern=" + JSON.stringify(_aFinalSymbols) + "&win_lines=" + JSON.stringify(k) + "&money=" + s_aSession.iMoney + "&tot_win=" + p +
                "&freespin=" + d + "&num_freespin=" + s_aSession.iTotFreeSpin + "&bonus=" + s_aSession.bBonus + "&bonus_prize=" + l + "&cash=" + s_aSession.iSlotCash
        }
        generLosingPattern();
        1 === s_aSession.bFreeSpin && (--s_aSession.iTotFreeSpin, 0 > s_aSession.iTotFreeSpin && (s_aSession.iTotFreeSpin = 0, s_aSession.bFreeSpin = 0));
        $(s_oMain).trigger("bet_placed", {
            bet: b,
            tot_bet: c,
            payline: a,
            amount_win: 0
        });
        return "res=true&win=false&pattern=" + JSON.stringify(_aFinalSymbols) + "&money=" + s_aSession.iMoney + "&freespin=0&num_freespin=" + s_aSession.iTotFreeSpin +
            "&bonus=false&bonus_prize=-1"
    }
}

function _initPaylines() {
    _aPaylineCombo[0] = [{
        row: 1,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 1,
        col: 4
    }];
    _aPaylineCombo[1] = [{
        row: 0,
        col: 0
    }, {
        row: 0,
        col: 1
    }, {
        row: 0,
        col: 2
    }, {
        row: 0,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    _aPaylineCombo[2] = [{
        row: 2,
        col: 0
    }, {
        row: 2,
        col: 1
    }, {
        row: 2,
        col: 2
    }, {
        row: 2,
        col: 3
    }, {
        row: 2,
        col: 4
    }];
    _aPaylineCombo[3] = [{
        row: 0,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 2,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    _aPaylineCombo[4] = [{
        row: 2,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 0,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 2,
        col: 4
    }];
    _aPaylineCombo[5] = [{
        row: 1,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 2,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 1,
        col: 4
    }];
    _aPaylineCombo[6] = [{
        row: 1,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 0,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 1,
        col: 4
    }];
    _aPaylineCombo[7] = [{
        row: 2,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 2,
        col: 4
    }];
    _aPaylineCombo[8] = [{
        row: 0,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    _aPaylineCombo[9] = [{
        row: 1,
        col: 0
    }, {
        row: 0,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 0,
        col: 3
    }, {
        row: 1,
        col: 4
    }];
    _aPaylineCombo[10] = [{
        row: 1,
        col: 0
    }, {
        row: 2,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 2,
        col: 3
    }, {
        row: 1,
        col: 4
    }];
    _aPaylineCombo[11] = [{
        row: 0,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 0,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    _aPaylineCombo[12] = [{
        row: 2,
        col: 0
    }, {
        row: 1,
        col: 1
    }, {
        row: 2,
        col: 2
    }, {
        row: 1,
        col: 3
    }, {
        row: 2,
        col: 4
    }];
    _aPaylineCombo[13] = [{
        row: 0,
        col: 0
    }, {
        row: 0,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 0,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    _aPaylineCombo[14] = [{
        row: 2,
        col: 0
    }, {
        row: 2,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 2,
        col: 3
    }, {
        row: 2,
        col: 4
    }];
    _aPaylineCombo[15] = [{
        row: 2,
        col: 0
    }, {
        row: 2,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 0,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    _aPaylineCombo[16] = [{
        row: 0,
        col: 0
    }, {
        row: 0,
        col: 1
    }, {
        row: 1,
        col: 2
    }, {
        row: 2,
        col: 3
    }, {
        row: 2,
        col: 4
    }];
    _aPaylineCombo[17] = [{
        row: 0,
        col: 0
    }, {
        row: 0,
        col: 1
    }, {
        row: 2,
        col: 2
    }, {
        row: 0,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    _aPaylineCombo[18] = [{
        row: 2,
        col: 0
    }, {
        row: 2,
        col: 1
    }, {
        row: 0,
        col: 2
    }, {
        row: 2,
        col: 3
    }, {
        row: 2,
        col: 4
    }];
    _aPaylineCombo[19] = [{
        row: 0,
        col: 0
    }, {
        row: 2,
        col: 1
    }, {
        row: 2,
        col: 2
    }, {
        row: 2,
        col: 3
    }, {
        row: 0,
        col: 4
    }];
    return _aPaylineCombo
}

function _initSymbolWin() {
    _aSymbolWin[0] = [0, 0, 0, 0, 0];
    _aSymbolWin[1] = PAYTABLE_VALUES[1];
    _aSymbolWin[2] = PAYTABLE_VALUES[2];
    _aSymbolWin[3] = PAYTABLE_VALUES[3];
    _aSymbolWin[4] = PAYTABLE_VALUES[4];
    _aSymbolWin[5] = PAYTABLE_VALUES[5];
    _aSymbolWin[6] = PAYTABLE_VALUES[6];
    _aSymbolWin[7] = PAYTABLE_VALUES[7];
    _aSymbolWin[8] = PAYTABLE_VALUES[8];
    _aSymbolWin[9] = PAYTABLE_VALUES[9];
    _aSymbolWin[10] = PAYTABLE_VALUES[10];
    _aSymbolWin[11] = [0, 0, 0, 0, 0];
    _aSymbolWin[12] = [0, 0, 0, 0, 0];
    return _aSymbolWin
}

function generLosingPattern() {
    for (var a = [], b = 0; b < NUM_ROWS; b++) {
        do var c = Math.floor(Math.random() * s_aRandSymbols.length); while (s_aRandSymbols[c] === BONUS_SYMBOL || s_aRandSymbols[c] === FREESPIN_SYMBOL || s_aRandSymbols[c] === WILD_SYMBOL);
        c = s_aRandSymbols[c];
        a[b] = c
    }
    for (b = 0; b < NUM_ROWS; b++) {
        _aFinalSymbols[b] = [];
        for (var d = 0; d < NUM_REELS; d++)
            if (0 == d) _aFinalSymbols[b][d] = a[b];
            else {
                do c = Math.floor(Math.random() * s_aRandSymbols.length), c = s_aRandSymbols[c]; while (a[0] === c || a[1] === c || a[2] === c || c === BONUS_SYMBOL || c === FREESPIN_SYMBOL ||
                    c === WILD_SYMBOL);
                _aFinalSymbols[b][d] = c
            }
    }
}

function generateRandomSymbols(a, b) {
    for (var c = 0; c < NUM_ROWS; c++) {
        _aFinalSymbols[c] = [];
        for (var d = 0; d < NUM_REELS; d++) {
            do iRandSymbol = s_aRandSymbols[Math.floor(Math.random() * s_aRandSymbols.length)], _aFinalSymbols[c][d] = iRandSymbol; while (iRandSymbol === BONUS_SYMBOL || iRandSymbol === FREESPIN_SYMBOL)
        }
    }
    if (1 === a) {
        var e = [];
        for (c = 0; c < s_aSession.freespin_symbol_num_occur.length; c++)
            for (d = 0; d < s_aSession.freespin_symbol_num_occur[c]; d++) e.push(c);
        _iNumSymbolFreeSpin = 3 + e[Math.floor(Math.random() * e.length)];
        c = [0, 1, 2,
            3, 4
        ];
        c = shuffle(c);
        for (d = 0; d < _iNumSymbolFreeSpin; d++) e = Math.floor(3 * Math.random()), _aFinalSymbols[e][c[d]] = FREESPIN_SYMBOL
    } else if (1 === b) {
        c = [0, 1, 2, 3, 4];
        c = shuffle(c);
        var k = Math.floor(3 * Math.random() + 3);
        for (d = 0; d < k; d++) e = Math.floor(3 * Math.random()), _aFinalSymbols[e][c[d]] = BONUS_SYMBOL
    }
}

function checkWin(a, b, c) {
    for (var d = [], e = 0; e < c; e++) {
        var k = _aPaylineCombo[e],
            l = [],
            q = _aFinalSymbols[k[0].row][k[0].col],
            p = 1,
            h = 1;
        for (l.push({
                row: k[0].row,
                col: k[0].col,
                value: _aFinalSymbols[k[0].row][k[0].col]
            }); q === WILD_SYMBOL && h < NUM_REELS;) p++, q = _aFinalSymbols[k[h].row][k[h].col], l.push({
            row: k[h].row,
            col: k[h].col,
            value: _aFinalSymbols[k[h].row][k[h].col]
        }), h++;
        for (; h < k.length; h++)
            if (_aFinalSymbols[k[h].row][k[h].col] === q || _aFinalSymbols[k[h].row][k[h].col] === WILD_SYMBOL) p++, l.push({
                row: k[h].row,
                col: k[h].col,
                value: _aFinalSymbols[k[h].row][k[h].col]
            });
            else break;
        !(0 < _aSymbolWin[q - 1][p - 1]) || 1 === a && q === FREESPIN_SYMBOL || 1 === b && q === BONUS_SYMBOL || (l.sort(sortListByCol), d.push({
            line: e + 1,
            amount: _aSymbolWin[q - 1][p - 1],
            num_win: p,
            value: q,
            list: l
        }))
    }
    if (1 === a) {
        l = [];
        for (a = 0; a < NUM_ROWS; a++)
            for (b = 0; b < NUM_REELS; b++) _aFinalSymbols[a][b] === FREESPIN_SYMBOL && l.push({
                row: a,
                col: b,
                value: FREESPIN_SYMBOL
            });
        l.sort(sortListByCol);
        d.push({
            line: 0,
            amount: 0,
            num_win: l.length,
            value: FREESPIN_SYMBOL,
            list: l
        })
    } else if (1 === b) {
        l = [];
        for (a = 0; a <
            NUM_ROWS; a++)
            for (b = 0; b < NUM_REELS; b++) _aFinalSymbols[a][b] === BONUS_SYMBOL && l.push({
                row: a,
                col: b,
                value: BONUS_SYMBOL
            });
        l.sort(sortListByCol);
        d.push({
            line: 0,
            amount: 0,
            num_win: l.length,
            value: BONUS_SYMBOL,
            list: l
        })
    }
    return d
}

function shuffle(a) {
    for (var b, c, d = a.length; d; b = Math.floor(Math.random() * d), c = a[--d], a[d] = a[b], a[b] = c);
    return a
}

function sortListByCol(a, b) {
    return a.col < b.col ? -1 : a.col > b.col ? 1 : 0
}

function _dieError(a) {
    return "res=false&desc=" + a
}

function CSpinBut(a, b, c, d, e, k) {
    var l = !1,
        q = !1,
        p, h, n, t, m, g, r;
    this._init = function(a, b, c, d, e) {
        t = [];
        m = [];
        g = new createjs.Container;
        g.x = a;
        g.y = b;
        g.regX = Math.floor(d / 2);
        g.regY = Math.floor(e / 2);
        g.cursor = "pointer";
        v.addChild(g);
        a = new createjs.SpriteSheet({
            framerate: 1,
            images: [c],
            frames: {
                width: d,
                height: e
            },
            animations: {
                spin: [0],
                stop: [1],
                autospin: [2],
                skip: [3],
                freespin: [4],
                disable: [5]
            }
        });
        r = createSprite(a, "spin", 0, 0, d, e);
        r.stop();
        g.addChild(r);
        p = e;
        n = SPIN_BUT_STATE_SPIN;
        this._initListener()
    };
    this.enable = function() {
        l = !1;
        r.gotoAndStop(n)
    };
    this.disable = function() {
        l = !0
    };
    this.setState = function(a) {
        r.gotoAndStop(a);
        a !== SPIN_BUT_STATE_STOP && (n = a)
    };
    this.toggleAutoSpinImage = function() {
        r.currentAnimation === SPIN_BUT_STATE_SPIN ? r.gotoAndStop(SPIN_BUT_STATE_AUTOSPIN) : r.gotoAndStop(SPIN_BUT_STATE_SPIN)
    };
    this._initListener = function() {
        g.on("mousedown", this.buttonDown);
        g.on("pressup", this.buttonRelease)
    };
    this.unload = function() {
        g.off("mousedown", this.buttonDown);
        g.off("pressup", this.buttonRelease);
        v.removeChild(g)
    };
    this.setVisible =
        function(a) {
            g.visible = a
        };
    this.addEventListener = function(a, b, c) {
        t[a] = b;
        m[a] = c
    };
    this.buttonRelease = function() {
        !1 === q || l || (q = !1, t[ON_MOUSE_UP] && t[ON_MOUSE_UP].call(m[ON_MOUSE_UP], r.currentAnimation))
    };
    this.buttonDown = function() {
        l || (h = 0, q = !0, t[ON_MOUSE_DOWN] && t[ON_MOUSE_DOWN].call(m[ON_MOUSE_DOWN]))
    };
    this.setPosition = function(a, b) {
        g.x = a;
        g.y = b
    };
    this.setX = function(a) {
        g.x = a
    };
    this.setY = function(a) {
        g.y = a
    };
    this.getButtonImage = function() {
        return g
    };
    this.getX = function() {
        return g.x
    };
    this.getY = function() {
        return g.y
    };
    this.getHeight = function() {
        return p
    };
    this.getSprite = function() {
        return g
    };
    this.getState = function() {
        return r.currentAnimation
    };
    this.update = function() {
        !1 !== q && (h += s_iTimeElaps, h > TIME_HOLD_AUTOSPIN && (h = 0, q = !1, t[ON_MOUSE_UP] && t[ON_MOUSE_UP].call(m[ON_MOUSE_UP], r.currentAnimation, !0)))
    };
    var v = k;
    this._init(a, b, c, d, e);
    return this
}

function CBonusGoalkeeper(a) {
    var b = !1,
        c, d, e, k, l, q, p, h, n, t;
    this._init = function() {
        p = new createjs.Container;
        m.addChild(p);
        h = new createjs.Container;
        h.x = 650;
        h.y = 160;
        p.addChild(h);
        n = new createjs.Container;
        n.visible = !1;
        n.x = 292;
        n.y = 132;
        p.addChild(n);
        t = new createjs.Container;
        t.visible = !1;
        t.x = 662;
        t.y = 132;
        p.addChild(t);
        q = [
            [],
            [],
            []
        ];
        for (var a = 0; 23 > a; a++) {
            var b = createBitmap(s_oSpriteLibrary.getSprite("gk_idle_" + a));
            h.addChild(b);
            q[0].push(b);
            0 < a && (b.visible = !1)
        }
        for (a = 0; 33 > a; a++) {
            b = createBitmap(s_oSpriteLibrary.getSprite("gk_save_left_" +
                a));
            n.addChild(b);
            q[1].push(b);
            var c = createBitmap(s_oSpriteLibrary.getSprite("gk_save_right_" + a));
            t.addChild(c);
            q[2].push(c);
            0 < a && (b.visible = !1, c.visible = !1)
        }
    };
    this.show = function() {
        k = c = 0;
        l = 2;
        d = 23;
        h.visible = !0;
        n.visible = !1;
        t.visible = !1;
        p.visible = !0;
        q[c][0].visible = !0;
        e = 0;
        b = !0
    };
    this.dive = function(a) {
        k = 0;
        l = 1;
        d = 33;
        c = a;
        switch (c) {
            case 1:
                h.visible = !1;
                n.visible = !0;
                t.visible = !1;
                break;
            case 2:
                h.visible = !1, n.visible = !1, t.visible = !0
        }
        q[c][0].visible = !0;
        e = 0;
        this.resetIdleAnim();
        b = !0
    };
    this.resetIdleAnim = function() {
        for (var a =
                0; a < q[0].length; a++) q[0][a].visible = !1
    };
    this._showWinAnim = function() {
        p.visible = !1;
        h.visible = !0;
        n.visible = !1;
        b = t.visible = !1
    };
    this.playToFrame = function(a) {
        q[c][e].visible = !1;
        e = a;
        q[c][e].visible = !0
    };
    this.nextFrame = function() {
        q[c][e].visible = !1;
        e++;
        q[c][e].visible = !0
    };
    this.update = function() {
        !1 !== b && (k++, k === l && (k = 0, e === d - 1 ? 0 === c ? this.playToFrame(1) : (q[c][e].visible = !1, this._showWinAnim()) : this.nextFrame()))
    };
    var m = a;
    this._init()
}

function CBonusPlayer(a, b, c) {
    var d = !1,
        e, k, l, q;
    this._init = function(a, b) {
        q = new createjs.Container;
        q.visible = !1;
        q.x = a;
        q.y = b;
        p.addChild(q);
        l = [];
        for (var c = 0; 30 > c; c++) {
            var d = createBitmap(s_oSpriteLibrary.getSprite("player_" + c));
            q.addChild(d);
            l.push(d);
            0 < c && (d.visible = !1)
        }
    };
    this.show = function() {
        e = 30;
        l[0].visible = !0;
        k = 0;
        d = q.visible = !0
    };
    this.hide = function() {
        q.visible = !1
    };
    this.playToFrame = function(a) {
        l[k].visible = !1;
        k = a;
        l[k].visible = !0
    };
    this.nextFrame = function() {
        l[k].visible = !1;
        k++;
        l[k].visible = !0
    };
    this.update =
        function() {
            !1 !== d && (k === e - 1 ? (d = !1, this.hide()) : (this.nextFrame(), 9 === k && s_oBonusPanel.kick()))
        };
    var p = c;
    this._init(a, b)
}

function CBonusBall(a, b, c) {
    var d = !1,
        e, k, l, q, p, h, n, t, m, g;
    this._init = function(a, b) {
        e = a;
        k = b;
        q = 1;
        p = FPS / 2;
        var c = s_oSpriteLibrary.getSprite("ball_anim"),
            d = new createjs.SpriteSheet({
                images: [c],
                frames: {
                    width: 211,
                    height: 205,
                    regX: 105,
                    regY: 102
                },
                animations: {
                    "static": [0],
                    moving: [1, 29, "moving"]
                }
            });
        g = createSprite(d, "static", 0, 0, c.width / 2, c.height);
        g.visible = !1;
        g.x = e;
        g.y = k;
        g.stop();
        r.addChild(g);
        m = new CTweenController
    };
    this.show = function(a, b) {
        h = a;
        n = b;
        g.x = e;
        g.y = k;
        this._calculateMid(new createjs.Point(g.x, g.y), new createjs.Point(h,
            n));
        g.scaleX = g.scaleY = 1;
        g.alpha = 1;
        g.visible = !0;
        g.gotoAndPlay("moving");
        l = 0;
        d = !0
    };
    this.hide = function() {
        g.visible = !1
    };
    this._resetBall = function() {
        playSound("avatar_win", 1, !1);
        l = 0;
        g.gotoAndStop("static");
        d = !1;
        createjs.Tween.get(g).to({
            y: CANVAS_HEIGHT / 2
        }, 1500, createjs.Ease.cubicIn);
        createjs.Tween.get(g).to({
            alpha: 0
        }, 1E3, createjs.Ease.cubicIn).call(function() {
            s_oBonusPanel.ballArrived()
        })
    };
    this._calculateMid = function(a, b) {
        var c = b.x < CANVAS_WIDTH / 2 ? new createjs.Point(b.x - 100, b.y + 40) : new createjs.Point(b.x +
            100, b.y + 40);
        t = {
            start: a,
            end: b,
            traj: c
        }
    };
    this.getX = function() {
        return g.x
    };
    this.getY = function() {
        return g.y
    };
    this.update = function() {
        if (d)
            if (l += q, l > p) this._resetBall();
            else {
                var a = m.easeOutCubic(l, 0, 1, p);
                a = m.getTrajectoryPoint(a, t);
                g.x = a.x;
                g.y = a.y;
                .2 <= g.scaleX && (g.scaleX -= .06, g.scaleY -= .06)
            }
    };
    var r = c;
    this._init(a, b)
}

function CScoreText(a, b, c) {
    var d;
    this._init = function(a, b, c) {
        d = new createjs.Text("00000", " 60px " + FONT_GAME_1, "#ffd202");
        d.textAlign = "center";
        d.text = "X" + a;
        d.x = b;
        d.y = c;
        d.alpha = 0;
        d.shadow = new createjs.Shadow("#000", 1, 1, 1);
        s_oStage.addChild(d);
        var e = this;
        createjs.Tween.get(d).to({
            alpha: 1
        }, 200, createjs.Ease.quadIn).call(function() {
            e.moveUp()
        })
    };
    this.moveUp = function() {
        var a = d.y - 100,
            b = this;
        createjs.Tween.get(d).to({
            y: a
        }, 1500, createjs.Ease.sineIn).call(function() {
            b.unload()
        });
        createjs.Tween.get(d).wait(800).to({
                alpha: 0
            },
            500)
    };
    this.unload = function() {
        s_oStage.removeChild(d)
    };
    this._init(a, b, c)
}

function CBonusResultPanel(a, b) {
    var c, d;
    this._init = function(a) {
        c = new createjs.Shape;
        c.graphics.beginFill("black").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        c.alpha = 0;
        e.addChild(c);
        d = new createjs.Container;
        d.x = -CANVAS_WIDTH / 2;
        d.y = CANVAS_HEIGHT / 2;
        e.addChild(d);
        var b = s_oSpriteLibrary.getSprite("bonus_panel_bg"),
            k = createBitmap(b);
        k.regX = b.width / 2;
        k.regY = b.height / 2;
        d.addChild(k);
        b = new createjs.Text(TEXT_CONGRATS, "52px " + FONT_GAME_1, "#fff");
        b.textAlign = "center";
        b.y = -110;
        b.shadow = new createjs.Shadow("#000",
            1, 1, 1);
        d.addChild(b);
        a = new createjs.Text(TEXT_YOU_WIN + "\nX" + a, "50px " + FONT_GAME_1, "#fff");
        a.y = 10;
        a.textAlign = "center";
        a.lineHeight = 50;
        a.shadow = new createjs.Shadow("#000", 1, 1, 1);
        d.addChild(a);
        createjs.Tween.get(d).to({
            x: CANVAS_WIDTH / 2
        }, 1E3, createjs.Ease.cubicOut).call(function() {
            createjs.Tween.get(c).to({
                alpha: .6
            }, 400)
        }).call(function() {
            setTimeout(function() {
                s_oBonusPanel.unload()
            }, 2E3)
        });
        playSound("bonus_win", 1, !1)
    };
    this.unload = function() {
        e.removeChild(c);
        e.removeChild(d)
    };
    var e = b;
    this._init(a)
}

function CFreespinPanel(a) {
    var b, c, d;
    this._init = function() {
        d = new createjs.Container;
        d.visible = !1;
        e.addChild(d);
        var a = createBitmap(s_oSpriteLibrary.getSprite("msg_box"));
        d.addChild(a);
        b = new createjs.Text(TEXT_CONGRATS, "50px " + FONT_GAME_1, "#fff");
        b.textAlign = "center";
        b.textBaseline = "alphabetic";
        b.lineWidth = 400;
        b.x = CANVAS_WIDTH / 2;
        b.y = 300;
        d.addChild(b);
        c = new createjs.Text("", "55px " + FONT_GAME_1, "#fff");
        c.textAlign = "center";
        c.textBaseline = "alphabetic";
        c.lineWidth = 400;
        c.lineHeight = 66;
        c.x = CANVAS_WIDTH / 2;
        c.y = 420;
        d.addChild(c)
    };
    this.show = function(a) {
        c.text = TEXT_YOU_WIN + " " + a + " " + TEXT_FREESPINS;
        d.on("click", function() {});
        d.alpha = 0;
        d.visible = !0;
        var b = this;
        createjs.Tween.get(d).to({
            alpha: 1
        }, 800, createjs.Ease.cubicOut).call(function() {
            setTimeout(function() {
                b.hide()
            }, 3E3)
        });
        playSound("bonus_win", 1, !1)
    };
    this.hide = function() {
        d.off("click", function() {});
        createjs.Tween.get(d).to({
            alpha: 0
        }, 800, createjs.Ease.cubicOut).call(function() {
            d.visible = !1
        });
        s_oGame.exitFromFreespinPanel()
    };
    var e = a;
    this._init()
}

function CAvatar(a) {
    var b, c = !1,
        d = !1,
        e, k = 2,
        l = 0,
        q, p = 0,
        h, n, t, m;
    this._init = function() {
        b = 50;
        m = new createjs.Container;
        m.x = 130;
        m.y = 252;
        g.addChild(m);
        n = new createjs.Container;
        m.addChild(n);
        t = new createjs.Container;
        t.visible = !1;
        m.addChild(t);
        h = [
            [],
            []
        ];
        for (var a = 0; 30 > a; a++) {
            var c = createBitmap(s_oSpriteLibrary.getSprite("avatar_idle_" + a));
            n.addChild(c);
            h[0][a] = c;
            c.visible = !1
        }
        for (a = 0; 38 > a; a++) c = createBitmap(s_oSpriteLibrary.getSprite("avatar_win_" + a)), t.addChild(c), h[1][a] = c, c.visible = !1;
        this.refreshButtonPos(s_iOffsetX)
    };
    this._hideAllAnims = function() {
        for (var a = 0; a < h[0].length; a++) h[0][a].visible = !1, h[1][a].visible = !1, h[2][a].visible = !1
    };
    this.refreshButtonPos = function(a, c) {
        130 > b + a && (m.x = b + a)
    };
    this.show = function(a) {
        h[p][l].visible = !1;
        p = a;
        switch (a) {
            case 0:
                n.visible = !0;
                t.visible = !1;
                break;
            case 1:
                n.visible = !1, t.visible = !0
        }
        q = h[p].length;
        k = 2;
        h[p][0].visible = !0;
        d = l = e = 0;
        c = !0
    };
    this.playToFrame = function(a) {
        h[p][l].visible = !1;
        l = a;
        h[p][l].visible = !0
    };
    this.nextFrame = function() {
        h[p][l].visible = !1;
        l++;
        h[p][l].visible = !0
    };
    this.update =
        function() {
            !1 !== c && (e++, e === k && (e = 0, l === q - 1 ? (this.playToFrame(1), d++, 2 === d && 1 === p && this.show(0)) : this.nextFrame()))
        };
    var g = a;
    this._init()
}

function CCreditsPanel() {
    var a, b, c, d;
    this._init = function() {
        b = new createjs.Container;
        s_oStage.addChild(b);
        var e = s_oSpriteLibrary.getSprite("msg_box");
        e = createBitmap(e);
        b.addChild(e);
        a = new createjs.Shape;
        a.graphics.beginFill("#0f0f0f").drawRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
        a.alpha = .01;
        a.on("click", this._onLogoButRelease);
        b.addChild(a);
        e = new createjs.Text(TEXT_DEVELOPED, " 34px " + FONT_GAME_1, "#000000");
        e.x = CANVAS_WIDTH / 2;
        e.y = 336;
        e.textAlign = "center";
        e.textBaseline = "middle";
        e.lineWidth = 300;
        e.outline =
            5;
        b.addChild(e);
        var k = new createjs.Text(TEXT_DEVELOPED, " 34px " + FONT_GAME_1, "#ffffff");
        k.x = CANVAS_WIDTH / 2;
        k.y = e.y;
        k.textAlign = "center";
        k.textBaseline = "middle";
        k.lineWidth = 300;
        b.addChild(k);
        e = new createjs.Text("www.codethislab.com", " 34px " + FONT_GAME_1, "#000000");
        e.x = CANVAS_WIDTH / 2;
        e.y = 460;
        e.textAlign = "center";
        e.textBaseline = "middle";
        e.lineWidth = 300;
        e.outline = 5;
        b.addChild(e);
        k = new createjs.Text("www.codethislab.com", " 34px " + FONT_GAME_1, "#ffffff");
        k.x = CANVAS_WIDTH / 2;
        k.y = e.y;
        k.textAlign = "center";
        k.textBaseline =
            "middle";
        k.lineWidth = 300;
        b.addChild(k);
        e = s_oSpriteLibrary.getSprite("ctl_logo");
        d = createBitmap(e);
        d.regX = e.width / 2;
        d.regY = e.height / 2;
        d.x = CANVAS_WIDTH / 2;
        d.y = CANVAS_HEIGHT / 2;
        b.addChild(d);
        e = s_oSpriteLibrary.getSprite("but_exit_info");
        c = new CGfxButton(970, 264, e, b);
        c.addEventListener(ON_MOUSE_UP, this.unload, this);
        b.alpha = 0;
        createjs.Tween.get(b).to({
            alpha: 1
        }, 1E3, createjs.Ease.cubicOut)
    };
    this.unload = function() {
        c.unload();
        a.off("mousedown", this._onLogoButRelease);
        s_oStage.removeChild(b)
    };
    this._onLogoButRelease =
        function() {
            window.open("http://www.codethislab.com/index.php?&l=en")
        };
    this._init()
}

function extractHostname(a) {
    a = -1 < a.indexOf("://") ? a.split("/")[2] : a.split("/")[0];
    a = a.split(":")[0];
    return a = a.split("?")[0]
}

function extractRootDomain(a) {
    a = extractHostname(a);
    var b = a.split("."),
        c = b.length;
    2 < c && (a = b[c - 2] + "." + b[c - 1]);
    return a
}
var getClosestTop = function() {
        var a = window,
            b = !1;
        try {
            for (; a.parent.document !== a.document;)
                if (a.parent.document) a = a.parent;
                else {
                    b = !0;
                    break
                }
        } catch (c) {
            b = !0
        }
        return {
            topFrame: a,
            err: b
        }
    },
    getBestPageUrl = function(a) {
        var b = a.topFrame,
            c = "";
        if (a.err) try {
            try {
                c = window.top.location.href
            } catch (e) {
                var d = window.location.ancestorOrigins;
                c = d[d.length - 1]
            }
        } catch (e) {
            c = b.document.referrer
        } else c = b.location.href;
        return c
    },
    TOPFRAMEOBJ = getClosestTop(),
    PAGE_URL = getBestPageUrl(TOPFRAMEOBJ);

function seekAndDestroy() {
    for (var a = extractRootDomain(PAGE_URL), b = [String.fromCharCode(99, 111, 100, 101, 116, 104, 105, 115, 108, 97, 98, 46, 99, 111, 109), String.fromCharCode(101, 110, 118, 97, 116, 111, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 99, 111, 109), String.fromCharCode(99, 111, 100, 101, 99, 97, 110, 121, 111, 110, 46, 110, 101, 116)], c = 0; c < b.length; c++)
        if (b[c] === a) return !0;
    return !1
};